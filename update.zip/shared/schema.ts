import { z } from "zod";

// --- JSON Data Models based on User Requirements ---

export const TargetSchema = z.object({
  chatId: z.string(),
  username: z.string().optional(),
  title: z.string().optional(),
  addedAt: z.number(),
  lastSentAt: z.number().optional(),
  failCount: z.number().optional(),
  banStatus: z.enum(["ACTIVE", "BANNED", "FORBIDDEN"]).default("ACTIVE").optional(),
  lastBanAt: z.number().optional(),
  banReason: z.string().optional(),
  retryCount: z.number().default(0).optional(),
});

export const TimerSchema = z.object({
  enabled: z.boolean(),
  startAt: z.string(), // HH:mm
  stopAt: z.string(), // HH:mm
});

export const PmPermitSchema = z.object({
  enabled: z.boolean(),
  template: z.string(),
  allowed: z.array(z.string()),
});

export const AutoReplyKeywordSchema = z.object({
  enabled: z.boolean(),
  keywords: z.array(z.string()),
  replyText: z.string().optional(),
  useForward: z.boolean(),
});

export const AutoPilotSchema = z.object({
  enabled: z.boolean(),
  scanLinks: z.boolean(),
  autoJoin: z.boolean(),
  joinedCount: z.number(),
  lastScanAt: z.number(),
});

// New Features - Broadcast Pesan Pribadi
export const BroadcastPrivateMessagesSchema = z.object({
  enabled: z.boolean(),
  message: z.string().optional(),
  lastExecutedAt: z.number().optional(),
  targetCount: z.number().default(0),
});

// New Features - Auto Leave
export const AutoLeaveSchema = z.object({
  enabled: z.boolean(),
  leaveAfterDays: z.number().min(1).default(1),
  lastExecutedAt: z.number().optional(),
  leftCount: z.number().default(0),
});

// New Features - Auto Read Chat
export const AutoReadChatSchema = z.object({
  enabled: z.boolean(),
  readGroups: z.boolean().default(true),
  readPrivate: z.boolean().default(true),
  lastExecutedAt: z.number().optional(),
});

// New Features - Clear Chat
export const ClearChatSchema = z.object({
  enabled: z.boolean(),
  clearGroups: z.boolean().default(false),
  clearPrivate: z.boolean().default(false),
  deleteLimitDays: z.number().optional(),
  lastExecutedAt: z.number().optional(),
  deletedCount: z.number().default(0),
});

// New Features - Message Delivery Enhancements
export const MessageDeliverySchema = z.object({
  mentionAllMembers: z.boolean().default(false),
  showTypingIndicator: z.boolean().default(false),
  typingDelayMs: z.number().default(1000),
  randomizeTyping: z.boolean().default(false),
});

export const StatsSchema = z.object({
  sent: z.number(),
  failed: z.number(),
  skipped: z.number(),
  lastError: z.string().optional(),
  uptimeStartAt: z.number(),
  lastPingMs: z.number(),
  lastRunAt: z.number(),
});

export const AuthSchema = z.object({
  type: z.enum(["STRING_SESSION", "PHONE_LOGIN"]),
  stringSession: z.string().optional(),
  phoneNumber: z.string().optional(),
});

export const SubscriptionSchema = z.object({
  active: z.boolean(),
  expireAt: z.number(),
  autoOffApplied: z.boolean(),
  resumeMode: z.enum(["RESUME", "RESET"]),
  startedAt: z.number().optional(), // Waktu subscription dimulai
  // Duration stored as milliseconds to support hours/days/weeks/months
  durationMs: z.number().optional(),
  durationDays: z.number().optional(), // Backwards compatibility
  buyerName: z.string().optional(), // Nama pembeli
  uniqueTrackingId: z.string().uuid().optional(), // ID unik untuk tracking
});

export const ForwardConfigSchema = z.object({
  chatId: z.string().optional(),
  messageIds: z.array(z.number()),
});

export const ForwardedMessageSchema = z.object({
  chatId: z.string(),
  messageIds: z.array(z.number()),
});

export const SettingsSchema = z.object({
  messageType: z.enum(["FORWARD", "REGULAR"]),
  forwardConfig: ForwardConfigSchema.optional(),
  forwardedMessage: ForwardedMessageSchema.optional(),
  forwardFromChatId: z.string().optional(), // Legacy
  forwardText: z.string().optional(), // Legacy - message ID
  regularText: z.string().optional(),
  watermarkText: z.string().optional(),
  spreadMode: z.enum(["INSTANT", "SEQUENTIAL"]),
  premiumEmoji: z.boolean().optional(),
  delays: z.object({
    instantLoopDelaySec: z.number().min(60),
    sequentialPerGroupDelaySec: z.number().min(5),
  }),
  targets: z.array(TargetSchema),
  timer: TimerSchema,
  blacklist: z.array(z.string()).optional(),
  // New features
  broadcastPrivateMessages: BroadcastPrivateMessagesSchema.optional(),
  autoLeave: AutoLeaveSchema.optional(),
  autoReadChat: AutoReadChatSchema.optional(),
  clearChat: ClearChatSchema.optional(),
  messageDelivery: MessageDeliverySchema.optional(),
});

export const UserbotSchema = z.object({
  id: z.string().uuid(),
  label: z.string(),
  buyerId: z.string(),
  auth: AuthSchema,
  subscription: SubscriptionSchema,
  status: z.enum(["READY", "RUNNING", "STOPPED", "OFF_SUBS", "ERROR"]),
  settings: SettingsSchema,
  pmPermit: PmPermitSchema,
  autoReplyKeyword: AutoReplyKeywordSchema.optional(),
  autoPilot: AutoPilotSchema.optional(),
  stats: StatsSchema,
});

export const GlobalSettingsSchema = z.object({
  defaultInstantDelay: z.number().min(60),
  defaultSequentialDelay: z.number().min(5),
  defaultWatermark: z.string().optional(),
  defaultPremiumEmoji: z.boolean(),
  globalBlacklist: z.array(z.string()),
  antiSpamCooldown: z.number(),
  maxTargetsPerUserbot: z.number(),
  autoJoinDelay: z.number(),
  floodWaitMultiplier: z.number(),
  timezone: z.string().default("Asia/Jakarta"), // Timezone untuk timer
});

export const BackupScheduleSchema = z.object({
  day: z.string(),
  hour: z.string(),
  minute: z.string(),
});

export const BackupSettingsSchema = z.object({
  enabled: z.boolean(),
  channelId: z.string().nullable(),
  schedule: BackupScheduleSchema,
});

export const BotBroadcastSchema = z.object({
  mode: z.enum(["CHANNEL", "GROUP", "PM"]),
  targets: z.array(z.string()),
  message: z.string().nullable(),
  lastBroadcastAt: z.number().nullable(),
});

export const JobSchema = z.object({
  running: z.boolean(),
  progressIndex: z.number(),
  lastSentAt: z.number(),
  loopCount: z.number(),
  lastTargetId: z.string().optional(),
  pausedReason: z.string().optional(),
  stateSnapshot: z.any().optional(),
});

// Full DB Schema
export const DatabaseSchema = z.object({
  userbots: z.array(UserbotSchema),
  jobs: z.record(JobSchema),
  globalSettings: GlobalSettingsSchema.optional(),
  backupSettings: BackupSettingsSchema.optional(),
  botBroadcast: BotBroadcastSchema.optional(),
});

export type Userbot = z.infer<typeof UserbotSchema>;
export type Job = z.infer<typeof JobSchema>;
export type Database = z.infer<typeof DatabaseSchema>;
export type GlobalSettings = z.infer<typeof GlobalSettingsSchema>;
export type AutoReplyKeyword = z.infer<typeof AutoReplyKeywordSchema>;
export type AutoPilot = z.infer<typeof AutoPilotSchema>;
export type BackupSettings = z.infer<typeof BackupSettingsSchema>;
export type BotBroadcast = z.infer<typeof BotBroadcastSchema>;

// --- Frontend API Types ---

export const BotStatusSchema = z.object({
  status: z.enum(["online", "offline"]),
  userbots_count: z.number(),
  active_jobs: z.number(),
  total_sent: z.number(),
  uptime: z.number(),
});

export type BotStatus = z.infer<typeof BotStatusSchema>;
