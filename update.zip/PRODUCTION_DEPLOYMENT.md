/**
 * JASEB PRODUCTION DEPLOYMENT GUIDE
 * Panduan lengkap untuk deploy bot ke production dengan safety checks
 */

# ============================================================================
#           JASEB v2.1 - PRODUCTION DEPLOYMENT GUIDE
# ============================================================================

## 📋 PRE-DEPLOYMENT CHECKLIST

### 1. Environment Setup
- [ ] `.env` file sudah dikonfigurasi dengan nilai production
- [ ] `BOT_TOKEN` valid dan active
- [ ] `OWNER_IDS` sudah diset dengan admin ID yang benar
- [ ] `DATA_DIR` pointing ke persistent storage
- [ ] `NODE_ENV=production` di environment variables
- [ ] `LOG_LEVEL` diset ke 'info' (bukan 'debug')

### 2. Database Verification
```bash
# Verify database integrity
npm run check

# Backup database sebelum deployment
cp data/db.json data/backups/backup_pre-deploy_$(date +%s).json

# Check file permissions
chmod 600 data/db.json
chmod 700 data/
```

### 3. Dependencies Check
```bash
# Verify semua dependencies terinstall
npm ci --production

# Check for security vulnerabilities
npm audit

# Build verification
npm run build

# Size check
ls -lh dist/
```

### 4. Configuration Review
```bash
# Check env variables
env | grep -E "BOT_TOKEN|OWNER|DATA"

# Verify timezone setting
node -e "console.log(new Intl.DateTimeFormat().resolvedOptions().timeZone)"
```

---

## 🚀 DEPLOYMENT STEPS

### Step 1: Build & Test
```bash
# Production build
npm run build

# Verify build output
ls -la dist/

# Check for build errors
file dist/index.cjs
```

### Step 2: Database Setup
```bash
# Ensure database directory exists
mkdir -p data/backups

# Initialize database (if new)
node -e "require('./dist/index.cjs')" &
sleep 2
kill %1

# Verify database created
ls -la data/db.json
```

### Step 3: Start Bot
```bash
# Option 1: Direct
npm start

# Option 2: With process manager (recommended)
pm2 start "npm start" --name "jaseb-bot" --max-memory-restart 500M

# Option 3: Docker
docker run -d \
  -e BOT_TOKEN=$BOT_TOKEN \
  -e OWNER_IDS=$OWNER_IDS \
  -v $(pwd)/data:/app/data \
  jaseb-bot:latest
```

### Step 4: Health Check
```bash
# Check if bot is responding
curl -s http://localhost:3000/health || echo "Bot running"

# Check process
ps aux | grep "node.*index"

# Check logs
tail -f logs/jaseb.log
```

### Step 5: Verification
```bash
# Verify bot is receiving updates
# Send /start command dari telegram

# Check database was updated
cat data/db.json | jq '.userbots | length'

# Monitor for errors
npm run dev 2>&1 | grep -i error
```

---

## 🔒 SECURITY HARDENING

### 1. File Permissions
```bash
# Secure database file
chmod 600 data/db.json
chmod 700 data/
chmod 700 data/backups/

# Secure environment
chmod 600 .env
chmod 600 .env.production
```

### 2. Process User
```bash
# Jalankan bot dengan limited user (bukan root)
useradd -m -s /bin/bash jaseb-bot
chown -R jaseb-bot:jaseb-bot /path/to/bot/data

# Run as user
sudo -u jaseb-bot npm start
```

### 3. Network Security
```bash
# Firewall: Hanya allow bot token access
# Jangan expose internal ports

# Gunakan reverse proxy (nginx)
# Implementasi rate limiting
# Enable HTTPS jika ada web interface
```

### 4. Data Protection
```bash
# Encrypt database (recommended)
# Enable WAL mode untuk SQLite
# Regular automated backups
# Test restore procedure

# Example: Encrypt sensitive data
const crypto = require('crypto');
function encryptSessionString(session) {
  return crypto.createHash('sha256').update(session).digest('hex');
}
```

---

## 📊 MONITORING & MAINTENANCE

### 1. Log Monitoring
```bash
# Setup log rotation
npm install winston-daily-rotate-file

# Monitor specific patterns
tail -f logs/jaseb.log | grep -E "ERROR|WARN"

# Alert on critical errors
tail -f logs/jaseb.log | grep "ERROR" | mail -s "JASEB Error Alert"
```

### 2. Resource Monitoring
```bash
# CPU & Memory
watch -n 5 'ps aux | grep node'

# Disk space
df -h data/

# Database size
du -sh data/db.json
```

### 3. Bot Health Check
```javascript
// Periodic health check script
const health = {
  uptime: process.uptime(),
  memory: process.memoryUsage(),
  dbSize: fs.statSync('data/db.json').size,
  botConnected: !!jasebBot.bot,
  activeUsers: userStateManager.getStats().total
};

console.log(JSON.stringify(health, null, 2));
```

### 4. Backup Strategy
```bash
# Daily backup script (cron)
0 2 * * * /home/jaseb-bot/backup.sh

# backup.sh content:
#!/bin/bash
BACKUP_DIR="/path/to/bot/data/backups"
TIMESTAMP=$(date +%Y-%m-%d_%H-%M-%S)
cp data/db.json "$BACKUP_DIR/backup_$TIMESTAMP.json"
gzip "$BACKUP_DIR/backup_$TIMESTAMP.json"

# Cleanup old backups (keep 30 days)
find "$BACKUP_DIR" -name "backup_*.json.gz" -mtime +30 -delete
```

---

## ⚠️ COMMON ISSUES & SOLUTIONS

### Issue: Bot tidak respond terhadap commands
**Debug Steps**:
```bash
# 1. Check if bot token valid
echo "BOT_TOKEN: $BOT_TOKEN"

# 2. Check if bot running
ps aux | grep node

# 3. Check logs
tail -100 logs/jaseb.log

# 4. Test dengan curl
curl -X POST https://api.telegram.org/botTOKEN/getMe
```

**Solutions**:
- Verify BOT_TOKEN di .env
- Check network connectivity
- Restart bot: `npm restart`
- Check if bot blocked by Telegram

### Issue: High memory usage
**Debug**:
```bash
# Monitor memory growth
watch -n 5 'ps aux | grep node | awk "{print $6}"'

# Check for memory leaks
node --inspect=0.0.0.0:9229 dist/index.cjs
# Open chrome://inspect di Chrome
```

**Solutions**:
- Implement periodic restart
- Check for circular references
- Reduce cache size
- Implement memory cleanup interval

### Issue: Database corruption
**Debug**:
```bash
# Check database integrity
node -e "
const fs = require('fs');
try {
  const db = JSON.parse(fs.readFileSync('data/db.json', 'utf8'));
  console.log('Database valid');
  console.log('Userbots:', db.userbots.length);
} catch (e) {
  console.error('Database corrupted:', e.message);
}
"
```

**Solutions**:
- Restore dari backup
- Re-initialize database
- Check file system health

### Issue: Broadcast stuck/slow
**Debug**:
```bash
# Check active userbots
cat data/db.json | jq '.userbots | map(select(.status == "RUNNING")) | length'

# Check target count
cat data/db.json | jq '.userbots[0].settings.targets | length'
```

**Solutions**:
- Check delay settings
- Verify network connectivity
- Check Telegram rate limits
- Reduce target count per broadcast
- Use sequential mode instead of instant

---

## 🔄 UPDATE PROCEDURE

### Minor Updates (patches)
```bash
# 1. Backup
cp -r data data.backup_$(date +%s)

# 2. Update code
git pull origin main

# 3. Install dependencies
npm ci --production

# 4. Verify
npm run check

# 5. Restart
npm restart
```

### Major Updates
```bash
# 1. Full backup
tar -czf backup_$(date +%Y-%m-%d).tar.gz data/

# 2. Test di staging
# Deploy to test environment dulu

# 3. Blue-green deployment (recommended)
# Run new version di separate process
# Test semua functionality
# Switch traffic ke new version
# Keep old version running untuk rollback

# 4. Monitor closely
tail -f logs/jaseb.log
```

### Rollback Procedure
```bash
# If update causes issues:

# 1. Stop current bot
npm stop
kill $(ps aux | grep "node.*index" | awk '{print $2}')

# 2. Restore previous version
git checkout [previous-tag]

# 3. Restore database
rm data/db.json
cp data.backup_[timestamp]/db.json data/

# 4. Rebuild & start
npm run build
npm start
```

---

## 📈 PERFORMANCE OPTIMIZATION

### 1. Database Optimization
```javascript
// Add indexes untuk frequently accessed fields
// Optimize query patterns
// Implement caching layer

const cache = new Map();
const CACHE_TTL = 5000; // 5 seconds

async function getCachedDb() {
  const now = Date.now();
  if (cache.has('db') && now - cache.get('db').time < CACHE_TTL) {
    return cache.get('db').data;
  }
  
  const db = await jsonDb.read();
  cache.set('db', { data: db, time: now });
  return db;
}
```

### 2. Message Broadcasting Optimization
```javascript
// Implementasi queue system
// Batch messages
// Implement priority queue
// Rate limit per userbot

class BroadcastQueue {
  private queue = [];
  private processing = false;

  async add(item) {
    this.queue.push(item);
    this.processQueue();
  }

  private async processQueue() {
    if (this.processing || this.queue.length === 0) return;
    
    this.processing = true;
    const item = this.queue.shift();
    
    try {
      await item.process();
    } finally {
      this.processing = false;
      this.processQueue();
    }
  }
}
```

### 3. Connection Pooling
```javascript
// Reuse GramJS connections
// Implement connection pool
// Monitor connection health

class ClientPool {
  private clients = new Map();
  private maxClientsPerUserbot = 3;

  getClient(userbotId) {
    if (!this.clients.has(userbotId)) {
      this.clients.set(userbotId, []);
    }
    
    const clients = this.clients.get(userbotId);
    // Return healthy client atau create new
    return clients.find(c => c.isHealthy) || this.createNewClient(userbotId);
  }
}
```

---

## 🎯 SUCCESS METRICS

Setelah deployment, monitor metrics ini:

```javascript
const metrics = {
  // Availability
  uptime: '> 99.5%',
  responseTime: '< 100ms',
  
  // Performance
  broadcastSpeed: '100+ messages/minute',
  errorRate: '< 0.1%',
  memoryUsage: '< 200MB',
  
  // User satisfaction
  commandSuccess: '> 99%',
  activeUsers: 'track growth',
  errorReports: '< 5 per day'
};
```

Monitor di dashboard atau alert system:
```bash
# Setup monitoring dengan Prometheus
npm install prom-client

# Export metrics
app.get('/metrics', (req, res) => {
  res.set('Content-Type', register.contentType);
  res.end(register.metrics());
});
```

---

## 🆘 SUPPORT & ESCALATION

### Quick Support Checklist
1. Check logs: `tail -100 logs/jaseb.log`
2. Verify env: `env | grep BOT`
3. Test bot token: `curl https://api.telegram.org/botTOKEN/getMe`
4. Check database: `cat data/db.json | jq '.userbots | length'`
5. Restart if needed: `npm restart`

### Escalation Path
1. **Level 1**: Check logs dan restart
2. **Level 2**: Check database, verify configs
3. **Level 3**: Database recovery, restore from backup
4. **Level 4**: Code issue investigation, contact development

---

## 📞 CONTACT & RESOURCES

- Documentation: See OPTIMIZATION_SUMMARY.md
- GitHub Issues: [repo-url]/issues
- Telegram Support: @jaseb_support
- Email: support@jaseb.dev

---

Generated: January 31, 2026
Version: 2.1.0
Status: PRODUCTION-READY

Untuk pertanyaan lebih lanjut, hubungi tim development.

