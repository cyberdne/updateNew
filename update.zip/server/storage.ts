import { randomUUID } from "crypto";

// Legacy storage interface - not currently used
// Please use server/storage/db.ts for current database operations

export interface IStorage {
  // Deprecated - use jsonDb from server/storage/db.ts instead
}

// Legacy MemStorage - not used
// export class MemStorage implements IStorage {
//   // Deprecated
// }

// export const storage = new MemStorage();
