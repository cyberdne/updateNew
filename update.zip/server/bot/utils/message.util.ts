import type { Context, Markup } from 'telegraf';
import type { InlineKeyboardMarkup } from 'telegraf/types';

type KeyboardMarkup = ReturnType<typeof Markup.inlineKeyboard> | InlineKeyboardMarkup;

export async function safeEditOrResend(ctx: Context, text: string, keyboard?: KeyboardMarkup) {
  // Extract reply_markup if it's a Markup wrapper object
  const replyMarkup = keyboard && 'reply_markup' in keyboard 
    ? keyboard.reply_markup 
    : keyboard;

  try {
    // Try to edit (only works for callback queries)
    if (ctx.callbackQuery) {
      await ctx.editMessageText(text, {
        parse_mode: 'HTML',
        reply_markup: replyMarkup as InlineKeyboardMarkup
      });
      return;
    }
  } catch (error: any) {
    // If message is not modified or other edit error
    if (error.description?.includes('message is not modified')) return;
  }

  // Fallback: Send new message (for /start command or when edit fails)
  try {
    // Delete old message if from callback
    if (ctx.callbackQuery?.message?.message_id) {
      await ctx.deleteMessage(ctx.callbackQuery.message.message_id).catch(() => {});
    }
    await ctx.reply(text, {
      parse_mode: 'HTML',
      reply_markup: replyMarkup as InlineKeyboardMarkup
    });
  } catch (e) {
    console.error('Failed to safeEditOrResend', e);
  }
}
