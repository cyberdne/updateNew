/**
 * User State Management untuk JASEB Bot
 * Mengelola user interaction state dengan better tracking dan cleanup
 */

import pino from 'pino';

const logger = pino({ level: 'info' });

export enum UserStateStep {
  // Idle state
  IDLE = 'IDLE',
  
  // Phone login flow
  PHONE_LOGIN_NUMBER = 'PHONE_LOGIN_NUMBER',
  PHONE_LOGIN_CODE = 'PHONE_LOGIN_CODE',
  PHONE_LOGIN_PASSWORD = 'PHONE_LOGIN_PASSWORD',
  
  // Session add flow
  ADD_SESSION_STRING = 'ADD_SESSION_STRING',
  ASK_BUYER_ID = 'ASK_BUYER_ID',
  ASK_BUYER_ID_SESSION = 'ASK_BUYER_ID_SESSION',
  ASK_SUBSCRIPTION = 'ASK_SUBSCRIPTION',
  ASK_SUBSCRIPTION_SESSION = 'ASK_SUBSCRIPTION_SESSION',
  
  // Settings flows
  SET_REG_TEXT = 'SET_REG_TEXT',
  SET_WATERMARK = 'SET_WATERMARK',
  
  // Forward flow
  AWAIT_FORWARD = 'AWAIT_FORWARD',
  SET_FORWARD_CHAT = 'SET_FORWARD_CHAT',
  SET_FORWARD_MSG_ID = 'SET_FORWARD_MSG_ID',
  
  // Target flows
  ADD_TARGET_MANUAL = 'ADD_TARGET_MANUAL',
  SCAN_CHANNEL = 'SCAN_CHANNEL',
  SEARCH_KEYWORD = 'SEARCH_KEYWORD',
  JOIN_LIST = 'JOIN_LIST',
  
  // Timer flows
  SET_TIMER_START = 'SET_TIMER_START',
  SET_TIMER_STOP = 'SET_TIMER_STOP',
  
  // PM Permit flows
  SET_PM_TEMPLATE = 'SET_PM_TEMPLATE',
  ADD_PM_ALLOW = 'ADD_PM_ALLOW',
  
  // Delay flows
  SET_INSTANT_DELAY = 'SET_INSTANT_DELAY',
  SET_SEQ_DELAY = 'SET_SEQ_DELAY',
  
  // Global settings flows
  GLOBAL_INSTANT_DELAY = 'GLOBAL_INSTANT_DELAY',
  GLOBAL_SEQ_DELAY = 'GLOBAL_SEQ_DELAY',
  GLOBAL_MAX_TARGETS = 'GLOBAL_MAX_TARGETS',
  GLOBAL_JOIN_DELAY = 'GLOBAL_JOIN_DELAY',
  GLOBAL_WATERMARK = 'GLOBAL_WATERMARK',
  GLOBAL_ADD_BLACKLIST = 'GLOBAL_ADD_BLACKLIST',
  GLOBAL_SET_TIMEZONE = 'GLOBAL_SET_TIMEZONE',
  
  // Backup flows
  SET_BACKUP_CHANNEL = 'SET_BACKUP_CHANNEL',
  SET_BACKUP_TIME = 'SET_BACKUP_TIME',
  SET_BACKUP_DAY = 'SET_BACKUP_DAY',
  
  // Broadcast flows
  ADD_BC_TARGET = 'ADD_BC_TARGET',
  SET_BC_MESSAGE = 'SET_BC_MESSAGE',
  BPM_MESSAGE = 'BPM_MESSAGE',
  
  // Other flows
  SOURCE_CUSTOM_NAME = 'SOURCE_CUSTOM_NAME',
  EXTEND_SUBSCRIPTION = 'EXTEND_SUBSCRIPTION',
  SET_SUB_HOURS = 'SET_SUB_HOURS',
  SET_SUB_DAYS = 'SET_SUB_DAYS',
  SET_SUB_WEEKS = 'SET_SUB_WEEKS',
  SET_SUB_MONTHS = 'SET_SUB_MONTHS',
  SET_SUB_YEARS = 'SET_SUB_YEARS',
  ADD_AUTOREPLY_KEYWORD = 'ADD_AUTOREPLY_KEYWORD',
  SET_AUTOREPLY_TEXT = 'SET_AUTOREPLY_TEXT',
  AUTO_LEAVE_DAYS = 'AUTO_LEAVE_DAYS',
  CLEAR_CHAT_DAYS = 'CLEAR_CHAT_DAYS',
}

export interface UserState {
  step: UserStateStep;
  temp?: Record<string, any>;
  createdAt?: number;
  lastInteractionAt?: number;
}

/**
 * Improved user state manager dengan auto-cleanup dan tracking
 */
export class UserStateManager {
  private states = new Map<number, UserState>();
  private readonly STATE_TIMEOUT = 15 * 60 * 1000; // 15 minutes
  private cleanupInterval: NodeJS.Timer | null = null;

  constructor() {
    this.startCleanupInterval();
  }

  /**
   * Get user state
   */
  getState(userId: number): UserState | undefined {
    const state = this.states.get(userId);
    
    if (state) {
      // Update last interaction time
      state.lastInteractionAt = Date.now();
    }
    
    return state;
  }

  /**
   * Set user state
   */
  setState(userId: number, step: UserStateStep, temp?: Record<string, any>) {
    const now = Date.now();
    
    this.states.set(userId, {
      step,
      temp: temp || {},
      createdAt: now,
      lastInteractionAt: now
    });
    
    logger.info({ userId, step }, 'User state updated');
  }

  /**
   * Update temp data for current state
   */
  updateTemp(userId: number, updates: Record<string, any>) {
    const state = this.states.get(userId);
    
    if (state) {
      state.temp = { ...state.temp, ...updates };
      state.lastInteractionAt = Date.now();
    }
  }

  /**
   * Clear user state
   */
  clearState(userId: number) {
    const hadState = this.states.has(userId);
    this.states.delete(userId);
    
    if (hadState) {
      logger.info({ userId }, 'User state cleared');
    }
  }

  /**
   * Get all active states (for monitoring)
   */
  getAllStates(): Map<number, UserState> {
    return new Map(this.states);
  }

  /**
   * Get state stats
   */
  getStats(): { total: number; byStep: Record<string, number> } {
    const byStep: Record<string, number> = {};
    
    for (const state of this.states.values()) {
      byStep[state.step] = (byStep[state.step] || 0) + 1;
    }
    
    return {
      total: this.states.size,
      byStep
    };
  }

  /**
   * Start automatic cleanup of old states
   */
  private startCleanupInterval() {
    this.cleanupInterval = setInterval(() => {
      const now = Date.now();
      let cleaned = 0;
      
      for (const [userId, state] of this.states.entries()) {
        const lastInteraction = state.lastInteractionAt || state.createdAt || 0;
        
        if (now - lastInteraction > this.STATE_TIMEOUT) {
          this.states.delete(userId);
          cleaned++;
        }
      }
      
      if (cleaned > 0) {
        logger.info({ cleaned }, 'Cleaned up old user states');
      }
    }, 5 * 60 * 1000); // Check every 5 minutes
  }

  /**
   * Stop cleanup interval (for graceful shutdown)
   */
  stopCleanupInterval() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }

  /**
   * Check if user is in specific state
   */
  isInState(userId: number, step: UserStateStep): boolean {
    const state = this.states.get(userId);
    return state?.step === step;
  }

  /**
   * Check if user is in any of given states
   */
  isInAnyState(userId: number, steps: UserStateStep[]): boolean {
    const state = this.states.get(userId);
    return state ? steps.includes(state.step) : false;
  }

  /**
   * Check if user is idle (no active state)
   */
  isIdle(userId: number): boolean {
    const state = this.states.get(userId);
    return !state || state.step === UserStateStep.IDLE;
  }

  /**
   * Debug: Print state for user (for debugging)
   */
  debugState(userId: number): string {
    const state = this.states.get(userId);
    
    if (!state) {
      return `No state for user ${userId}`;
    }
    
    const createdAgo = state.createdAt ? Date.now() - state.createdAt : 0;
    const lastInteractionAgo = state.lastInteractionAt ? Date.now() - state.lastInteractionAt : 0;
    
    return `User ${userId}:
  Step: ${state.step}
  Created: ${(createdAgo / 1000).toFixed(1)}s ago
  Last interaction: ${(lastInteractionAgo / 1000).toFixed(1)}s ago
  Temp data: ${JSON.stringify(state.temp, null, 2)}`;
  }
}

// Singleton instance
export const userStateManager = new UserStateManager();

/**
 * State transition validator
 * Membantu prevent invalid state transitions
 */
export class StateTransitionValidator {
  private validTransitions: Map<UserStateStep, UserStateStep[]> = new Map([
    // From IDLE, user can start login atau add session
    [UserStateStep.IDLE, [
      UserStateStep.PHONE_LOGIN_NUMBER,
      UserStateStep.ADD_SESSION_STRING,
    ]],
    
    // Phone login flow
    [UserStateStep.PHONE_LOGIN_NUMBER, [UserStateStep.PHONE_LOGIN_CODE]],
    [UserStateStep.PHONE_LOGIN_CODE, [UserStateStep.PHONE_LOGIN_PASSWORD, UserStateStep.ASK_BUYER_ID]],
    [UserStateStep.PHONE_LOGIN_PASSWORD, [UserStateStep.ASK_BUYER_ID]],
    [UserStateStep.ASK_BUYER_ID, [UserStateStep.ASK_SUBSCRIPTION]],
    
    // Session flow
    [UserStateStep.ADD_SESSION_STRING, [UserStateStep.ASK_BUYER_ID_SESSION]],
    [UserStateStep.ASK_BUYER_ID_SESSION, [UserStateStep.ASK_SUBSCRIPTION_SESSION]],
    [UserStateStep.ASK_SUBSCRIPTION, [UserStateStep.IDLE]],
    [UserStateStep.ASK_SUBSCRIPTION_SESSION, [UserStateStep.IDLE]],
    
    // Settings flows (all can go back to IDLE)
    [UserStateStep.SET_REG_TEXT, [UserStateStep.IDLE]],
    [UserStateStep.SET_WATERMARK, [UserStateStep.IDLE]],
    [UserStateStep.AWAIT_FORWARD, [UserStateStep.IDLE]],
  ]);

  isValidTransition(from: UserStateStep, to: UserStateStep): boolean {
    const validTargets = this.validTransitions.get(from);
    return validTargets ? validTargets.includes(to) : true; // Allow if not restricted
  }

  getValidNextStates(currentState: UserStateStep): UserStateStep[] {
    return this.validTransitions.get(currentState) || [UserStateStep.IDLE];
  }
}

export const stateValidator = new StateTransitionValidator();
