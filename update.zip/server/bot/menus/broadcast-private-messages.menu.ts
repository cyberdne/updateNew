import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendBroadcastPrivateMessagesMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const settings = userbot.settings.broadcastPrivateMessages;
  const statusEmoji = settings?.enabled ? ICONS.online : ICONS.offline;
  const msgEmoji = settings?.message ? ICONS.success : ICONS.warning;

  const text = `${ICONS.send} <b>💬 BROADCAST PRIVATE MESSAGES</b>
${Format.divider(50)}

${Format.item(1, `${ICONS.bot} Userbot`, Format.bold(userbot.label))}

<b>ℹ️ FEATURE CAPABILITIES</b>
${Format.item(1, 'Function', 'Broadcast pesan ke semua user DM')}
${Format.item(1, 'Target', 'Semua user yang pernah interaksi')}
${Format.item(1, 'Scope', '📨 Direct messages (PM) only', true)}

<b>📊 CONFIGURATION STATUS</b>
${Format.item(1, 'Status', `${statusEmoji} ${settings?.enabled ? '✅ Aktif' : '❌ Nonaktif'}`)}
${Format.item(1, 'Message', `${msgEmoji} ${settings?.message ? 'Tersimpan' : 'Belum Diset'}`)}
${Format.item(1, 'Targets', Format.bold((settings?.targetCount || 0).toString()), true)}

<b>🔄 CARA KERJA</b>
${Format.item(1, '1️⃣ Set Pesan', 'Tentukan pesan yang akan dikirim')}
${Format.item(1, '2️⃣ Enable', 'Aktifkan fitur broadcast PM')}
${Format.item(1, '3️⃣ Send', 'Klik "Send Now" untuk broadcast')}
${Format.item(1, '✅ Done', 'Bot kirim ke semua DM target', true)}

<b>⚠️ IMPORTANT WARNINGS</b>
${Format.item(1, '🚨 All DMs', Format.bold('Akan mengirim ke SEMUA DM!'))}
${Format.item(1, '⛔ Risk', 'Gunakan bijak untuk hindari ban Telegram')}
${Format.item(1, '⏱️ Delay', 'Sangat recommend pakai delay antar pesan')}
${Format.item(1, '🔴 Caution', 'Spam = akun banned permanent!', true)}

<b>💡 BEST PRACTICES</b>
${Format.item(1, '📊 Frequency', 'Jangan broadcast terlalu sering')}
${Format.item(1, '✍️ Content', 'Pesan relevan & bermanfaat')}
${Format.item(1, '📉 Limit', 'Batasi jumlah user per broadcast', true)}

${Format.divider(50)}
<i>⚡ Fitur powerful namun dangerous - gunakan dengan bijak!</i>`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(settings?.enabled ? `${ICONS.failed} Disable` : `${ICONS.success} Enable`, `action:toggle_bpm:${id}`)],
    [Markup.button.callback('📝 Set Message', `input:bpm_message:${id}`)],
    [Markup.button.callback(`${ICONS.rocket} Send Now`, `action:execute_bpm:${id}`)],
    [Markup.button.callback(`${ICONS.back} Back`, `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
