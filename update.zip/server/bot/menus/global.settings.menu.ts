import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS, StatusFormatter } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendGlobalSettingsMenu(ctx: Context) {
  const settings = await jsonDb.getGlobalSettings();

  const watermarkPreview = settings.defaultWatermark 
    ? Format.code(settings.defaultWatermark.substring(0, 25) + (settings.defaultWatermark.length > 25 ? '...' : ''))
    : Format.italic('Not set');

  const timezoneDisplay = settings.timezone ? Format.code(settings.timezone) : Format.italic('⚠️ Not set');

  const text = `${ICONS.settings} <b>⚙️ GLOBAL BOT SETTINGS</b>
${Format.divider(50)}

<b>🌍 SERVER CONFIGURATION</b>
${Format.item(1, 'Timezone', timezoneDisplay)}
${Format.item(1, 'Purpose', Format.italic('Untuk timer semua userbot'), true)}

<b>⏱️ DEFAULT DELAYS</b>
${Format.item(1, 'Instant Loop', `<b>${settings.defaultInstantDelay}s</b>`)}
${Format.item(1, 'Sequential', `<b>${settings.defaultSequentialDelay}s</b>`)}
${Format.item(1, 'Auto Join', `<b>${settings.autoJoinDelay}ms</b>`, true)}

<b>📝 DEFAULT MESSAGE</b>
${Format.item(1, 'Watermark', watermarkPreview)}
${Format.item(1, 'Premium Emoji', StatusFormatter.feature(settings.defaultPremiumEmoji), true)}

<b>🎯 TARGET MANAGEMENT</b>
${Format.item(1, 'Max per Userbot', `<b>${settings.maxTargetsPerUserbot}</b> grup`)}
${Format.item(1, 'Blacklist Size', `<b>${settings.globalBlacklist.length}</b> chat`, true)}

<b>🛡️ SECURITY & ANTI-SPAM</b>
${Format.item(1, 'Join Cooldown', `<b>${settings.antiSpamCooldown}</b>`)}
${Format.item(1, 'FloodWait Multiplier', `<b>×${settings.floodWaitMultiplier}</b>`, true)}

${Format.divider(50)}
<i>💡 Pengaturan global berlaku untuk semua userbot.</i>`;

  const timezoneButtonText = settings.timezone 
    ? `${ICONS.world} 🔄 Timezone: ${settings.timezone.split('/')[1] || settings.timezone.split('/')[0]}`
    : `${ICONS.world} ⚡ Set Timezone`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(timezoneButtonText, 'global:set_timezone')],
    [
      Markup.button.callback(`${ICONS.timer} Instant`, 'global:instant_delay'),
      Markup.button.callback(`${ICONS.timer} Sequential`, 'global:seq_delay')
    ],
    [
      Markup.button.callback(`${ICONS.target} Max Targets`, 'global:max_targets'),
      Markup.button.callback(`${ICONS.timer} Join Delay`, 'global:join_delay')
    ],
    [
      Markup.button.callback('📝 Set WM', 'global:set_watermark'),
      Markup.button.callback(`${ICONS.delete} Clear WM`, 'global:clear_watermark')
    ],
    [
      Markup.button.callback(settings.defaultPremiumEmoji ? `${ICONS.failed} Disable Emoji` : `✨ Enable Emoji`, 'global:toggle_premium_emoji')
    ],
    [
      Markup.button.callback(`${ICONS.plus} Add BL`, 'global:add_blacklist'),
      Markup.button.callback(`${ICONS.delete} Clear BL`, 'global:clear_blacklist')
    ],
    [Markup.button.callback(`${ICONS.back} Back`, 'home')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
