import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendBotBroadcastMenu(ctx: Context) {
  const db = await jsonDb.read();
  const bcSettings = db.botBroadcast || {
    mode: 'CHANNEL',
    targets: [],
    message: null,
    lastBroadcastAt: null
  };
  
  const statusEmoji = bcSettings.message ? ICONS.success : ICONS.warning;
  const lastBroadcast = bcSettings.lastBroadcastAt ? new Date(bcSettings.lastBroadcastAt).toLocaleString('id-ID') : 'Never';

  const text = `${ICONS.broadcast} <b>📢 BOT BROADCAST MANAGER</b>
${Format.divider(50)}

<b>⚙️ BROADCAST CONFIGURATION</b>
${Format.item(1, 'Mode', Format.bold(bcSettings.mode))}
${Format.item(1, 'Targets', Format.bold(bcSettings.targets?.length.toString() || '0'))}
${Format.item(1, 'Message', `${statusEmoji} ${bcSettings.message ? 'Tersimpan' : 'Belum Diset'}`)}
${Format.item(1, 'Last BC', lastBroadcast, true)}

<b>📋 BROADCAST MODES</b>
${Format.item(1, '📢 Channel Mode', 'Broadcast ke channel-channel')}
${Format.item(1, '👥 Group Mode', 'Broadcast ke group-group')}
${Format.item(1, '💬 PM Mode', 'Broadcast ke private messages', true)}

<b>🚀 SETUP INSTRUCTIONS</b>
${Format.item(1, '1️⃣ Select', 'Pilih broadcast mode (Channel/Group/PM)')}
${Format.item(1, '2️⃣ Add Targets', 'Tambah targets (user ID atau username)')}
${Format.item(1, '3️⃣ Set Message', 'Tentukan pesan yang akan dikirim')}
${Format.item(1, '4️⃣ Execute', 'Klik "Start Broadcast" untuk mulai', true)}

<b>⚡ FEATURES</b>
${Format.item(1, '🎯 Target', 'Unlimited target per broadcast')}
${Format.item(1, '💬 Message', 'Simpan & reuse message template')}
${Format.item(1, '📊 Progress', 'Real-time broadcast progress tracking')}
${Format.item(1, '📈 Report', 'Detail report setelah broadcast', true)}

${Format.divider(50)}
<i>💡 Bot akan mengirim pesan ke semua target yang sudah dikonfigurasi.</i>`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('📢 Channel', 'botbc:mode:CHANNEL'),
      Markup.button.callback('👥 Group', 'botbc:mode:GROUP'),
      Markup.button.callback('💬 PM', 'botbc:mode:PM')
    ],
    [
      Markup.button.callback(`${ICONS.plus} Add Target`, 'botbc:add_target'),
      Markup.button.callback('📋 List Targets', 'botbc:list_targets')
    ],
    [
      Markup.button.callback('✏️ Set Message', 'botbc:set_message'),
      Markup.button.callback(`${ICONS.delete} Clear Targets`, 'botbc:clear_targets')
    ],
    [Markup.button.callback(`${ICONS.rocket} Start Broadcast`, 'botbc:start')],
    [Markup.button.callback(`${ICONS.back} Back`, 'home')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
