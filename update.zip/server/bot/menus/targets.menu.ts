import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendTargetsMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const targets = userbot.settings.targets;
  const totalTargets = targets.length;
  const failedTargets = targets.filter(t => (t.failCount || 0) > 2).length;
  const healthyTargets = totalTargets - failedTargets;
  const maxTargets = db.globalSettings?.maxTargetsPerUserbot || 500;
  const usagePercent = totalTargets > 0 ? Math.round((totalTargets / maxTargets) * 100) : 0;
  
  const recentTargets = targets.slice(-5).reverse().map((t, i) => {
    const failBadge = (t.failCount || 0) > 2 ? ` ${ICONS.warning}` : '';
    const statusIcon = (t.failCount || 0) > 2 ? ICONS.warning : ICONS.success;
    return `  ${i + 1}. ${statusIcon} ${t.title || t.username || t.chatId}${failBadge}`;
  }).join('\n');

  const text = `${ICONS.target} <b>🎯 TARGET MANAGEMENT CENTER</b>
${Format.divider(50)}

${Format.item(1, `${ICONS.bot} Userbot`, Format.bold(userbot.label))}

<b>📊 TARGET ANALYTICS</b>
${Format.item(1, `${ICONS.send} Total Groups`, `<b>${totalTargets}</b>/<code>${maxTargets}</code>`)}
${Format.item(1, `${ICONS.success} Healthy`, `<b>${healthyTargets}</b> grup`)}
${Format.item(1, `${ICONS.warning} Failed`, `<b>${failedTargets}</b> grup`)}
${Format.item(1, `📈 Usage Quota`, `<b>${usagePercent}%</b> ${Format.progressBar(totalTargets, maxTargets, 15)}`, true)}

${totalTargets > 0 ? `
<b>🕐 RECENT TARGETS</b>
${recentTargets}
` : `<i>Belum ada target ditambahkan ke userbot ini.</i>`}

${Format.divider(50)}
<b>📱 SCAN OPTIONS:</b>
• <b>Scan My Groups</b> - Auto scan semua grup yang userbot sudah join
• <b>Scan Channel</b> - Scan channel tertentu untuk cari link grup
• <b>Search Groups</b> - Cari grup baru di Telegram dengan keyword
${Format.divider(50)}`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback(`${ICONS.plus} Add Target`, `menu:target_add:${id}`),
      Markup.button.callback(`${ICONS.refresh} Refresh`, `menu:targets:${id}`)
    ],
    [
      Markup.button.callback('📱 Scan My Groups', `action:scan_groups:${id}`),
      Markup.button.callback(`${ICONS.scan} Scan Channel`, `menu:scan_channel:${id}`)
    ],
    [
      Markup.button.callback('🔎 Search Groups', `menu:search_group:${id}`),
      Markup.button.callback('🔗 Join From List', `menu:join_list:${id}`)
    ],
    [
      Markup.button.callback(`${ICONS.delete} Clear All`, `action:clear_targets:${id}`)
    ],
    [Markup.button.callback(`${ICONS.back} Back`, `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
