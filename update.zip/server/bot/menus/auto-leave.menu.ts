import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendAutoLeaveMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const settings = userbot.settings.autoLeave;
  const statusEmoji = settings?.enabled ? ICONS.online : ICONS.offline;

  const text = `${ICONS.export} <b>👋 AUTO LEAVE GROUPS</b>
${Format.divider(50)}

${Format.item(1, `${ICONS.bot} Userbot`, Format.bold(userbot.label))}

<b>ℹ️ FEATURE DESCRIPTION</b>
${Format.item(1, 'Function', 'Otomatis keluar dari grup sesuai durasi')}
${Format.item(1, 'Purpose', 'Manage group membership lifecycle')}
${Format.item(1, 'Trigger', '⏱️ Time-based automatic departure', true)}

<b>📊 CONFIGURATION STATUS</b>
${Format.item(1, 'Status', `${statusEmoji} ${settings?.enabled ? '✅ Aktif' : '❌ Nonaktif'}`)}
${Format.item(1, 'Leave After', `<b>${(settings?.leaveAfterDays || 1)}</b> hari`)}
${Format.item(1, 'Total Left', Format.bold((settings?.leftCount || 0).toString()), true)}

<b>🔄 CARA KERJA</b>
${Format.item(1, '1️⃣ Monitor', 'Bot monitor semua grup yang diikuti')}
${Format.item(1, '2️⃣ Check', 'Check waktu joined di setiap grup')}
${Format.item(1, '3️⃣ Leave', 'Otomatis keluar jika melewati durasi')}
${Format.item(1, '📝 Log', 'Catat semua grup yang sudah left', true)}

<b>💡 USE CASES</b>
${Format.item(1, '🧹 Cleanup', 'Otomatis bersihkan grup expired')}
${Format.item(1, '📊 Management', 'Auto manage group membership')}
${Format.item(1, '✨ Efficiency', 'Kurangi clutter dari group list', true)}

<b>⚠️ IMPORTANT NOTES</b>
${Format.item(1, '📌 Remember', 'Jangan lupa re-join grup jika perlu')}
${Format.item(1, '⚙️ Automatic', 'Pengaturan bersifat otomatis & permanent')}
${Format.item(1, '🔴 Recovery', 'Tidak bisa di-undo - hati-hati konfigurasi', true)}

${Format.divider(50)}
<i>💡 Gunakan untuk maintain clean group list dari inactive groups.</i>`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(settings?.enabled ? `${ICONS.failed} Disable` : `${ICONS.success} Enable`, `action:toggle_auto_leave:${id}`)],
    [Markup.button.callback('⏱️ Set Days', `input:auto_leave_days:${id}`)],
    [Markup.button.callback(`${ICONS.rocket} Execute Now`, `action:execute_auto_leave:${id}`)],
    [Markup.button.callback(`${ICONS.back} Back`, `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
