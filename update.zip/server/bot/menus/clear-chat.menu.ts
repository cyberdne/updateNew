import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendClearChatMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const settings = userbot.settings.clearChat;
  const statusEmoji = settings?.enabled ? ICONS.online : ICONS.offline;
  const groupEmoji = settings?.clearGroups ? ICONS.success : ICONS.failed;
  const pmEmoji = settings?.clearPrivate ? ICONS.success : ICONS.failed;

  const text = `${ICONS.delete} <b>🗑️ CLEAR CHAT MESSAGES</b>
${Format.divider(50)}

${Format.item(1, `${ICONS.bot} Userbot`, Format.bold(userbot.label))}

<b>ℹ️ FEATURE DESCRIPTION</b>
${Format.item(1, 'Function', 'Otomatis menghapus pesan dari grup & PM')}
${Format.item(1, 'Purpose', 'Auto cleanup messages berdasarkan durasi')}
${Format.item(1, 'Trigger', '⏱️ Time-based automatic deletion', true)}

<b>📊 CONFIGURATION STATUS</b>
${Format.item(1, 'Status', `${statusEmoji} ${settings?.enabled ? '✅ Aktif' : '❌ Nonaktif'}`)}
${Format.item(1, 'Clear Groups', `${groupEmoji} ${settings?.clearGroups ? 'Enabled' : 'Disabled'}`)}
${Format.item(1, 'Clear Private', `${pmEmoji} ${settings?.clearPrivate ? 'Enabled' : 'Disabled'}`)}
${Format.item(1, 'Total Deleted', Format.bold((settings?.deletedCount || 0).toString()), true)}

<b>🔄 CARA KERJA</b>
${Format.item(1, '1️⃣ Monitor', 'Bot monitor pesan di chat')}
${Format.item(1, '2️⃣ Check Age', 'Check umur setiap pesan')}
${Format.item(1, '3️⃣ Delete', 'Otomatis delete jika sudah old enough')}
${Format.item(1, '📝 Log', 'Log semua deleted messages', true)}

<b>💡 USE CASES & BENEFITS</b>
${Format.item(1, '🔐 Privacy', 'Auto delete messages untuk privacy')}
${Format.item(1, '✨ Cleanup', 'Keep chat tetap clean & organized')}
${Format.item(1, '💾 Storage', 'Reduce storage dengan auto cleanup')}
${Format.item(1, '⚖️ Compliance', 'Auto comply dengan data retention policy', true)}

<b>🔴 CRITICAL WARNINGS</b>
${Format.item(1, Format.bold('⚠️ PERMANENT'), 'SEMUA PENGHAPUSAN BERSIFAT PERMANENT!')}
${Format.item(1, '🚫 NO RECOVERY', 'Tidak bisa dikembalikan setelah dihapus')}
${Format.item(1, '⛔ CAUTION', 'Gunakan dengan SANGAT hati-hati')}
${Format.item(1, '❌ IRREVERSIBLE', 'Double-check sebelum enable!', true)}

<b>📋 CONFIGURATION TIPS</b>
${Format.item(1, '📅 Hari', 'Set berapa hari sebelum pesan dihapus')}
${Format.item(1, '🎯 Target', 'Pilih grup & PM sesuai kebutuhan')}
${Format.item(1, '✅ Test', 'Test di small group dulu before production', true)}

${Format.divider(50)}
${Format.bold('🔴 WARNING: Penghapusan TIDAK BISA DIBATALKAN! Pastikan Anda YAKIN!')}`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(settings?.enabled ? `${ICONS.failed} Disable All` : `${ICONS.success} Enable All`, `action:toggle_clear_chat:${id}`)],
    [
      Markup.button.callback(settings?.clearGroups ? `✅ Groups` : `⬜ Groups`, `action:toggle_clear_groups:${id}`),
      Markup.button.callback(settings?.clearPrivate ? `✅ Private` : `⬜ Private`, `action:toggle_clear_private:${id}`)
    ],
    [Markup.button.callback('📅 Set Days Before Delete', `input:clear_chat_days:${id}`)],
    [Markup.button.callback(`${ICONS.rocket} Execute Now`, `action:execute_clear_chat:${id}`)],
    [Markup.button.callback(`${ICONS.back} Back`, `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
