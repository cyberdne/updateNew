import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendAutoPilotMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const autoPilot = userbot.autoPilot || { enabled: false, scanLinks: false, autoJoin: false, joinedCount: 0, lastScanAt: 0 };
  const statusEmoji = autoPilot.enabled ? ICONS.online : ICONS.offline;
  const scanEmoji = autoPilot.scanLinks ? ICONS.success : ICONS.failed;
  const joinEmoji = autoPilot.autoJoin ? ICONS.success : ICONS.failed;
  const lastScan = autoPilot.lastScanAt ? new Date(autoPilot.lastScanAt).toLocaleString('id-ID') : 'Never';

  const text = `${ICONS.rocket} <b>🤖 AUTO PILOT MODE</b>
${Format.divider(50)}

${Format.item(1, `${ICONS.bot} Userbot`, Format.bold(userbot.label))}

<b>📊 ACTIVE FEATURES</b>
${Format.item(1, 'Auto Pilot', `${statusEmoji} ${autoPilot.enabled ? '✅ Aktif' : '❌ Nonaktif'}`)}
${Format.item(1, 'Link Scanning', `${scanEmoji} ${autoPilot.scanLinks ? '🔍 Aktif' : '❌ Nonaktif'}`)}
${Format.item(1, 'Auto Join', `${joinEmoji} ${autoPilot.autoJoin ? '🔗 Aktif' : '❌ Nonaktif'}`, true)}

<b>📈 STATISTICS</b>
${Format.item(1, 'Groups Joined', Format.bold(autoPilot.joinedCount.toString()))}
${Format.item(1, 'Last Scan', lastScan, true)}

<b>🔄 CARA KERJA AUTO PILOT</b>
${Format.item(1, '1️⃣ Broadcast', 'Bot broadcast pesan ke semua target')}
${Format.item(1, '2️⃣ Scan', 'Scan chat target & cari link grup baru')}
${Format.item(1, '3️⃣ Join', 'Otomatis join grup baru yang ditemukan')}
${Format.item(1, '4️⃣ Expand', 'Tambahkan ke target untuk BC berikutnya', true)}

<b>💡 POWER FEATURES</b>
${Format.item(1, '🚀 Reach', 'Perluas jangkauan broadcast otomatis')}
${Format.item(1, '⏰ Efficiency', 'Hemat waktu setup target manual')}
${Format.item(1, '🧠 Smart', 'Intelligent link detection & auto-join', true)}

<b>🎯 ADVANTAGES</b>
${Format.item(1, '📈 Exponential', 'Target growth otomatis & berkelanjutan')}
${Format.item(1, '⚡ Fast', 'Expansion super cepat tanpa manual')}
${Format.item(1, '🔐 Reliable', 'Join dengan smart error handling', true)}

${Format.divider(50)}
<i>⚡ Auto Pilot adalah fitur paling powerful untuk ekspansi otomatis reach!</i>`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(autoPilot.enabled ? '⏸️ Nonaktifkan' : '▶️ Aktifkan', `autopilot:toggle:${id}`)],
    [
      Markup.button.callback(autoPilot.scanLinks ? '🔍 Scan: ON' : '🔍 Scan: OFF', `autopilot:scan:${id}`),
      Markup.button.callback(autoPilot.autoJoin ? '🔗 Join: ON' : '🔗 Join: OFF', `autopilot:join:${id}`)
    ],
    [Markup.button.callback('🔄 Reset Stats', `autopilot:reset:${id}`)],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
