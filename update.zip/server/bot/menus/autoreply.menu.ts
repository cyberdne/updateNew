import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendAutoReplyMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const autoReply = userbot.autoReplyKeyword || { enabled: false, keywords: [], useForward: false };
  const statusEmoji = autoReply.enabled ? ICONS.online : ICONS.offline;
  const modeEmoji = autoReply.useForward ? '🔄' : '📝';
  const modeText = autoReply.useForward ? 'Forward Mode' : 'Text Reply';

  const keywordList = autoReply.keywords.length > 0 
    ? autoReply.keywords.slice(0, 8).map((k, i) => `${i + 1}. ${Format.code(k)}`).join('\n')
    : Format.italic('(No keywords set)');
  
  const totalKeywords = autoReply.keywords.length;

  const text = `${ICONS.chat} <b>💬 AUTO-REPLY KEYWORD</b>
${Format.divider(50)}

${Format.item(1, `${ICONS.bot} Userbot`, Format.bold(userbot.label))}

<b>📊 FEATURE STATUS</b>
${Format.item(1, 'Status', `${statusEmoji} ${autoReply.enabled ? '✅ Aktif' : '❌ Nonaktif'}`)}
${Format.item(1, 'Reply Mode', `${modeEmoji} ${modeText}`)}
${Format.item(1, 'Keywords', Format.bold(totalKeywords.toString()), true)}

<b>🔑 ACTIVE KEYWORDS</b>
${keywordList}
${totalKeywords > 8 ? `${Format.italic(`...and ${totalKeywords - 8} more`)}` : ''}

<b>💬 REPLY TEMPLATE</b>
${Format.item(1, 'Content', autoReply.replyText ? Format.code(autoReply.replyText.substring(0, 40) + '...') : Format.italic('Default Telegram message'), true)}

<b>🔄 CARA KERJA</b>
${Format.item(1, '1️⃣ Terima', 'Bot menerima pesan dengan keyword')}
${Format.item(1, '2️⃣ Deteksi', 'Sistem mencocokan dengan keywords')}
${Format.item(1, '3️⃣ Balas', autoReply.useForward ? 'Forward pesan original' : 'Kirim text reply', true)}

<b>✨ USE CASES</b>
${Format.item(1, '🛟 Support', 'Automated customer service')}
${Format.item(1, '❓ FAQ', 'Quick answers otomatis', true)}

${Format.divider(50)}
<i>💡 Peraturan Telegram: Gunakan dengan bijak untuk menghindari spam.</i>`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(autoReply.enabled ? '⏸️ Nonaktifkan' : '▶️ Aktifkan', `autoreply:toggle:${id}`)],
    [
      Markup.button.callback('➕ Add Keyword', `autoreply:add_keyword:${id}`),
      Markup.button.callback('🗑️ Clear KW', `autoreply:clear_keywords:${id}`)
    ],
    [
      Markup.button.callback('📝 Set Teks Reply', `autoreply:set_text:${id}`),
      Markup.button.callback(autoReply.useForward ? '📝 Pakai Teks' : '🔄 Pakai Forward', `autoreply:toggle_forward:${id}`)
    ],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
