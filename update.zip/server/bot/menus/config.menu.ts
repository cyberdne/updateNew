import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendConfigMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const { settings } = userbot;
  const msgTypeStatus = settings.messageType === 'FORWARD' ? 'Forward Pesan' : 'Teks Manual';
  const spreadStatus = settings.spreadMode === 'INSTANT' ? 'Paralel (Cepat)' : 'Sequential (Aman)';
  const wmStatus = settings.watermarkText ? `Aktif: ${settings.watermarkText}` : 'Tidak Diset';
  const wmEmoji = settings.watermarkText ? ICONS.success : ICONS.warning;
  
  // Define icons for buttons
  const msgTypeIcon = settings.messageType === 'FORWARD' ? ICONS.refresh : ICONS.send;
  const modeIcon = settings.spreadMode === 'INSTANT' ? '⚡' : '🐢';

  const text = `${ICONS.config} <b>⚙️ BROADCAST CONFIGURATION</b>
${Format.divider(50)}

${Format.item(1, `${ICONS.bot} Userbot`, Format.bold(userbot.label))}

<b>📨 MESSAGE TYPE CONFIGURATION</b>
${Format.item(1, 'Mode', `🔄 ${Format.bold(msgTypeStatus)}`)}
${Format.item(1, 'Deskripsi', settings.messageType === 'FORWARD' ? 'Pesan di-forward dari sumber asli' : 'Mengirim pesan teks biasa')}
${Format.item(1, 'Keuntungan', settings.messageType === 'FORWARD' ? 'Menjaga format & metadata' : 'Lebih fleksibel & cepat', true)}

<b>🚀 SPREAD MODE CONFIGURATION</b>
${Format.item(1, 'Mode', `⚡ ${Format.bold(spreadStatus)}`)}
${Format.item(1, 'Kecepatan', settings.spreadMode === 'INSTANT' ? 'Sangat Cepat' : 'Sedang-Lambat')}
${Format.item(1, 'Risiko Ban', settings.spreadMode === 'INSTANT' ? '🔴 Tinggi (Recommend: Pakai Delay)' : '🟢 Rendah (Aman)', true)}

<b>⏱️ DELAY CONFIGURATION</b>
${Format.item(1, 'Instant Loop Delay', `${Format.code(settings.delays.instantLoopDelaySec + 's')}`)}
${Format.item(2, 'Detail', 'Jeda antar loop broadcast', true)}
${Format.item(1, 'Sequential Delay', `${Format.code(settings.delays.sequentialPerGroupDelaySec + 's')}`)}
${Format.item(2, 'Detail', 'Jeda antar pesan per grup', true)}

<b>📝 WATERMARK SETTINGS</b>
${Format.item(1, 'Status', `${wmEmoji} ${wmStatus}`)}
${Format.item(1, 'Fungsi', 'Tanda identitas di akhir pesan', true)}

<b>💡 TIPS & BEST PRACTICES</b>
${Format.item(1, '⚡ Fast', 'INSTANT mode cepat tapi risko ban')}
${Format.item(1, '🟢 Safe', 'SEQUENTIAL lebih aman dengan delay')}
${Format.item(1, '📊 Balance', 'Kombinasi optimal untuk hasil terbaik', true)}

${Format.divider(50)}
<i>⚙️ Pengaturan ini berpengaruh pada kecepatan & keamanan broadcast Anda.</i>`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback(`${msgTypeIcon} ${settings.messageType}`, `action:toggle_msg_type:${id}`),
      Markup.button.callback(`${modeIcon} ${settings.spreadMode}`, `action:toggle_spread_mode:${id}`)
    ],
    [
      Markup.button.callback('⏱️ Instant Delay', `input:instant_delay:${id}`),
      Markup.button.callback('⏱️ Seq Delay', `input:seq_delay:${id}`)
    ],
    [
      Markup.button.callback('📝 Set Watermark', `input:watermark:${id}`),
      Markup.button.callback('🗑️ Hapus WM', `action:clear_watermark:${id}`)
    ],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
