import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS, StatusFormatter } from '../utils/format.util';
import { jsonDb } from '../../storage/db';
import { liveEvents } from '../../utils/live-events';

export async function sendUserbotControlMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);

  if (!userbot) {
    return ctx.answerCbQuery('Userbot tidak ditemukan');
  }

  const { status, subscription, settings, stats } = userbot;
  const isRunning = status === 'RUNNING';
  const isExpired = subscription.expireAt < Date.now();
  const daysLeft = Math.ceil((subscription.expireAt - Date.now()) / (24 * 60 * 60 * 1000));
  
  // Get live broadcast progress if running
  const liveProgress = isRunning ? liveEvents.getBroadcastProgress(id) : null;
  
  const msgTypeIcon = settings.messageType === 'FORWARD' ? ICONS.refresh : ICONS.send;
  const hasMessage = settings.messageType === 'FORWARD' 
    ? (settings.forwardedMessage?.messageIds?.length || settings.forwardConfig?.messageIds?.length)
    : !!settings.regularText;
  
  let statsSection = `<b>📊 STATISTICS</b>
${Format.item(1, 'Sent', Format.bold(Format.number(stats.sent)))}
${Format.item(1, 'Failed', stats.failed.toString())}
${Format.item(1, 'Skipped', stats.skipped.toString())}
${Format.item(1, 'Last Error', stats.lastError ? Format.code(stats.lastError.substring(0, 30)) : '-', true)}`;

  if (liveProgress && liveProgress.status === 'running') {
    const progressBar = createProgressBar(liveProgress.percentComplete, 15);
    statsSection += `

<b>🔴 LIVE BROADCAST</b>
${progressBar} ${liveProgress.percentComplete}%
${Format.item(1, 'Progress', `${liveProgress.currentIndex}/${liveProgress.totalTargets}`)}
${Format.item(1, 'Sent Now', Format.bold(liveProgress.sent.toString()))}
${Format.item(1, 'Failed', liveProgress.failed.toString())}
${Format.item(1, 'Current', liveProgress.currentTarget ? Format.code(liveProgress.currentTarget.substring(0, 30)) : 'Starting', true)}`;
  }
  
  const text = `${ICONS.bot} <b>USERBOT — Kontrol & Informasi</b>
<i>Panel singkat untuk mengelola dan memantau userbot ini</i>
${Format.divider(50)}

<b>📋 BASIC INFORMATION</b>
${Format.item(1, 'Label', Format.bold(userbot.label))}
${Format.item(1, 'Buyer ID', Format.code(userbot.buyerId))}
${Format.item(1, 'Status', StatusFormatter.userbot(status))}
${Format.item(1, 'Subscription', subscription.active && !isExpired ? `✅ ${daysLeft} days left` : `❌ EXPIRED`, true)}

<b>⚙️ Pengaturan Broadcast</b>
${Format.item(1, 'Tipe Pesan', `${msgTypeIcon} ${Format.bold(settings.messageType)}`)}
${Format.item(1, 'Mode Penyebaran', Format.bold(settings.spreadMode))}
${Format.item(1, 'Pesan', hasMessage ? `${ICONS.success} Tersedia` : `${ICONS.failed} Belum diset`)}
${Format.item(1, 'Jumlah Targets', Format.bold(settings.targets.length.toString()))}
${Format.item(1, 'Timer', settings.timer.enabled ? `✅ ${settings.timer.startAt} - ${settings.timer.stopAt}` : `❌ Mati`)}
${Format.item(1, 'Watermark', settings.watermarkText ? ICONS.success : ICONS.failed, true)}

<b>✨ PREMIUM FEATURES</b>
${Format.item(1, 'Premium Emoji', StatusFormatter.feature(settings.premiumEmoji))}
${Format.item(1, 'PM Permit', StatusFormatter.feature(userbot.pmPermit.enabled))}
${Format.item(1, 'Auto Reply', StatusFormatter.feature(userbot.autoReplyKeyword?.enabled))}
${Format.item(1, 'Auto Pilot', StatusFormatter.feature(userbot.autoPilot?.enabled), true)}

${statsSection}

${Format.divider(50)}`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback(isRunning ? `${ICONS.failed} Stop` : `${ICONS.success} Start`, isRunning ? `action:stop:${id}` : `action:start:${id}`),
      Markup.button.callback(`${ICONS.refresh} Refresh`, `userbot:${id}`)
    ],
    [
      Markup.button.callback(`${ICONS.send} Regular Text`, `menu:set_reg_text:${id}`),
      Markup.button.callback(`${ICONS.refresh} Forward`, `menu:set_fwd_text:${id}`)
    ],
    [
      Markup.button.callback(`${ICONS.target} Targets`, `menu:targets:${id}`),
      Markup.button.callback(`${ICONS.timer} Timer`, `menu:timer:${id}`)
    ],
    [
      Markup.button.callback(`${ICONS.config} Config`, `menu:config:${id}`),
      Markup.button.callback('🛡️ PM Permit', `menu:pmpermit:${id}`)
    ],
    [
      Markup.button.callback(`${ICONS.stats} Account Info`, `menu:userbot_info:${id}`)
    ],
    [
      Markup.button.callback('💬 Auto Reply', `menu:autoreply:${id}`),
      Markup.button.callback(`${ICONS.rocket} Auto Pilot`, `menu:autopilot:${id}`)
    ],
    [
      Markup.button.callback(`${ICONS.send} Broadcast PM`, `menu:bpm:${id}`),
      Markup.button.callback('👋 Auto Leave', `menu:auto_leave:${id}`)
    ],
    [
      Markup.button.callback('👀 Auto Read', `menu:auto_read:${id}`),
      Markup.button.callback(`${ICONS.delete} Clear Chat`, `menu:clear_chat:${id}`)
    ],
    [
      Markup.button.callback(`${ICONS.premium} Premium`, `menu:premium:${id}`),
      Markup.button.callback('💳 Subscription', `menu:subscription:${id}`)
    ],
    [Markup.button.callback(`${ICONS.delete} Delete`, `action:delete:${id}`)],
    [Markup.button.callback(`${ICONS.back} Back`, 'menu:userbots')]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
function createProgressBar(percentage: number, width: number = 20): string {
  const filled = Math.round((percentage / 100) * width);
  const empty = width - filled;
  const bar = '█'.repeat(filled) + '░'.repeat(empty);
  return `[${bar}]`;
}