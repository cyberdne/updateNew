import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendPremiumMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const premiumEnabled = userbot.settings.premiumEmoji || false;
  const statusEmoji = premiumEnabled ? ICONS.success : ICONS.failed;

  const text = `${ICONS.premium} <b>✨ PREMIUM FEATURES</b>
${Format.divider(50)}

${Format.item(1, `${ICONS.bot} Userbot`, Format.bold(userbot.label))}

<b>🎁 PREMIUM EMOJI SUPPORT</b>
${Format.item(1, 'Status', `${statusEmoji} ${premiumEnabled ? '✅ Enabled' : '❌ Disabled'}`, true)}

<b>⭐ PREMIUM FEATURES INCLUDED</b>
${Format.item(1, '🎨 Support', 'Premium emoji Telegram support')}
${Format.item(1, '📎 Preserve', 'Preserve format custom emoji saat forward')}
${Format.item(1, '🖼️ Display', 'Display emoji premium dengan benar')}
${Format.item(1, '🎬 Rich Media', 'Rich media content support', true)}

<b>📋 REQUIREMENTS</b>
${Format.item(1, '👤 Account', 'Userbot harus Telegram Premium subscription')}
${Format.item(1, '🔓 Unlock', 'Feature ini unlock emoji premium')}
${Format.item(1, '✅ Optional', 'Tidak required untuk broadcast normal', true)}

<b>💡 BENEFITS</b>
${Format.item(1, '🌟 Quality', 'Pesan emoji premium lebih menarik')}
${Format.item(1, '💎 Professional', 'Tampilan premium & sophisticated')}
${Format.item(1, '👁️ Reach', 'Emoji banyak = eye-catching maksimal', true)}

${Format.divider(50)}
<i>⚠️ Note: Optimal jika akun userbot sudah Telegram Premium.</i>`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(premiumEnabled ? `${ICONS.failed} Disable Premium` : `${ICONS.success} Enable Premium`, `premium:toggle:${id}`)],
    [Markup.button.callback(`${ICONS.back} Back`, `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
