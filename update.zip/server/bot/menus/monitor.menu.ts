import { Telegraf, Context } from 'telegraf';
import { jsonDb } from '../../storage/db';
import { liveEvents } from '../../utils/live-events';
import { Format, ICONS } from '../utils/format.util';

export function setupMonitorMenu(bot: Telegraf<Context>) {
  // Monitor active broadcasts — tampilan ringkas untuk progress realtime setiap userbot
  bot.action('monitor_active', async (ctx) => {
    try {
      const allBroadcasts = liveEvents.getAllBroadcasts();
      
      if (allBroadcasts.length === 0) {
        return ctx.reply('📊 <b>Tidak ada broadcast aktif</b>\n\n✅ Semua userbot dalam kondisi idle', {
          parse_mode: 'HTML',
        });
      }

      let text = '<b>📊 Active Broadcasts</b>\n\n';
      
      for (const broadcast of allBroadcasts) {
        const db = await jsonDb.read();
        const userbot = db.userbots.find(u => u.id === broadcast.userbotId);
        const label = userbot?.label || broadcast.userbotId;
        
        const progressBar = createProgressBar(broadcast.percentComplete, 20);
        const timeElapsed = Format.timeDiff(Date.now() - broadcast.startedAt);
        const timeRemaining = broadcast.estimatedTimeLeft 
          ? Format.timeDiff(broadcast.estimatedTimeLeft) 
          : '...';
        
        text += `<b>${label}</b>\n`;
        text += `${progressBar} ${broadcast.percentComplete}%\n`;
        text += `📤 Sent: <code>${broadcast.sent}</code> | ❌ Failed: <code>${broadcast.failed}</code> | ⏭️ Skipped: <code>${broadcast.skipped}</code>\n`;
        text += `⏱️ Target: ${broadcast.currentTarget ? `<code>${broadcast.currentTarget}</code>` : '<i>Starting...</i>'}\n`;
        text += `⏰ Elapsed: <code>${timeElapsed}</code> | Remaining: <code>${timeRemaining}</code>\n\n`;
      }

      return ctx.editMessageText(text, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🔄 Refresh', callback_data: 'monitor_active' },
              { text: '📊 Stats', callback_data: 'monitor_stats' }
            ],
            [ { text: '🏠 Kembali', callback_data: 'home' } ]
          ],
        },
      });
    } catch (error: any) {
      ctx.answerCbQuery(`Error: ${error?.message}`, { show_alert: true });
    }
  });

  // Monitor global stats
  bot.action('monitor_stats', async (ctx) => {
    try {
      const db = await jsonDb.read();
      
      const activeBots = db.userbots.filter(u => u.status === 'RUNNING').length;
      const totalBots = db.userbots.length;
      const totalSent = db.userbots.reduce((acc, u) => acc + u.stats.sent, 0);
      const totalFailed = db.userbots.reduce((acc, u) => acc + u.stats.failed, 0);
      const totalTargets = db.userbots.reduce((acc, u) => acc + u.settings.targets.length, 0);
      
      // Get active broadcasts
      const allBroadcasts = liveEvents.getAllBroadcasts();
      const totalRunning = allBroadcasts.length;
      
      let text = '<b>📈 Global System Stats</b>\n\n';
      text += `<b>Bots</b>\n`;
      text += `✅ Active: <code>${activeBots}/${totalBots}</code>\n`;
      text += `🔄 Broadcasts Running: <code>${totalRunning}</code>\n\n`;
      
      text += `<b>Messages</b>\n`;
      text += `📤 Total Sent: <code>${Format.number(totalSent)}</code>\n`;
      text += `❌ Total Failed: <code>${Format.number(totalFailed)}</code>\n`;
      text += `💯 Success Rate: <code>${totalSent + totalFailed > 0 ? ((totalSent / (totalSent + totalFailed)) * 100).toFixed(1) : '0'}%</code>\n\n`;
      
      text += `<b>Targets</b>\n`;
      text += `🎯 Total Configured: <code>${Format.number(totalTargets)}</code>\n`;
      
      const globalBlacklistSize = db.globalSettings?.globalBlacklist?.length || 0;
      text += `🚫 Blacklisted: <code>${Format.number(globalBlacklistSize)}</code>\n\n`;
      
      text += `🕐 Last Update: <code>${new Date().toLocaleTimeString()}</code>`;

      return ctx.editMessageText(text, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [ { text: '🔄 Refresh', callback_data: 'monitor_stats' }, { text: '📊 Broadcasts', callback_data: 'monitor_active' } ],
            [ { text: '🏠 Kembali', callback_data: 'home' } ]
          ],
        },
      });
    } catch (error: any) {
      ctx.answerCbQuery(`Error: ${error?.message}`, { show_alert: true });
    }
  });

  // Monitor individual userbot
  bot.action(/^monitor_userbot_(.+)$/, async (ctx) => {
    try {
      const userbotId = (ctx.match as any)[1];
      const db = await jsonDb.read();
      const userbot = db.userbots.find(u => u.id === userbotId);
      
      if (!userbot) {
        return ctx.answerCbQuery('Userbot not found', { show_alert: true });
      }

      const broadcastProgress = liveEvents.getBroadcastProgress(userbotId);
      
      let text = `<b>📊 ${userbot.label} - Details</b>\n\n`;
      text += `<b>Status</b>\n`;
      text += `Status: <code>${userbot.status}</code>\n`;
      text += `Last Active: <code>${userbot.stats.lastRunAt ? Format.timeDiff(Date.now() - userbot.stats.lastRunAt) + ' ago' : 'Never'}</code>\n\n`;
      
      text += `<b>Statistics</b>\n`;
      text += `📤 Messages Sent: <code>${Format.number(userbot.stats.sent)}</code>\n`;
      text += `❌ Failed: <code>${Format.number(userbot.stats.failed)}</code>\n`;
      text += `🎯 Targets: <code>${Format.number(userbot.settings.targets.length)}</code>\n\n`;
      
      if (broadcastProgress && broadcastProgress.status === 'running') {
        text += `<b>Current Broadcast</b>\n`;
        const progressBar = createProgressBar(broadcastProgress.percentComplete, 20);
        const timeRemaining = broadcastProgress.estimatedTimeLeft 
          ? Format.timeDiff(broadcastProgress.estimatedTimeLeft) 
          : '...';
        
        text += `${progressBar} ${broadcastProgress.percentComplete}%\n`;
        text += `📤 Sent: <code>${broadcastProgress.sent}</code> | ❌ Failed: <code>${broadcastProgress.failed}</code>\n`;
        text += `Target: ${broadcastProgress.currentTarget ? `<code>${broadcastProgress.currentTarget}</code>` : '<i>Starting...</i>'}\n`;
        text += `Remaining: <code>${timeRemaining}</code>\n`;
      } else {
        text += `<b>Status</b>\n`;
        text += `💤 No active broadcast\n`;
      }

      return ctx.editMessageText(text, {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [ { text: '🔄 Refresh', callback_data: `monitor_userbot_${userbotId}` } ],
            [ { text: '◀️ Kembali', callback_data: 'monitor_active' } ]
          ],
        },
      });
    } catch (error: any) {
      ctx.answerCbQuery(`Error: ${error?.message}`, { show_alert: true });
    }
  });
}

function createProgressBar(percentage: number, width: number = 20): string {
  const filled = Math.round((percentage / 100) * width);
  const empty = width - filled;
  const bar = '█'.repeat(filled) + '░'.repeat(empty);
  return `[${bar}]`;
}
