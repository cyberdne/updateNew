import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS, StatusFormatter } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendUserbotsMenu(ctx: Context, page = 1) {
  const db = await jsonDb.read();
  const userbots = db.userbots;
  const perPage = 5;
  const totalPages = Math.max(1, Math.ceil(userbots.length / perPage));
  const currentPage = Math.min(Math.max(1, page), totalPages);
  const start = (currentPage - 1) * perPage;
  const pageUserbots = userbots.slice(start, start + perPage);

  let list = '';
  if (pageUserbots.length === 0) {
    list = Format.italic('Belum ada userbot. Tambahkan userbot pertama Anda!');
  } else {
    list = pageUserbots.map((u, i) => {
      const status = StatusFormatter.userbot(u.status);
      const daysLeft = Math.ceil((u.subscription.expireAt - Date.now()) / (24*60*60*1000));
      const subStatus = StatusFormatter.subscription(daysLeft);
      const index = start + i + 1;
      
      return `${index}. ${status}
   ${ICONS.bot} <b>${u.label}</b>
   👤 Buyer: ${Format.code(u.buyerId)}
   ${ICONS.calendar} Sub: ${subStatus}`;
    }).join('\n\n');
  }

  const text = `${ICONS.bot} <b>🤖 USERBOT MANAGEMENT</b>
${Format.divider(50)}

${Format.section('Daftar Userbots', ICONS.list)}
${list}

${Format.divider(50)}
📄 <b>Halaman ${currentPage}/${totalPages}</b> • <b>Total: ${userbots.length}</b> userbot`;

  const rows: any[] = [];
  
  pageUserbots.forEach((u, i) => {
    const status = StatusFormatter.userbot(u.status);
    const label = u.label.length > 20 ? u.label.substring(0, 17) + '...' : u.label;
    rows.push([
      Markup.button.callback(`${status} ${label}`, `userbot:${u.id}`),
      Markup.button.callback('ℹ️', `menu:userbot_info:${u.id}`)
    ]);
  });

  const navButtons = [];
  if (currentPage > 1) {
    navButtons.push(Markup.button.callback(`${ICONS.prev} Previous`, `menu:userbots:${currentPage - 1}`));
  }
  navButtons.push(Markup.button.callback(`📄 ${currentPage}/${totalPages}`, 'noop'));
  if (currentPage < totalPages) {
    navButtons.push(Markup.button.callback(`${ICONS.next} Next`, `menu:userbots:${currentPage + 1}`));
  }
  if (navButtons.length > 1 || totalPages > 1) {
    rows.push(navButtons);
  }

  rows.push([
    Markup.button.callback(`${ICONS.plus} Add Userbot`, 'menu:add_userbot'),
    Markup.button.callback(`${ICONS.refresh} Refresh`, 'menu:userbots')
  ]);
  rows.push([Markup.button.callback(`${ICONS.back} Back`, 'home')]);

  await safeEditOrResend(ctx, text, Markup.inlineKeyboard(rows));
}
