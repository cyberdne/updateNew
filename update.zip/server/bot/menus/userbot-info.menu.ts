import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS, StatusFormatter } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendUserbotInfoMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const { subscription, settings, stats, status } = userbot;
  const targetCount = settings.targets.length;
  const timezone = db.globalSettings?.timezone || 'Asia/Jakarta';

  // Calculate activation date
  const activatedAt = subscription.startedAt || subscription.expireAt - (subscription.durationMs || 0);
  const activatedDate = new Date(activatedAt);
  const activatedStr = activatedDate.toLocaleDateString('id-ID', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  // Calculate remaining time
  const now = Date.now();
  const remaining = Math.max(0, subscription.expireAt - now);
  const remainingDays = Math.ceil(remaining / (24 * 60 * 60 * 1000));
  const expiredDate = new Date(subscription.expireAt);
  const expiredStr = expiredDate.toLocaleDateString('id-ID', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  // Duration
  const durationMs = subscription.durationMs || 0;
  const durationDays = Math.floor(durationMs / (24 * 60 * 60 * 1000));
  const durationHours = Math.floor((durationMs % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));

  // Uptime
  const uptimeStartAt = stats.uptimeStartAt || activatedAt;
  const uptimeDays = Math.floor((now - uptimeStartAt) / (24 * 60 * 60 * 1000));

  // Success rate
  const totalMessages = stats.sent + stats.failed;
  const successRate = totalMessages > 0 ? ((stats.sent / totalMessages) * 100).toFixed(1) : '0';

  // Status badge
  const statusBadge = {
    'RUNNING': `${ICONS.online} Running`,
    'READY': `${ICONS.offline} Ready`,
    'STOPPED': `${ICONS.offline} Stopped`,
    'ERROR': `${ICONS.error} Error`,
    'OFF_SUBS': `${ICONS.warning} Expired`,
  }[status] || `${ICONS.offline} Unknown`;

  // Subscription status badge
  const subStatusBadge = subscription.active
    ? remainingDays > 7
      ? `${ICONS.success} Active (${remainingDays}d)`
      : remainingDays > 0
      ? `${ICONS.warning} Expiring Soon (${remainingDays}d)`
      : `${ICONS.failed} Expired`
    : `${ICONS.failed} Inactive`;

  // Progress bars
  const targetUsagePercent = Math.min(100, Math.round((targetCount / (db.globalSettings?.maxTargetsPerUserbot || 500)) * 100));
  const targetProgressBar = Format.progressBar(targetCount, db.globalSettings?.maxTargetsPerUserbot || 500, 15);

  const subProgressPercent = remaining > 0 ? Math.round((remaining / (subscription.durationMs || 1)) * 100) : 0;
  const subProgressBar = Format.progressBar(
    remainingDays,
    durationDays,
    15
  );

  const successRatePercent = Math.min(100, Math.round(parseFloat(successRate) / 1));
  const successProgressBar = Format.progressBar(Math.round(parseFloat(successRate)), 100, 15);

  // Get message statistics
  const regularText = settings.regularText || '';
  const forwarded = settings.forwardedMessage?.messageIds?.length || 0;
  const messageType = settings.messageType === 'FORWARD' ? `Forward (${forwarded} msg)` : 'Regular Text';
  const messagePreview = regularText ? regularText.substring(0, 50) + (regularText.length > 50 ? '...' : '') : 'Not set';

  const text = `${ICONS.bot} <b>🤖 ACCOUNT INFORMATION</b>
${Format.divider(60)}

<b>👤 BASIC INFO</b>
${Format.item(0, '📱 Bot Name', Format.bold(userbot.label))}
${Format.item(0, '🔑 Buyer ID', Format.code(subscription.buyerId || subscription.buyerName || 'N/A'))}
${Format.item(0, '👤 Buyer Name', subscription.buyerName ? Format.code(subscription.buyerName) : Format.italic('Not set'), true)}

${Format.divider(60)}
<b>⏰ SUBSCRIPTION TIMELINE</b>
${Format.item(0, '🚀 Activated', Format.code(activatedStr))}
${Format.item(0, '⏳ Duration', `<b>${durationDays}d ${durationHours}h</b>`)}
${Format.item(0, '📅 Expires', Format.code(expiredStr))}
${Format.item(0, '⏱️ Remaining', remainingDays > 0 ? Format.bold(`${remainingDays} days`) : Format.italic('Expired'), true)}

<b>📊 SUBSCRIPTION STATUS</b>
${Format.item(0, '', subStatusBadge)}
${Format.item(0, '', `Progress: ${subProgressBar} ${subProgressPercent}%`, true)}

${Format.divider(60)}
<b>📤 ACCOUNT STATISTICS</b>
${Format.item(0, 'Status', statusBadge)}
${Format.item(0, '📨 Messages Sent', Format.bold(stats.sent.toLocaleString()))}
${Format.item(0, '❌ Failed', Format.bold(stats.failed.toLocaleString()))}
${Format.item(0, '⏭️ Skipped', Format.bold(stats.skipped.toLocaleString()))}
${Format.item(0, '💯 Success Rate', `${successRate}% ${successProgressBar}`, true)}

${Format.divider(60)}<b>📨 MESSAGE CONFIGURATION</b>
${Format.item(0, 'Type', Format.bold(messageType))}
${Format.item(0, 'Preview', messagePreview === 'Not set' ? Format.italic(messagePreview) : Format.code(messagePreview))}
${Format.item(0, '⚙️ Spread Mode', Format.bold(settings.spreadMode))}
${Format.item(0, 'Premium Emoji', settings.premiumEmoji ? '✅ Enabled' : '❌ Disabled', true)}

${Format.divider(60)}<b>🎯 TARGET MANAGEMENT</b>
${Format.item(0, 'Total Groups', Format.bold(targetCount.toString()))}
${Format.item(0, 'Max Capacity', Format.code((db.globalSettings?.maxTargetsPerUserbot || 500).toString()))}
${Format.item(0, 'Usage', `${targetUsagePercent}% ${targetProgressBar}`, true)}

${Format.divider(60)}
<b>🕐 ACTIVITY</b>
${Format.item(0, 'Uptime', `${uptimeDays} days`)}
${Format.item(0, 'Last Active', stats.lastRunAt ? Format.bold(formatTimeDiff(now - stats.lastRunAt) + ' ago') : Format.italic('Never'), true)}

${Format.divider(60)}
<i>💡 Informasi akun lengkap dan detail untuk monitoring & management</i>`;

  const keyboard = Markup.inlineKeyboard([
    [Markup.button.callback(`${ICONS.refresh} Refresh`, `menu:userbot_info:${id}`)],
    [Markup.button.callback(`${ICONS.back} Back`, `userbot:${id}`)],
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}

function formatTimeDiff(ms: number): string {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days}d`;
  if (hours > 0) return `${hours}h`;
  if (minutes > 0) return `${minutes}m`;
  return `${seconds < 1 ? 1 : seconds}s`;
}
