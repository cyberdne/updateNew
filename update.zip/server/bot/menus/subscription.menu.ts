import { Markup } from 'telegraf';
import type { Context } from 'telegraf';
import { safeEditOrResend } from '../utils/message.util';
import { Format, ICONS } from '../utils/format.util';
import { jsonDb } from '../../storage/db';

export async function sendSubscriptionMenu(ctx: Context, id: string) {
  const db = await jsonDb.read();
  const userbot = db.userbots.find(u => u.id === id);
  if (!userbot) return ctx.answerCbQuery('Userbot tidak ditemukan');

  const { subscription } = userbot;
  const now = Date.now();
  const isExpired = subscription.expireAt < now;
  const daysLeft = Math.ceil((subscription.expireAt - now) / (24 * 60 * 60 * 1000));
  const statusEmoji = subscription.active && !isExpired ? ICONS.success : ICONS.warning;
  const botStatusEmoji = userbot.status === 'RUNNING' ? ICONS.online : userbot.status === 'STOPPED' ? ICONS.offline : ICONS.failed;
  
  const expireDate = new Date(subscription.expireAt).toLocaleDateString('id-ID', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  const startDate = subscription.startedAt 
    ? new Date(subscription.startedAt).toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    : 'N/A';

  const daysUsed = subscription.startedAt ? Math.floor((now - subscription.startedAt) / (24 * 60 * 60 * 1000)) : 0;
  const totalDays = subscription.durationMs ? Math.ceil(subscription.durationMs / (24 * 60 * 60 * 1000)) : (subscription.durationDays || 0);

  // Add subscription type indicator
  const getDurationLabel = (durationMs?: number): string => {
    if (!durationMs) return 'Custom';
    const days = durationMs / (24 * 60 * 60 * 1000);
    if (days < 1/24) return 'Per Jam';
    if (days === 1) return 'Harian';
    if (days === 7) return 'Mingguan';
    if (days === 30) return 'Bulanan';
    if (days === 365) return 'Tahunan';
    return `${Math.round(days)} Hari`;
  };

  const text = `${ICONS.premium} <b>💳 SUBSCRIPTION MANAGER</b>
${Format.divider(50)}

<b>📌 USERBOT INFORMATION</b>
${Format.item(1, 'Nama', Format.bold(userbot.label))}
${Format.item(1, 'ID Unik', Format.code(subscription.uniqueTrackingId || 'N/A'))}
${Format.item(1, 'Pembeli', Format.bold(subscription.buyerName || userbot.buyerId))}
${Format.item(1, 'Status', `${botStatusEmoji} ${userbot.status}`, true)}

<b>💎 SUBSCRIPTION DETAILS</b>
${Format.item(1, 'Status', `${statusEmoji} ${subscription.active && !isExpired ? '✅ Aktif' : '❌ Expired'}`)}
${Format.item(1, 'Tipe', Format.bold(getDurationLabel(subscription.durationMs)))}
${Format.item(1, 'Aktif Sejak', Format.code(startDate))}
${Format.item(1, 'Durasi', `<b>${totalDays || 'N/A'}</b> hari`)}
${Format.item(1, 'Usage', `<b>${daysUsed}</b> / <b>${totalDays || 0}</b> hari`)}
${Format.item(1, 'Berakhir', Format.code(expireDate))}
${Format.item(1, 'Sisa Hari', isExpired ? Format.bold('❌ EXPIRED') : Format.bold(`✅ ${daysLeft} hari`), true)}

<b>🔧 CONFIGURATION</b>
${Format.item(1, 'Resume Mode', Format.bold(subscription.resumeMode))}
${Format.item(1, 'Info', subscription.resumeMode === 'RESUME' ? '↩️ Lanjut dari posisi terakhir' : '🔄 Mulai dari awal', true)}

${Format.divider(50)}
<i>⚠️ Perpanjang sebelum expired untuk data tidak hilang saat reset.</i>`;

  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('⏰ Per Jam', `action:set_sub_hourly:${id}`),
      Markup.button.callback('📅 Per Hari', `action:set_sub_daily:${id}`)
    ],
    [
      Markup.button.callback('📆 Per Minggu', `action:set_sub_weekly:${id}`),
      Markup.button.callback('🗓️ Per Bulan', `action:set_sub_monthly:${id}`)
    ],
    [
      Markup.button.callback('📈 Per Tahun', `action:set_sub_yearly:${id}`),
      Markup.button.callback('➕ Perpanjang', `input:extend_sub:${id}`)
    ],
    [Markup.button.callback(`🔄 Mode: ${subscription.resumeMode}`, `action:toggle_resume_mode:${id}`)],
    [Markup.button.callback('🔙 Kembali', `userbot:${id}`)]
  ]);

  await safeEditOrResend(ctx, text, keyboard);
}
