import type { Context } from 'telegraf';
import { jasebBot } from '../bot';
import { userbotManager } from '../../userbots/userbot.manager';
import { targetManager } from '../../jaseb/target/target.manager';
import { linkScanner } from '../../jaseb/link.scanner';
import { jsonDb } from '../../storage/db';
import { liveEvents } from '../../utils/live-events';
import { sendMainMenu } from '../menus/main.menu';
import { sendUserbotsMenu } from '../menus/userbots.menu';
import { sendUserbotControlMenu } from '../menus/userbot.control.menu';
import { sendTargetsMenu } from '../menus/targets.menu';
import { sendUserbotInfoMenu } from '../menus/userbot-info.menu';
import { sendStatsMenu } from '../menus/stats.menu';
import { sendTimerMenu } from '../menus/timer.menu';
import { sendPmPermitMenu } from '../menus/pmpermit.menu';
import { sendConfigMenu } from '../menus/config.menu';
import { sendSubscriptionMenu } from '../menus/subscription.menu';
import { sendGlobalSettingsMenu } from '../menus/global.settings.menu';
import { sendAutoPilotMenu } from '../menus/autopilot.menu';
import { sendAutoReplyMenu } from '../menus/autoreply.menu';
import { sendPremiumMenu } from '../menus/premium.menu';
import { sendSourceMenu } from '../menus/source.menu';
import { sendBackupMenu } from '../menus/backup.menu';
import { sendBotBroadcastMenu } from '../menus/bot.broadcast.menu';
import { sendBroadcastPrivateMessagesMenu } from '../menus/broadcast-private-messages.menu';
import { sendAutoLeaveMenu } from '../menus/auto-leave.menu';
import { sendAutoReadChatMenu } from '../menus/auto-read-chat.menu';
import { sendClearChatMenu } from '../menus/clear-chat.menu';
import { setupMonitorMenu } from '../menus/monitor.menu';
import { jobRunner } from '../../jaseb/job.runner';
import { reportService } from '../../reports/report.service';
import { sourceService } from '../../services/source.service';
import { backupService } from '../../services/backup.service';
import { cacheService } from '../../services/cache.service';
import { broadcastPrivateMessagesService } from '../../services/broadcast-private-messages.service';
import { autoLeaveService } from '../../services/auto-leave.service';
import { autoReadChatService } from '../../services/auto-read-chat.service';
import { clearChatService } from '../../services/clear-chat.service';
import os from 'os';

export async function handleCallback(ctx: Context) {
    // @ts-ignore
    const data = ctx.callbackQuery?.data as string;
    if (!data) return;

    try {
        await ctx.answerCbQuery().catch(() => {});

        if (data === 'home') return sendMainMenu(ctx);
        if (data === 'noop') return;

        // ========== LIVE MONITOR ==========
        if (data === 'monitor_active') {
            const allBroadcasts = liveEvents.getAllBroadcasts();
            
            if (allBroadcasts.length === 0) {
                return ctx.reply('📊 <b>No active broadcasts</b>\n\n✅ All userbots idle', {
                    parse_mode: 'HTML',
                });
            }

            let text = '<b>📊 Active Broadcasts</b>\n\n';
            
            for (const broadcast of allBroadcasts) {
                const db = await jsonDb.read();
                const userbot = db.userbots.find(u => u.id === broadcast.userbotId);
                const label = userbot?.label || broadcast.userbotId;
                
                const progressBar = createProgressBar(broadcast.percentComplete, 20);
                const timeElapsed = formatTimeDiff(Date.now() - broadcast.startedAt);
                const timeRemaining = broadcast.estimatedTimeLeft 
                    ? formatTimeDiff(broadcast.estimatedTimeLeft) 
                    : '...';
                
                text += `<b>${label}</b>\n`;
                text += `${progressBar} ${broadcast.percentComplete}%\n`;
                text += `📤 Sent: <code>${broadcast.sent}</code> | ❌ Failed: <code>${broadcast.failed}</code> | ⏭️ Skipped: <code>${broadcast.skipped}</code>\n`;
                text += `⏱️ Target: ${broadcast.currentTarget ? `<code>${broadcast.currentTarget}</code>` : '<i>Starting...</i>'}\n`;
                text += `⏰ Elapsed: <code>${timeElapsed}</code> | Remaining: <code>${timeRemaining}</code>\n\n`;
            }

            return ctx.editMessageText(text, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            {
                                text: '🔄 Refresh',
                                callback_data: 'monitor_active',
                            },
                            {
                                text: '📊 Stats',
                                callback_data: 'monitor_stats',
                            }
                        ],
                        [
                            {
                                text: '🏠 Home',
                                callback_data: 'home',
                            }
                        ]
                    ],
                },
            }).catch(() => {});
        }

        if (data === 'monitor_stats') {
            const db = await jsonDb.read();
            
            const activeBots = db.userbots.filter(u => u.status === 'RUNNING').length;
            const totalBots = db.userbots.length;
            const totalSent = db.userbots.reduce((acc, u) => acc + u.stats.sent, 0);
            const totalFailed = db.userbots.reduce((acc, u) => acc + u.stats.failed, 0);
            const totalTargets = db.userbots.reduce((acc, u) => acc + u.settings.targets.length, 0);
            
            // Get active broadcasts
            const allBroadcasts = liveEvents.getAllBroadcasts();
            const totalRunning = allBroadcasts.length;
            
            let text = '<b>📈 Global System Stats</b>\n\n';
            text += `<b>Bots</b>\n`;
            text += `✅ Active: <code>${activeBots}/${totalBots}</code>\n`;
            text += `🔄 Broadcasts Running: <code>${totalRunning}</code>\n\n`;
            
            text += `<b>Messages</b>\n`;
            text += `📤 Total Sent: <code>${formatNumber(totalSent)}</code>\n`;
            text += `❌ Total Failed: <code>${formatNumber(totalFailed)}</code>\n`;
            text += `💯 Success Rate: <code>${totalSent + totalFailed > 0 ? ((totalSent / (totalSent + totalFailed)) * 100).toFixed(1) : '0'}%</code>\n\n`;
            
            text += `<b>Targets</b>\n`;
            text += `🎯 Total Configured: <code>${formatNumber(totalTargets)}</code>\n`;
            
            const globalBlacklistSize = db.globalSettings?.globalBlacklist?.length || 0;
            text += `🚫 Blacklisted: <code>${formatNumber(globalBlacklistSize)}</code>\n\n`;
            
            text += `🕐 Last Update: <code>${new Date().toLocaleTimeString()}</code>`;

            return ctx.editMessageText(text, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            {
                                text: '📊 Broadcasts',
                                callback_data: 'monitor_active',
                            },
                            {
                                text: '🔄 Refresh',
                                callback_data: 'monitor_stats',
                            }
                        ],
                        [
                            {
                                text: '🏠 Home',
                                callback_data: 'home',
                            }
                        ]
                    ],
                },
            }).catch(() => {});
        }

        if (data.startsWith('monitor_userbot_')) {
            const userbotId = data.split('_')[2];
            const db = await jsonDb.read();
            const userbot = db.userbots.find(u => u.id === userbotId);
            
            if (!userbot) {
                return ctx.answerCbQuery('Userbot not found', { show_alert: true });
            }

            const broadcastProgress = liveEvents.getBroadcastProgress(userbotId);
            
            let text = `<b>📊 ${userbot.label} - Details</b>\n\n`;
            text += `<b>Status</b>\n`;
            text += `Status: <code>${userbot.status}</code>\n`;
            text += `Last Active: <code>${userbot.stats.lastRunAt ? formatTimeDiff(Date.now() - userbot.stats.lastRunAt) + ' ago' : 'Never'}</code>\n\n`;
            
            text += `<b>Statistics</b>\n`;
            text += `📤 Messages Sent: <code>${formatNumber(userbot.stats.sent)}</code>\n`;
            text += `❌ Failed: <code>${formatNumber(userbot.stats.failed)}</code>\n`;
            text += `🎯 Targets: <code>${formatNumber(userbot.settings.targets.length)}</code>\n\n`;
            
            if (broadcastProgress && broadcastProgress.status === 'running') {
                text += `<b>Current Broadcast</b>\n`;
                const progressBar = createProgressBar(broadcastProgress.percentComplete, 20);
                const timeRemaining = broadcastProgress.estimatedTimeLeft 
                    ? formatTimeDiff(broadcastProgress.estimatedTimeLeft) 
                    : '...';
                
                text += `${progressBar} ${broadcastProgress.percentComplete}%\n`;
                text += `📤 Sent: <code>${broadcastProgress.sent}</code> | ❌ Failed: <code>${broadcastProgress.failed}</code>\n`;
                text += `Target: ${broadcastProgress.currentTarget ? `<code>${broadcastProgress.currentTarget}</code>` : '<i>Starting...</i>'}\n`;
                text += `Remaining: <code>${timeRemaining}</code>\n`;
            } else {
                text += `<b>Status</b>\n`;
                text += `💤 No active broadcast\n`;
            }

            return ctx.editMessageText(text, {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            {
                                text: '🔄 Refresh',
                                callback_data: `monitor_userbot_${userbotId}`,
                            },
                        ],
                        [
                            {
                                text: '◀️ Back',
                                callback_data: 'monitor_active',
                            },
                        ],
                    ],
                },
            }).catch(() => {});
        }
        
        // ========== NAVIGATION MENUS ==========
        if (data.startsWith('menu:')) {
            const parts = data.split(':');
            const menu = parts[1];
            const arg = parts[2];

            switch(menu) {
                case 'userbots': return sendUserbotsMenu(ctx, arg ? parseInt(arg) : 1);
                case 'stats': return sendStatsMenu(ctx);
                case 'settings': return sendGlobalSettingsMenu(ctx);
                case 'targets': return sendTargetsMenu(ctx, arg);
                case 'timer': return sendTimerMenu(ctx, arg);
                case 'pmpermit': return sendPmPermitMenu(ctx, arg);
                case 'config': return sendConfigMenu(ctx, arg);
                case 'subscription': return sendSubscriptionMenu(ctx, arg);
                case 'autopilot': return sendAutoPilotMenu(ctx, arg);
                case 'autoreply': return sendAutoReplyMenu(ctx, arg);
                case 'premium': return sendPremiumMenu(ctx, arg);
                case 'source': return sendSourceMenu(ctx);
                case 'backup': return sendBackupMenu(ctx);
                case 'bpm': return sendBroadcastPrivateMessagesMenu(ctx, arg);
                case 'auto_leave': return sendAutoLeaveMenu(ctx, arg);
                case 'auto_read': return sendAutoReadChatMenu(ctx, arg);
                case 'clear_chat': return sendClearChatMenu(ctx, arg);
                case 'userbot_info': return sendUserbotInfoMenu(ctx, arg);
                case 'bot_broadcast': return sendBotBroadcastMenu(ctx);
                case 'add_userbot': 
                    const addKeyboard = {
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '📱 Login via Phone', callback_data: 'add:phone' }],
                                [{ text: '🔑 Tambah String Session', callback_data: 'add:session' }],
                                [{ text: '🔙 Kembali', callback_data: 'menu:userbots' }]
                            ]
                        }
                    };
                    await ctx.editMessageText(`<b>➕ Tambah Userbot</b>
━━━━━━━━━━━━━━━━━━━━━

Pilih metode untuk menambahkan userbot:

📱 <b>Login via Phone</b>
Masukkan nomor telepon dan kode OTP

🔑 <b>String Session</b>
Gunakan string session yang sudah ada

━━━━━━━━━━━━━━━━━━━━━`, { 
                        parse_mode: 'HTML', 
                        ...addKeyboard 
                    });
                    return;
                case 'set_reg_text':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_REG_TEXT', temp: { userbotId: arg } });
                    await ctx.reply('📝 <b>Set Regular Text</b>\n\nKirim teks yang akan di-broadcast.\nMendukung multi-line dan format Telegram.', { parse_mode: 'HTML' });
                    return;
                case 'set_fwd_text':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'AWAIT_FORWARD', temp: { userbotId: arg } });
                    await ctx.reply(`🔄 <b>Set Forward Message</b>
━━━━━━━━━━━━━━━━━━━━━

<b>Cara menggunakan:</b>
Forward pesan dari chat/channel mana saja ke sini.
Bot akan otomatis mendeteksi dan menyimpan pesan tersebut.

<i>💡 Bisa forward satu atau beberapa pesan sekaligus.</i>

━━━━━━━━━━━━━━━━━━━━━`, { parse_mode: 'HTML' });
                    return;
                case 'target_add':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'ADD_TARGET_MANUAL', temp: { userbotId: arg } });
                    await ctx.reply('🎯 Kirim link/username/ID target grup:\n\nContoh:\n• @groupname\n• t.me/groupname\n• -1001234567890');
                    return;
                case 'join_list':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'JOIN_LIST', temp: { userbotId: arg } });
                    await ctx.reply(`🔗 <b>Join From List</b>\n\nKirim daftar link/username/ID dipisah baris.\nOpsional: tambahkan baris pengaturan di awal seperti:\nDELAY:5000  (ms antara tiap join)\nBATCH:5    (jumlah join sebelum jeda)\nPAUSE:120000 (ms jeda setelah setiap batch)\n\nContoh:\nDELAY:5000\nBATCH:5\nPAUSE:120000\n@group1\nt.me/group2\n+AbCdEfGh`, { parse_mode: 'HTML' });
                    return;
                case 'scan_channel':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SCAN_CHANNEL', temp: { userbotId: arg } });
                    await ctx.reply('📡 Kirim username channel untuk di-scan:\n\nContoh: @channelname atau t.me/channelname');
                    return;
                case 'search_group':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SEARCH_KEYWORD', temp: { userbotId: arg } });
                    await ctx.reply('🔍 Kirim keyword untuk mencari grup:\n\nContoh: crypto, trading, nft');
                    return;
                case 'bpm_message':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'BPM_MESSAGE', temp: { userbotId: arg } });
                    await ctx.reply('📝 Kirim pesan untuk broadcast pesan pribadi:');
                    return;
                case 'auto_leave_days':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'AUTO_LEAVE_DAYS', temp: { userbotId: arg } });
                    await ctx.reply('📅 Kirim jumlah hari (min 1):\n\nBot akan keluar dari grup setelah X hari.');
                    return;
                case 'clear_chat_days':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'CLEAR_CHAT_DAYS', temp: { userbotId: arg } });
                    await ctx.reply('📅 Kirim jumlah hari minimum (min 1):\n\nHanya hapus pesan lebih lama dari X hari. Kosongkan untuk hapus semua.');
                    return;
            }
        }

        // ========== SOURCE CODE EXPORT ==========
        if (data.startsWith('source:')) {
            const mode = data.split(':')[1];
            
            if (mode === 'custom') {
                jasebBot.userStates.set(ctx.from!.id, { step: 'SOURCE_CUSTOM_NAME' });
                await ctx.reply('✏️ Kirim nama file (tanpa .zip):');
                return;
            }
            
            const validModes = ['script_only', 'no_modules', 'no_data', 'full'];
            if (validModes.includes(mode)) {
                await ctx.reply('⏳ Sedang membuat archive...');
                try {
                    const filePath = await sourceService.exportSource({ mode: mode as any });
                    await ctx.replyWithDocument({ source: filePath, filename: filePath.split('/').pop() });
                    await ctx.reply('✅ Export berhasil!');
                } catch (e: any) {
                    await ctx.reply(`❌ Gagal: ${e.message}`);
                }
                return sendSourceMenu(ctx);
            }
        }

        // ========== BACKUP ==========
        if (data.startsWith('backup:')) {
            const action = data.split(':')[1];
            
            switch(action) {
                case 'toggle':
                    const db = await jsonDb.read();
                    const current = (db as any).backupSettings?.enabled || false;
                    await backupService.updateSettings({ enabled: !current });
                    await ctx.reply(current ? '⏸️ Auto backup dinonaktifkan' : '▶️ Auto backup diaktifkan');
                    return sendBackupMenu(ctx);
                case 'set_channel':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_BACKUP_CHANNEL' });
                    await ctx.reply('📺 Kirim ID channel untuk backup:\n\nContoh: -1001234567890 atau @channelname');
                    return;
                case 'set_schedule':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_BACKUP_TIME' });
                    await ctx.reply('⏰ Kirim jam backup (format HH:MM):\n\nContoh: 00:00 atau 12:30');
                    return;
                case 'set_day':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_BACKUP_DAY' });
                    await ctx.reply('📅 Kirim hari backup:\n\n• * = Setiap hari\n• 1-31 = Tanggal tertentu\n\nContoh: * atau 1');
                    return;
                case 'now':
                    await ctx.reply('⏳ Membuat backup...');
                    try {
                        const backupPath = await backupService.createBackup();
                        await ctx.replyWithDocument({ source: backupPath, filename: backupPath.split('/').pop() });
                        await ctx.reply('✅ Backup berhasil!');
                    } catch (e: any) {
                        await ctx.reply(`❌ Gagal: ${e.message}`);
                    }
                    return sendBackupMenu(ctx);
                case 'restore':
                    const backups = await backupService.listBackups();
                    if (backups.length === 0) {
                        await ctx.reply('❌ Tidak ada backup tersedia');
                        return sendBackupMenu(ctx);
                    }
                    const latestPath = await backupService.getLatestBackup();
                    if (latestPath) {
                        await backupService.restoreBackup(latestPath);
                        await ctx.reply('✅ Restore berhasil dari backup terakhir!');
                    }
                    return sendBackupMenu(ctx);
            }
        }

        // ========== BOT BROADCAST ==========
        if (data.startsWith('botbc:')) {
            const parts = data.split(':');
            const action = parts[1];
            const arg = parts[2];

            switch(action) {
                case 'mode':
                    const db = await jsonDb.read();
                    (db as any).botBroadcast = (db as any).botBroadcast || { mode: 'CHANNEL', targets: [], message: null };
                    (db as any).botBroadcast.mode = arg;
                    await jsonDb.write(db);
                    await ctx.reply(`✅ Mode diubah ke ${arg}`);
                    return sendBotBroadcastMenu(ctx);
                case 'add_target':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'ADD_BC_TARGET' });
                    await ctx.reply('🎯 Kirim target (ID atau username):');
                    return;
                case 'set_message':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_BC_MESSAGE' });
                    await ctx.reply('📝 Kirim pesan untuk broadcast:');
                    return;
                case 'list_targets':
                    const dbList = await jsonDb.read();
                    const targets = (dbList as any).botBroadcast?.targets || [];
                    if (targets.length === 0) {
                        await ctx.reply('❌ Belum ada target');
                    } else {
                        await ctx.reply(`📋 <b>Daftar Target:</b>\n\n${targets.map((t: string, i: number) => `${i+1}. <code>${t}</code>`).join('\n')}`, { parse_mode: 'HTML' });
                    }
                    return;
                case 'clear_targets':
                    const dbClear = await jsonDb.read();
                    (dbClear as any).botBroadcast = (dbClear as any).botBroadcast || {};
                    (dbClear as any).botBroadcast.targets = [];
                    await jsonDb.write(dbClear);
                    await ctx.reply('✅ Targets dibersihkan');
                    return sendBotBroadcastMenu(ctx);
                case 'start':
                    await ctx.reply('⏳ Memulai broadcast...');
                    const dbBc = await jsonDb.read();
                    const bcSettings = (dbBc as any).botBroadcast;
                    if (!bcSettings?.message) {
                        await ctx.reply('❌ Pesan belum diset');
                        return;
                    }
                    if (!bcSettings?.targets?.length) {
                        await ctx.reply('❌ Target belum diset');
                        return;
                    }
                    let sent = 0;
                    for (const target of bcSettings.targets) {
                        try {
                            await ctx.telegram.sendMessage(target, bcSettings.message, { parse_mode: 'HTML' });
                            sent++;
                        } catch (e: any) {
                            // Skip failed
                        }
                    }
                    (dbBc as any).botBroadcast.lastBroadcastAt = Date.now();
                    await jsonDb.write(dbBc);
                    await ctx.reply(`✅ Broadcast selesai!\n\nTerkirim: ${sent}/${bcSettings.targets.length}`);
                    return sendBotBroadcastMenu(ctx);
            }
        }

        // ========== GLOBAL SETTINGS ==========
        if (data.startsWith('global:')) {
            const action = data.split(':')[1];
            
            switch(action) {
                case 'set_timezone':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_SET_TIMEZONE' });
                    await ctx.reply(`🌍 <b>Set Timezone Server</b>

Kirim timezone dalam format: <code>Asia/Jakarta</code>

<b>Contoh timezone populer:</b>
• Asia/Jakarta (WIB)
• Asia/Bangkok (ICT)
• Asia/Manila (PHT)
• Asia/Singapore (SGT)
• Asia/Kolkata (IST)
• America/New_York (EST)
• Europe/London (GMT)

<i>💡 Timezone ini akan digunakan untuk timer semua userbot.</i>`, { parse_mode: 'HTML' });
                    return;
                case 'toggle_premium_emoji':
                    await jsonDb.updateGlobalSettings(s => {
                        s.defaultPremiumEmoji = !s.defaultPremiumEmoji;
                        return s;
                    });
                    return sendGlobalSettingsMenu(ctx);
                case 'clear_watermark':
                    await jsonDb.updateGlobalSettings(s => {
                        s.defaultWatermark = undefined;
                        return s;
                    });
                    return sendGlobalSettingsMenu(ctx);
                case 'clear_blacklist':
                    await jsonDb.updateGlobalSettings(s => {
                        s.globalBlacklist = [];
                        return s;
                    });
                    return sendGlobalSettingsMenu(ctx);
                case 'instant_delay':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_INSTANT_DELAY' });
                    await ctx.reply('⏱️ Masukkan delay instant loop (detik, min 60):');
                    return;
                case 'seq_delay':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_SEQ_DELAY' });
                    await ctx.reply('⏱️ Masukkan delay sequential (detik, min 5):');
                    return;
                case 'max_targets':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_MAX_TARGETS' });
                    await ctx.reply('🎯 Masukkan max target per userbot:');
                    return;
                case 'join_delay':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_JOIN_DELAY' });
                    await ctx.reply('⏱️ Masukkan delay auto join (ms, min 1000):');
                    return;
                case 'set_watermark':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_WATERMARK' });
                    await ctx.reply('📝 Masukkan teks watermark default:');
                    return;
                case 'add_blacklist':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'GLOBAL_ADD_BLACKLIST' });
                    await ctx.reply('🚫 Masukkan chat ID untuk blacklist:');
                    return;
            }
        }

        // ========== AUTOPILOT ==========
        if (data.startsWith('autopilot:')) {
            const parts = data.split(':');
            const action = parts[1];
            const id = parts[2];

            switch(action) {
                case 'toggle':
                    await jsonDb.updateUserbot(id, u => {
                        if (!u.autoPilot) u.autoPilot = { enabled: false, scanLinks: false, autoJoin: false, joinedCount: 0, lastScanAt: 0 };
                        u.autoPilot.enabled = !u.autoPilot.enabled;
                        if (u.autoPilot.enabled) {
                            u.autoPilot.scanLinks = true;
                            u.autoPilot.autoJoin = true;
                        }
                        return u;
                    });
                    return sendAutoPilotMenu(ctx, id);
                case 'scan':
                    await jsonDb.updateUserbot(id, u => {
                        if (!u.autoPilot) u.autoPilot = { enabled: false, scanLinks: false, autoJoin: false, joinedCount: 0, lastScanAt: 0 };
                        u.autoPilot.scanLinks = !u.autoPilot.scanLinks;
                        return u;
                    });
                    return sendAutoPilotMenu(ctx, id);
                case 'join':
                    await jsonDb.updateUserbot(id, u => {
                        if (!u.autoPilot) u.autoPilot = { enabled: false, scanLinks: false, autoJoin: false, joinedCount: 0, lastScanAt: 0 };
                        u.autoPilot.autoJoin = !u.autoPilot.autoJoin;
                        return u;
                    });
                    return sendAutoPilotMenu(ctx, id);
                case 'reset':
                    await jsonDb.updateUserbot(id, u => {
                        if (u.autoPilot) {
                            u.autoPilot.joinedCount = 0;
                            u.autoPilot.lastScanAt = 0;
                        }
                        return u;
                    });
                    return sendAutoPilotMenu(ctx, id);
            }
        }

        // ========== AUTOREPLY ==========
        if (data.startsWith('autoreply:')) {
            const parts = data.split(':');
            const action = parts[1];
            const id = parts[2];

            switch(action) {
                case 'toggle':
                    await jsonDb.updateUserbot(id, u => {
                        if (!u.autoReplyKeyword) u.autoReplyKeyword = { enabled: false, keywords: [], useForward: false };
                        u.autoReplyKeyword.enabled = !u.autoReplyKeyword.enabled;
                        return u;
                    });
                    return sendAutoReplyMenu(ctx, id);
                case 'toggle_forward':
                    await jsonDb.updateUserbot(id, u => {
                        if (!u.autoReplyKeyword) u.autoReplyKeyword = { enabled: false, keywords: [], useForward: false };
                        u.autoReplyKeyword.useForward = !u.autoReplyKeyword.useForward;
                        return u;
                    });
                    return sendAutoReplyMenu(ctx, id);
                case 'clear_keywords':
                    await jsonDb.updateUserbot(id, u => {
                        if (u.autoReplyKeyword) u.autoReplyKeyword.keywords = [];
                        return u;
                    });
                    return sendAutoReplyMenu(ctx, id);
                case 'add_keyword':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'ADD_AUTOREPLY_KEYWORD', temp: { userbotId: id } });
                    await ctx.reply('💬 Masukkan keyword trigger:');
                    return;
                case 'set_text':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_AUTOREPLY_TEXT', temp: { userbotId: id } });
                    await ctx.reply('📝 Masukkan teks reply:');
                    return;
            }
        }

        // ========== PREMIUM ==========
        if (data.startsWith('premium:')) {
            const parts = data.split(':');
            const action = parts[1];
            const id = parts[2];

            if (action === 'toggle') {
                await jsonDb.updateUserbot(id, u => {
                    u.settings.premiumEmoji = !u.settings.premiumEmoji;
                    return u;
                });
                return sendPremiumMenu(ctx, id);
            }
        }

        // ========== ADD USERBOT METHODS ==========
        if (data.startsWith('add:')) {
            const method = data.split(':')[1];
            if (method === 'phone') {
                jasebBot.userStates.set(ctx.from!.id, { step: 'PHONE_LOGIN_NUMBER' });
                await ctx.reply('📱 Masukkan nomor telepon (format internasional):\n\nContoh: +628123456789');
            } else if (method === 'session') {
                jasebBot.userStates.set(ctx.from!.id, { step: 'ADD_SESSION_STRING' });
                await ctx.reply('🔑 Kirim string session GramJS/Telethon:');
            }
            return;
        }

        // ========== INPUT PROMPTS ==========
        if (data.startsWith('input:')) {
            const parts = data.split(':');
            const inputType = parts[1];
            const arg = parts[2];

            switch(inputType) {
                case 'timer_start':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_TIMER_START', temp: { userbotId: arg } });
                    await ctx.reply('⏰ Masukkan jam mulai (format HH:MM):\n\nContoh: 08:00');
                    break;
                case 'timer_stop':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_TIMER_STOP', temp: { userbotId: arg } });
                    await ctx.reply('⏰ Masukkan jam berhenti (format HH:MM):\n\nContoh: 22:00');
                    break;
                case 'pm_template':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_PM_TEMPLATE', temp: { userbotId: arg } });
                    await ctx.reply('📝 Masukkan template PM auto-reply:');
                    break;
                case 'pm_allow':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'ADD_PM_ALLOW', temp: { userbotId: arg } });
                    await ctx.reply('👤 Masukkan user ID yang diizinkan:');
                    break;
                case 'instant_delay':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_INSTANT_DELAY', temp: { userbotId: arg } });
                    await ctx.reply('⏱️ Masukkan delay instant loop (detik, min 60):');
                    break;
                case 'seq_delay':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_SEQ_DELAY', temp: { userbotId: arg } });
                    await ctx.reply('⏱️ Masukkan delay sequential (detik, min 5):');
                    break;
                case 'watermark':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_WATERMARK', temp: { userbotId: arg } });
                    await ctx.reply('📝 Masukkan teks watermark:');
                    break;
                case 'extend_sub':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'EXTEND_SUBSCRIPTION', temp: { userbotId: arg } });
                    await ctx.reply('📅 Masukkan durasi perpanjangan (contoh: 1h, 12h, 1d, 7d, 1w, 1m):');
                    break;
            }
            return;
        }

        // ========== ACTIONS ==========
        if (data.startsWith('action:')) {
            const parts = data.split(':');
            const action = parts[1];
            const arg = parts[2];

            switch(action) {
                case 'start':
                    const dbStart = await jsonDb.read();
                    const ubStart = dbStart.userbots.find(u => u.id === arg);
                    if (!ubStart) return;

                    if (!ubStart.subscription.active || ubStart.subscription.expireAt < Date.now()) {
                        await ctx.reply('❌ Tidak bisa start: Subscription expired');
                        return sendUserbotControlMenu(ctx, arg);
                    }
                    if (ubStart.settings.targets.length === 0) {
                        await ctx.reply('❌ Tidak bisa start: Belum ada target');
                        return sendUserbotControlMenu(ctx, arg);
                    }
                    
                    const hasMessage = ubStart.settings.messageType === 'FORWARD'
                        ? (ubStart.settings.forwardedMessage?.messageIds?.length || ubStart.settings.forwardConfig?.messageIds?.length)
                        : !!ubStart.settings.regularText;
                    
                    if (!hasMessage) {
                        await ctx.reply('❌ Tidak bisa start: Belum ada pesan yang diset');
                        return sendUserbotControlMenu(ctx, arg);
                    }

                    await jsonDb.updateUserbot(arg, u => { u.status = 'RUNNING'; return u; });
                    await jobRunner.startJob(arg);
                    await ctx.reply('✅ Job Started!');
                    return sendUserbotControlMenu(ctx, arg);

                case 'stop':
                    await jsonDb.updateUserbot(arg, u => { u.status = 'STOPPED'; return u; });
                    await jobRunner.stopJob(arg);
                    await ctx.reply('⏹️ Job Stopped!');
                    return sendUserbotControlMenu(ctx, arg);

                case 'delete':
                    await userbotManager.stopClient(arg);
                    await jobRunner.stopJob(arg);
                    // Clean any remaining live monitor progress for this userbot
                    try {
                        liveEvents.clearBroadcastProgress(arg);
                    } catch (e) {
                        console.debug(`Failed to clear live progress for ${arg}: ${e?.message}`);
                    }
                    const dbDel = await jsonDb.read();
                    dbDel.userbots = dbDel.userbots.filter(u => u.id !== arg);
                    delete dbDel.jobs[arg];
                    await jsonDb.write(dbDel);
                    await ctx.reply('🗑️ Userbot Deleted!');
                    return sendUserbotsMenu(ctx);

                case 'scan_groups':
                    await ctx.reply('⏳ Scanning joined groups...');
                    const count = await targetManager.scanJoinedGroups(arg);
                    await ctx.reply(`✅ Ditambahkan ${count} grup baru ke target.`);
                    return sendTargetsMenu(ctx, arg);

                case 'clear_targets':
                    await targetManager.clearTargets(arg);
                    await ctx.reply('✅ Semua target dibersihkan.');
                    return sendTargetsMenu(ctx, arg);

                case 'toggle_timer':
                    await jsonDb.updateUserbot(arg, u => {
                        u.settings.timer.enabled = !u.settings.timer.enabled;
                        return u;
                    });
                    return sendTimerMenu(ctx, arg);

                case 'toggle_pmpermit':
                    await jsonDb.updateUserbot(arg, u => {
                        u.pmPermit.enabled = !u.pmPermit.enabled;
                        return u;
                    });
                    return sendPmPermitMenu(ctx, arg);

                case 'clear_pm_allowed':
                    await jsonDb.updateUserbot(arg, u => {
                        u.pmPermit.allowed = [];
                        return u;
                    });
                    return sendPmPermitMenu(ctx, arg);

                case 'toggle_msg_type':
                    await jsonDb.updateUserbot(arg, u => {
                        u.settings.messageType = u.settings.messageType === 'REGULAR' ? 'FORWARD' : 'REGULAR';
                        return u;
                    });
                    return sendConfigMenu(ctx, arg);

                case 'toggle_spread_mode':
                    await jsonDb.updateUserbot(arg, u => {
                        u.settings.spreadMode = u.settings.spreadMode === 'INSTANT' ? 'SEQUENTIAL' : 'INSTANT';
                        return u;
                    });
                    return sendConfigMenu(ctx, arg);

                case 'clear_watermark':
                    await jsonDb.updateUserbot(arg, u => {
                        u.settings.watermarkText = undefined;
                        return u;
                    });
                    return sendConfigMenu(ctx, arg);

                case 'toggle_resume_mode':
                    await jsonDb.updateUserbot(arg, u => {
                        u.subscription.resumeMode = u.subscription.resumeMode === 'RESUME' ? 'RESET' : 'RESUME';
                        return u;
                    });
                    return sendSubscriptionMenu(ctx, arg);

                // ========== SUBSCRIPTION DURATION SETTING ==========
                case 'set_sub_hourly':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_SUB_HOURS', temp: { userbotId: arg } });
                    await ctx.reply('⏰ <b>Set Subscription Per Jam</b>\n\nKirim jumlah jam:\nContoh: 1, 6, 12, 24', { parse_mode: 'HTML' });
                    return;
                case 'set_sub_daily':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_SUB_DAYS', temp: { userbotId: arg } });
                    await ctx.reply('📅 <b>Set Subscription Per Hari</b>\n\nKirim jumlah hari:\nContoh: 1, 7, 30', { parse_mode: 'HTML' });
                    return;
                case 'set_sub_weekly':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_SUB_WEEKS', temp: { userbotId: arg } });
                    await ctx.reply('📆 <b>Set Subscription Per Minggu</b>\n\nKirim jumlah minggu:\nContoh: 1, 2, 4', { parse_mode: 'HTML' });
                    return;
                case 'set_sub_monthly':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_SUB_MONTHS', temp: { userbotId: arg } });
                    await ctx.reply('🗓️ <b>Set Subscription Per Bulan</b>\n\nKirim jumlah bulan:\nContoh: 1, 3, 6, 12', { parse_mode: 'HTML' });
                    return;
                case 'set_sub_yearly':
                    jasebBot.userStates.set(ctx.from!.id, { step: 'SET_SUB_YEARS', temp: { userbotId: arg } });
                    await ctx.reply('📈 <b>Set Subscription Per Tahun</b>\n\nKirim jumlah tahun:\nContoh: 1, 2, 3', { parse_mode: 'HTML' });
                    return;

                // ========== NEW FEATURES ==========
                case 'toggle_bpm':
                    await jsonDb.updateUserbot(arg, u => {
                        if (!u.settings.broadcastPrivateMessages) {
                            u.settings.broadcastPrivateMessages = { enabled: false, message: undefined, targetCount: 0 };
                        }
                        u.settings.broadcastPrivateMessages.enabled = !u.settings.broadcastPrivateMessages.enabled;
                        return u;
                    });
                    return sendBroadcastPrivateMessagesMenu(ctx, arg);

                case 'execute_bpm':
                    const bpmDb = await jsonDb.read();
                    const bpmUb = bpmDb.userbots.find(u => u.id === arg);
                    if (!bpmUb?.settings.broadcastPrivateMessages?.message) {
                        await ctx.reply('❌ Pesan belum diset');
                        return sendBroadcastPrivateMessagesMenu(ctx, arg);
                    }
                    await ctx.reply('⏳ Memulai broadcast pesan pribadi...');
                    try {
                        const result = await broadcastPrivateMessagesService.broadcastToPrivateChats(arg, bpmUb.settings.broadcastPrivateMessages.message);
                        await ctx.reply(`✅ Broadcast selesai!\n\n• Terkirim: ${result.sent}\n• Gagal: ${result.failed}`);
                    } catch (e: any) {
                        await ctx.reply(`❌ Error: ${e.message}`);
                    }
                    return sendBroadcastPrivateMessagesMenu(ctx, arg);

                case 'toggle_auto_leave':
                    await jsonDb.updateUserbot(arg, u => {
                        if (!u.settings.autoLeave) {
                            u.settings.autoLeave = { enabled: false, leaveAfterDays: 1, leftCount: 0 };
                        }
                        u.settings.autoLeave.enabled = !u.settings.autoLeave.enabled;
                        return u;
                    });
                    return sendAutoLeaveMenu(ctx, arg);

                case 'execute_auto_leave':
                    const alDb = await jsonDb.read();
                    const alUb = alDb.userbots.find(u => u.id === arg);
                    if (!alUb?.settings.autoLeave?.enabled) {
                        await ctx.reply('❌ Auto leave tidak aktif');
                        return sendAutoLeaveMenu(ctx, arg);
                    }
                    await ctx.reply('⏳ Mengecek grup untuk di-leave...');
                    try {
                        const leftCount = await autoLeaveService.autoLeaveOldGroups(arg, alUb.settings.autoLeave.leaveAfterDays);
                        await ctx.reply(`✅ Selesai!\n\n• Keluar dari: ${leftCount} grup`);
                    } catch (e: any) {
                        await ctx.reply(`❌ Error: ${e.message}`);
                    }
                    return sendAutoLeaveMenu(ctx, arg);

                case 'toggle_auto_read':
                    await jsonDb.updateUserbot(arg, u => {
                        if (!u.settings.autoReadChat) {
                            u.settings.autoReadChat = { enabled: false, readGroups: true, readPrivate: true };
                        }
                        u.settings.autoReadChat.enabled = !u.settings.autoReadChat.enabled;
                        return u;
                    });
                    return sendAutoReadChatMenu(ctx, arg);

                case 'toggle_read_groups':
                    await jsonDb.updateUserbot(arg, u => {
                        if (!u.settings.autoReadChat) {
                            u.settings.autoReadChat = { enabled: false, readGroups: true, readPrivate: true };
                        }
                        u.settings.autoReadChat.readGroups = !u.settings.autoReadChat.readGroups;
                        return u;
                    });
                    return sendAutoReadChatMenu(ctx, arg);

                case 'toggle_read_private':
                    await jsonDb.updateUserbot(arg, u => {
                        if (!u.settings.autoReadChat) {
                            u.settings.autoReadChat = { enabled: false, readGroups: true, readPrivate: true };
                        }
                        u.settings.autoReadChat.readPrivate = !u.settings.autoReadChat.readPrivate;
                        return u;
                    });
                    return sendAutoReadChatMenu(ctx, arg);

                case 'execute_auto_read':
                    await ctx.reply('⏳ Membaca semua chat...');
                    try {
                        const arDb = await jsonDb.read();
                        const arUb = arDb.userbots.find(u => u.id === arg);
                        if (arUb?.settings.autoReadChat) {
                            const result = await autoReadChatService.autoReadChats(
                                arg,
                                arUb.settings.autoReadChat.readGroups,
                                arUb.settings.autoReadChat.readPrivate
                            );
                            await ctx.reply(`✅ Selesai!\n\n• Grup dibaca: ${result.groupsRead}\n• Private dibaca: ${result.privateRead}`);
                        }
                    } catch (e: any) {
                        await ctx.reply(`❌ Error: ${e.message}`);
                    }
                    return sendAutoReadChatMenu(ctx, arg);

                case 'toggle_clear_chat':
                    await jsonDb.updateUserbot(arg, u => {
                        if (!u.settings.clearChat) {
                            u.settings.clearChat = { enabled: false, clearGroups: false, clearPrivate: false, deletedCount: 0 };
                        }
                        u.settings.clearChat.enabled = !u.settings.clearChat.enabled;
                        return u;
                    });
                    return sendClearChatMenu(ctx, arg);

                case 'toggle_clear_groups':
                    await jsonDb.updateUserbot(arg, u => {
                        if (!u.settings.clearChat) {
                            u.settings.clearChat = { enabled: false, clearGroups: false, clearPrivate: false, deletedCount: 0 };
                        }
                        u.settings.clearChat.clearGroups = !u.settings.clearChat.clearGroups;
                        return u;
                    });
                    return sendClearChatMenu(ctx, arg);

                case 'toggle_clear_private':
                    await jsonDb.updateUserbot(arg, u => {
                        if (!u.settings.clearChat) {
                            u.settings.clearChat = { enabled: false, clearGroups: false, clearPrivate: false, deletedCount: 0 };
                        }
                        u.settings.clearChat.clearPrivate = !u.settings.clearChat.clearPrivate;
                        return u;
                    });
                    return sendClearChatMenu(ctx, arg);

                case 'execute_clear_chat':
                    await ctx.reply('⏳ Menghapus chat...');
                    try {
                        const ccDb = await jsonDb.read();
                        const ccUb = ccDb.userbots.find(u => u.id === arg);
                        if (ccUb?.settings.clearChat) {
                            const deletedCount = await clearChatService.clearChats(
                                arg,
                                ccUb.settings.clearChat.clearGroups,
                                ccUb.settings.clearChat.clearPrivate,
                                ccUb.settings.clearChat.deleteLimitDays
                            );
                            await ctx.reply(`✅ Selesai!\n\n• Pesan dihapus: ${deletedCount}`);
                        }
                    } catch (e: any) {
                        await ctx.reply(`❌ Error: ${e.message}`);
                    }
                    return sendClearChatMenu(ctx, arg);

                case 'report':
                case 'report_generate':
                    await ctx.reply('⏳ Generating report...');
                    const path = await reportService.generateReport();
                    await ctx.replyWithDocument({ source: path, filename: 'jaseb_report.xlsx' });
                    return;

                case 'clear_cache':
                    await ctx.reply('🧹 Membersihkan cache & junk...');
                    const result = await cacheService.clearAll();
                    const freedMB = (result.totalFreed / 1024 / 1024).toFixed(2);
                    await ctx.reply(`✅ Selesai!\n\n• Cache dibersihkan: ${result.cacheCleared}\n• Junk dibersihkan: ${result.junkCleared}\n• Total dibebaskan: ${freedMB} MB`);
                    return sendMainMenu(ctx);

                case 'monitor_info':
                    const networkInterfaces = os.networkInterfaces();
                    let ips: string[] = [];
                    for (const [name, nets] of Object.entries(networkInterfaces)) {
                        for (const net of nets || []) {
                            if (net.family === 'IPv4' && !net.internal) {
                                ips.push(`${name}: ${net.address}`);
                            }
                        }
                    }
                    
                    const monitorText = `<b>🌐 Monitor URL Info</b>
━━━━━━━━━━━━━━━━━━━━━

<b>📡 Server Info</b>
├ Port: <code>5000</code>
├ Status: 🟢 Online
└ Hostname: <code>${os.hostname()}</code>

<b>🔗 Akses Monitor</b>
├ Internal: <code>http://localhost:5000</code>
└ Replit URL: <i>Lihat di tab Webview</i>

<b>📊 Network Interfaces</b>
${ips.map(ip => `└ ${ip}`).join('\n') || '└ Tidak tersedia'}

<b>💻 System</b>
├ Platform: ${os.platform()}
├ Uptime: ${Math.floor(os.uptime() / 3600)}h ${Math.floor((os.uptime() % 3600) / 60)}m
└ Memory: ${Math.floor(os.freemem() / 1024 / 1024)} MB free

━━━━━━━━━━━━━━━━━━━━━`;

                    await ctx.reply(monitorText, { parse_mode: 'HTML' });
                    return;
            }
        }

        // ========== DIRECT USERBOT SELECTION ==========
        if (data.startsWith('userbot:')) {
            const id = data.split(':')[1];
            return sendUserbotControlMenu(ctx, id);
        }

    } catch (e: any) {
        console.error('Callback error:', e);
        await ctx.reply(`❌ Error: ${e.message}`);
    }
}
function createProgressBar(percentage: number, width: number = 20): string {
    const filled = Math.round((percentage / 100) * width);
    const empty = width - filled;
    const bar = '█'.repeat(filled) + '░'.repeat(empty);
    return `[${bar}]`;
}

function formatTimeDiff(ms: number): string {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ${hours % 24}h`;
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
}

function formatNumber(num: number): string {
    return num.toLocaleString();
}