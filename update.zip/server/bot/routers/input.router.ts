import type { Context } from 'telegraf';
import { jasebBot } from '../bot';
import { targetManager } from '../../jaseb/target/target.manager';
import { linkScanner } from '../../jaseb/link.scanner';
import { jsonDb } from '../../storage/db';
import { sendUserbotControlMenu } from '../menus/userbot.control.menu';
import { sendTargetsMenu } from '../menus/targets.menu';
import { sendTimerMenu } from '../menus/timer.menu';
import { sendPmPermitMenu } from '../menus/pmpermit.menu';
import { sendConfigMenu } from '../menus/config.menu';
import { sendGlobalSettingsMenu } from '../menus/global.settings.menu';
import { validateTimezone } from '../utils/input-handler.util';
import { sendAutoReplyMenu } from '../menus/autoreply.menu';
import { sendBackupMenu } from '../menus/backup.menu';
import { sendBotBroadcastMenu } from '../menus/bot.broadcast.menu';
import { sendSourceMenu } from '../menus/source.menu';
import { sendBroadcastPrivateMessagesMenu } from '../menus/broadcast-private-messages.menu';
import { sendAutoLeaveMenu } from '../menus/auto-leave.menu';
import { sendAutoReadChatMenu } from '../menus/auto-read-chat.menu';
import { sendClearChatMenu } from '../menus/clear-chat.menu';
import { userbotManager } from '../../userbots/userbot.manager';
import { GramJsClient } from '../../userbots/gramjs.client';
import { sendUserbotsMenu } from '../menus/userbots.menu';
import { backupService } from '../../services/backup.service';
import { sourceService } from '../../services/source.service';

export async function handleInput(ctx: Context) {
    const userId = ctx.from?.id;
    if (!userId) return;

    const state = jasebBot.userStates.get(userId);
    // @ts-ignore
    const text = ctx.message?.text;
    // @ts-ignore
    const fwdFrom = ctx.message?.forward_from_chat || ctx.message?.forward_from;
    // @ts-ignore
    const fwdMsgId = ctx.message?.forward_from_message_id || ctx.message?.message_id;
    
    // Handle forwarded messages for AWAIT_FORWARD state
    if (state?.step === 'AWAIT_FORWARD' && fwdFrom) {
        const userbotId = state.temp?.userbotId;
        try {
            const chatId = fwdFrom.id?.toString() || fwdFrom.username;
            const messageId = fwdMsgId;
            
            await jsonDb.updateUserbot(userbotId, (u) => {
                if (!u.settings.forwardedMessage) {
                    u.settings.forwardedMessage = { chatId, messageIds: [] };
                }
                u.settings.forwardedMessage.chatId = chatId;
                if (!u.settings.forwardedMessage.messageIds.includes(messageId)) {
                    u.settings.forwardedMessage.messageIds.push(messageId);
                }
                u.settings.messageType = 'FORWARD';
                return u;
            });
            
            const db = await jsonDb.read();
            const ub = db.userbots.find(u => u.id === userbotId);
            const msgCount = ub?.settings.forwardedMessage?.messageIds?.length || 0;
            
            await ctx.reply(`✅ Pesan forward tersimpan!\n\n📊 Total pesan: ${msgCount}\n\n<i>Forward lagi untuk menambah pesan, atau klik tombol di bawah.</i>`, { 
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: '✅ Selesai', callback_data: `userbot:${userbotId}` }],
                        [{ text: '🗑️ Reset Forward', callback_data: `action:clear_forward:${userbotId}` }]
                    ]
                }
            });
        } catch (e: any) {
            await ctx.reply(`❌ Gagal menyimpan forward: ${e.message}`);
            jasebBot.userStates.delete(userId);
        }
        return;
    }
    
    if (!state || !text) return;

    try {
        // Helper: parse duration like '1h', '12h', '1d', '7d', '1w', '1m' (m=month)
        function parseDuration(str: string): number | null {
            if (!str) return null;
            const s = str.trim().toLowerCase();
            const m = s.match(/^(\d+)\s*(h|hr|hour|hours|d|day|days|w|week|weeks|m|mo|month|months|y|yr|year|years)?$/i);
            if (!m) return null;
            const n = parseInt(m[1], 10);
            const unit = (m[2] || 'd').toLowerCase();
            switch (unit) {
                case 'h': case 'hr': case 'hour': case 'hours': return n * 60 * 60 * 1000;
                case 'd': case 'day': case 'days': return n * 24 * 60 * 60 * 1000;
                case 'w': case 'week': case 'weeks': return n * 7 * 24 * 60 * 60 * 1000;
                case 'm': case 'mo': case 'month': case 'months': return n * 30 * 24 * 60 * 60 * 1000; // approx 30 days
                case 'y': case 'yr': case 'year': case 'years': return n * 365 * 24 * 60 * 60 * 1000;
                default: return null;
            }
        }
        switch (state.step) {
            // ========== PHONE LOGIN FLOW ==========
            case 'PHONE_LOGIN_NUMBER':
                await ctx.reply('⏳ Mengirim kode...');
                const tempClient = new GramJsClient();
                try {
                    await tempClient.connect();
                    const result = await tempClient.sendCode(text);
                    jasebBot.userStates.set(userId, { 
                        step: 'PHONE_LOGIN_CODE', 
                        temp: { phone: text, phoneCodeHash: result.phoneCodeHash, client: tempClient } 
                    });
                    await ctx.reply('📱 Kode terkirim! Masukkan kode yang diterima:\n\nFormat: 12345');
                } catch (e: any) {
                    await ctx.reply(`❌ Gagal kirim kode: ${e.message}`);
                    jasebBot.userStates.delete(userId);
                }
                break;

            case 'PHONE_LOGIN_CODE':
                const loginData = state.temp;
                try {
                    await ctx.reply('⏳ Login...');
                    await loginData.client.client.signInUser(
                        { apiId: loginData.client.client.apiId, apiHash: loginData.client.client.apiHash },
                        {
                            phoneNumber: loginData.phone,
                            phoneCode: async () => text,
                            password: async () => {
                                throw new Error('SESSION_PASSWORD_NEEDED');
                            },
                            onError: (err: any) => { throw err; }
                        }
                    );
                    
                    const me = await loginData.client.getMe();
                    const username = me.username || me.firstName || loginData.phone;
                    const session = loginData.client.getSessionString();
                    
                    jasebBot.userStates.set(userId, { 
                        step: 'ASK_BUYER_ID', 
                        temp: { ...loginData, session, username } 
                    });
                    await ctx.reply(`✅ Login berhasil! Account: @${username}\n\nMasukkan Buyer ID untuk userbot ini:`);
                    
                } catch (e: any) {
                    if (e.message.includes('SESSION_PASSWORD_NEEDED') || e.errorMessage === 'SESSION_PASSWORD_NEEDED') {
                        jasebBot.userStates.set(userId, { 
                            step: 'PHONE_LOGIN_PASSWORD', 
                            temp: loginData 
                        });
                        await ctx.reply('🔐 2FA aktif. Masukkan password:');
                    } else {
                        await ctx.reply(`❌ Login gagal: ${e.message}`);
                        jasebBot.userStates.delete(userId);
                    }
                }
                break;

            case 'PHONE_LOGIN_PASSWORD':
                const pwdData = state.temp;
                try {
                    await ctx.reply('⏳ Verifikasi password...');
                    await pwdData.client.client.signInWithPassword(
                        { apiId: pwdData.client.client.apiId, apiHash: pwdData.client.client.apiHash },
                        {
                            password: async () => text,
                            onError: (err: any) => { throw err; }
                        }
                    );

                    const me = await pwdData.client.getMe();
                    const username = me.username || me.firstName || pwdData.phone;
                    const session = pwdData.client.getSessionString();
                    
                    jasebBot.userStates.set(userId, { 
                        step: 'ASK_BUYER_ID', 
                        temp: { ...pwdData, session, username } 
                    });
                    await ctx.reply(`✅ Login berhasil! Account: @${username}\n\nMasukkan Buyer ID:`);
                } catch (e: any) {
                    await ctx.reply(`❌ Password salah: ${e.message}`);
                    jasebBot.userStates.delete(userId);
                }
                break;

            case 'ASK_BUYER_ID':
                const buyerData = state.temp;
                try {
                    // Ask for subscription duration before creating userbot
                    jasebBot.userStates.set(userId, { step: 'ASK_SUBSCRIPTION', temp: { ...buyerData, buyerId: text } });
                    await ctx.reply('📅 Masukkan durasi subscription untuk userbot ini (contoh: 1h, 12h, 1d, 7d, 1w, 1m):');
                } catch (e: any) {
                    await ctx.reply(`❌ Gagal membuat userbot: ${e.message}`);
                    jasebBot.userStates.delete(userId);
                }
                break;

            // ========== STRING SESSION ADD ==========
            case 'ADD_SESSION_STRING':
                try {
                    await ctx.reply('⏳ Verifikasi session...');
                    const client = new GramJsClient(text);
                    await client.connect();
                    const me = await client.getMe();
                    const username = me.username || me.firstName || 'Unknown';
                    
                    jasebBot.userStates.set(userId, { 
                        step: 'ASK_BUYER_ID_SESSION', 
                        temp: { session: text, username, client } 
                    });
                    await ctx.reply(`✅ Session valid! Account: @${username}\n\nMasukkan Buyer ID:`);
                } catch (e: any) {
                    await ctx.reply(`❌ Session tidak valid: ${e.message}`);
                    jasebBot.userStates.delete(userId);
                }
                break;

            case 'ASK_BUYER_ID_SESSION':
                const sessData = state.temp;
                try {
                    // Ask for subscription duration before creating userbot
                    jasebBot.userStates.set(userId, { step: 'ASK_SUBSCRIPTION_SESSION', temp: { ...sessData, buyerId: text } });
                    await ctx.reply('📅 Masukkan durasi subscription untuk userbot ini (contoh: 1h, 12h, 1d, 7d, 1w, 1m):');
                } catch (e: any) {
                    await ctx.reply(`❌ Gagal: ${e.message}`);
                    jasebBot.userStates.delete(userId);
                }
                break;

            // ========== NEW: ASK SUBSCRIPTION FOR PHONE LOGIN ==========
            case 'ASK_SUBSCRIPTION':
                {
                    const temp = state.temp;
                    const durationMs = parseDuration(text);
                    if (!durationMs) {
                        await ctx.reply('❌ Format durasi tidak valid. Gunakan contoh: 1h, 12h, 1d, 7d, 1w, 1m');
                        return;
                    }
                    try {
                        const u = await userbotManager.create({
                            label: temp.username,
                            buyerId: temp.buyerId,
                            auth: { type: 'PHONE_LOGIN', stringSession: temp.session, phoneNumber: temp.phone }
                        });

                        // update subscription fields
                        await jsonDb.updateUserbot(u.id, (ub) => {
                            const now = Date.now();
                            ub.subscription.startedAt = now;
                            ub.subscription.expireAt = now + durationMs;
                            ub.subscription.durationMs = durationMs;
                            ub.subscription.durationDays = Math.ceil(durationMs / (24 * 60 * 60 * 1000));
                            ub.subscription.active = true;
                            ub.subscription.autoOffApplied = false;
                            ub.subscription.buyerName = temp.buyerId;
                            return ub;
                        });

                        await userbotManager.startClient(u.id);
                        await temp.client.disconnect();

                        await ctx.reply(`✅ Userbot berhasil dibuat dan diberi subscription!\n\n📋 Label: ${u.label}\n👤 Buyer: ${temp.buyerId}\n🆔 ID: ${u.id}`);
                        jasebBot.userStates.delete(userId);
                        await sendUserbotsMenu(ctx);
                    } catch (e: any) {
                        await ctx.reply(`❌ Gagal membuat userbot: ${e.message}`);
                        jasebBot.userStates.delete(userId);
                    }
                }
                break;

            // ========== NEW: ASK SUBSCRIPTION FOR SESSION STRING ==========
            case 'ASK_SUBSCRIPTION_SESSION':
                {
                    const temp = state.temp;
                    const durationMs = parseDuration(text);
                    if (!durationMs) {
                        await ctx.reply('❌ Format durasi tidak valid. Gunakan contoh: 1h, 12h, 1d, 7d, 1w, 1m');
                        return;
                    }
                    try {
                        const u = await userbotManager.create({
                            label: temp.username,
                            buyerId: temp.buyerId,
                            auth: { type: 'STRING_SESSION', stringSession: temp.session }
                        });

                        await jsonDb.updateUserbot(u.id, (ub) => {
                            const now = Date.now();
                            ub.subscription.startedAt = now;
                            ub.subscription.expireAt = now + durationMs;
                            ub.subscription.durationMs = durationMs;
                            ub.subscription.durationDays = Math.ceil(durationMs / (24 * 60 * 60 * 1000));
                            ub.subscription.active = true;
                            ub.subscription.autoOffApplied = false;
                            ub.subscription.buyerName = temp.buyerId;
                            return ub;
                        });

                        await userbotManager.startClient(u.id);
                        await temp.client.disconnect();

                        await ctx.reply(`✅ Userbot berhasil dibuat dan diberi subscription!\n\n📋 Label: ${u.label}\n👤 Buyer: ${temp.buyerId}\n🆔 ID: ${u.id}`);
                        jasebBot.userStates.delete(userId);
                        await sendUserbotsMenu(ctx);
                    } catch (e: any) {
                        await ctx.reply(`❌ Gagal membuat userbot: ${e.message}`);
                        jasebBot.userStates.delete(userId);
                    }
                }
                break;

            // ========== SETTINGS ==========
            case 'SET_REG_TEXT':
                const regTextId = state.temp.userbotId;
                await jsonDb.updateUserbot(regTextId, (u) => {
                    u.settings.regularText = text;
                    u.settings.messageType = 'REGULAR';
                    return u;
                });
                await ctx.reply('✅ Regular text berhasil disimpan!');
                await sendUserbotControlMenu(ctx, regTextId);
                jasebBot.userStates.delete(userId);
                break;

            case 'SET_WATERMARK':
                const wmId = state.temp.userbotId;
                await jsonDb.updateUserbot(wmId, (u) => {
                    u.settings.watermarkText = text;
                    return u;
                });
                await ctx.reply('✅ Watermark berhasil disimpan!');
                await sendConfigMenu(ctx, wmId);
                jasebBot.userStates.delete(userId);
                break;

            // ========== TARGETS ==========
            case 'ADD_TARGET_MANUAL':
                const ubId = state.temp.userbotId;
                await ctx.reply('⏳ Resolving target...');
                const res = await targetManager.addManualTarget(ubId, text);
                await ctx.reply(res.success ? `✅ ${res.message}` : `❌ ${res.message}`);
                await sendTargetsMenu(ctx, ubId);
                jasebBot.userStates.delete(userId);
                break;

            case 'SCAN_CHANNEL':
                const scanId = state.temp.userbotId;
                await ctx.reply('⏳ Scanning channel untuk link grup...');
                try {
                    const count = await linkScanner.scanChannelForLinks(scanId, text);
                    await ctx.reply(`✅ Scan selesai! Bergabung ke ${count} grup baru.`);
                } catch (e: any) {
                    await ctx.reply(`❌ Scan gagal: ${e.message}`);
                }
                await sendTargetsMenu(ctx, scanId);
                jasebBot.userStates.delete(userId);
                break;

            case 'SEARCH_KEYWORD':
                const searchId = state.temp.userbotId;
                await ctx.reply('⏳ Mencari grup...');
                try {
                    const count = await targetManager.searchAndJoinGroups(searchId, text);
                    await ctx.reply(`✅ Pencarian selesai! Bergabung ke ${count} grup baru.`);
                } catch (e: any) {
                    await ctx.reply(`❌ Pencarian gagal: ${e.message}`);
                }
                await sendTargetsMenu(ctx, searchId);
                jasebBot.userStates.delete(userId);
                break;

            // ========== TIMER ==========
            case 'SET_TIMER_START':
                const timerStartId = state.temp.userbotId;
                if (!/^\d{2}:\d{2}$/.test(text)) {
                    await ctx.reply('❌ Format salah. Gunakan HH:MM (contoh: 08:00)');
                    return;
                }
                await jsonDb.updateUserbot(timerStartId, (u) => {
                    u.settings.timer.startAt = text;
                    return u;
                });
                await ctx.reply(`✅ Jam mulai diset: ${text}`);
                await sendTimerMenu(ctx, timerStartId);
                jasebBot.userStates.delete(userId);
                break;

            case 'SET_TIMER_STOP':
                const timerStopId = state.temp.userbotId;
                if (!/^\d{2}:\d{2}$/.test(text)) {
                    await ctx.reply('❌ Format salah. Gunakan HH:MM (contoh: 22:00)');
                    return;
                }
                await jsonDb.updateUserbot(timerStopId, (u) => {
                    u.settings.timer.stopAt = text;
                    return u;
                });
                await ctx.reply(`✅ Jam berhenti diset: ${text}`);
                await sendTimerMenu(ctx, timerStopId);
                jasebBot.userStates.delete(userId);
                break;

            // ========== PM PERMIT ==========
            case 'SET_PM_TEMPLATE':
                const pmTplId = state.temp.userbotId;
                await jsonDb.updateUserbot(pmTplId, (u) => {
                    u.pmPermit.template = text;
                    return u;
                });
                await ctx.reply('✅ Template PM Permit disimpan!');
                await sendPmPermitMenu(ctx, pmTplId);
                jasebBot.userStates.delete(userId);
                break;

            case 'ADD_PM_ALLOW':
                const pmAllowId = state.temp.userbotId;
                await jsonDb.updateUserbot(pmAllowId, (u) => {
                    if (!u.pmPermit.allowed.includes(text)) {
                        u.pmPermit.allowed.push(text);
                    }
                    return u;
                });
                await ctx.reply(`✅ User ${text} ditambahkan ke whitelist.`);
                await sendPmPermitMenu(ctx, pmAllowId);
                jasebBot.userStates.delete(userId);
                break;

            // ========== AUTO REPLY KEYWORD ==========
            case 'ADD_AUTOREPLY_KEYWORD':
                const arKwId = state.temp.userbotId;
                await jsonDb.updateUserbot(arKwId, (u) => {
                    if (!u.autoReplyKeyword) {
                        u.autoReplyKeyword = { enabled: false, keywords: [], useForward: false };
                    }
                    if (!u.autoReplyKeyword.keywords.includes(text.toLowerCase())) {
                        u.autoReplyKeyword.keywords.push(text.toLowerCase());
                    }
                    return u;
                });
                await ctx.reply(`✅ Keyword ditambahkan: ${text}`);
                await sendAutoReplyMenu(ctx, arKwId);
                jasebBot.userStates.delete(userId);
                break;

            case 'SET_AUTOREPLY_TEXT':
                const arTextId = state.temp.userbotId;
                await jsonDb.updateUserbot(arTextId, (u) => {
                    if (!u.autoReplyKeyword) {
                        u.autoReplyKeyword = { enabled: false, keywords: [], useForward: false };
                    }
                    u.autoReplyKeyword.replyText = text;
                    return u;
                });
                await ctx.reply('✅ Reply text disimpan!');
                await sendAutoReplyMenu(ctx, arTextId);
                jasebBot.userStates.delete(userId);
                break;

            // ========== DELAYS ==========
            case 'SET_INSTANT_DELAY':
                const instDelayId = state.temp.userbotId;
                const instDelay = parseInt(text);
                if (isNaN(instDelay) || instDelay < 60) {
                    await ctx.reply('❌ Delay harus angka >= 60 detik');
                    return;
                }
                await jsonDb.updateUserbot(instDelayId, (u) => {
                    u.settings.delays.instantLoopDelaySec = instDelay;
                    return u;
                });
                await ctx.reply(`✅ Instant loop delay: ${instDelay} detik`);
                await sendConfigMenu(ctx, instDelayId);
                jasebBot.userStates.delete(userId);
                break;

            case 'SET_SEQ_DELAY':
                const seqDelayId = state.temp.userbotId;
                const seqDelay = parseInt(text);
                if (isNaN(seqDelay) || seqDelay < 5) {
                    await ctx.reply('❌ Delay harus angka >= 5 detik');
                    return;
                }
                await jsonDb.updateUserbot(seqDelayId, (u) => {
                    u.settings.delays.sequentialPerGroupDelaySec = seqDelay;
                    return u;
                });
                await ctx.reply(`✅ Sequential delay: ${seqDelay} detik`);
                await sendConfigMenu(ctx, seqDelayId);
                jasebBot.userStates.delete(userId);
                break;

            // ========== GLOBAL SETTINGS ==========
            case 'GLOBAL_INSTANT_DELAY':
                const gInstDelay = parseInt(text);
                if (isNaN(gInstDelay) || gInstDelay < 60) {
                    await ctx.reply('❌ Delay harus >= 60 detik');
                    return;
                }
                await jsonDb.updateGlobalSettings(s => {
                    s.defaultInstantDelay = gInstDelay;
                    return s;
                });
                await ctx.reply(`✅ Global instant delay: ${gInstDelay}s`);
                await sendGlobalSettingsMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            case 'GLOBAL_SEQ_DELAY':
                const gSeqDelay = parseInt(text);
                if (isNaN(gSeqDelay) || gSeqDelay < 5) {
                    await ctx.reply('❌ Delay harus >= 5 detik');
                    return;
                }
                await jsonDb.updateGlobalSettings(s => {
                    s.defaultSequentialDelay = gSeqDelay;
                    return s;
                });
                await ctx.reply(`✅ Global sequential delay: ${gSeqDelay}s`);
                await sendGlobalSettingsMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            case 'GLOBAL_MAX_TARGETS':
                const maxT = parseInt(text);
                if (isNaN(maxT) || maxT < 1) {
                    await ctx.reply('❌ Harus angka positif');
                    return;
                }
                await jsonDb.updateGlobalSettings(s => {
                    s.maxTargetsPerUserbot = maxT;
                    return s;
                });
                await ctx.reply(`✅ Max targets: ${maxT}`);
                await sendGlobalSettingsMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            case 'GLOBAL_JOIN_DELAY':
                const joinD = parseInt(text);
                if (isNaN(joinD) || joinD < 1000) {
                    await ctx.reply('❌ Harus >= 1000 ms');
                    return;
                }
                await jsonDb.updateGlobalSettings(s => {
                    s.autoJoinDelay = joinD;
                    return s;
                });
                await ctx.reply(`✅ Join delay: ${joinD}ms`);
                await sendGlobalSettingsMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            case 'GLOBAL_WATERMARK':
                await jsonDb.updateGlobalSettings(s => {
                    s.defaultWatermark = text;
                    return s;
                });
                await ctx.reply('✅ Global watermark disimpan!');
                await sendGlobalSettingsMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            case 'GLOBAL_ADD_BLACKLIST':
                await jsonDb.updateGlobalSettings(s => {
                    if (!s.globalBlacklist.includes(text)) {
                        s.globalBlacklist.push(text);
                    }
                    return s;
                });
                await ctx.reply(`✅ ${text} ditambahkan ke blacklist`);
                await sendGlobalSettingsMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            // ========== BACKUP ==========
            case 'SET_BACKUP_CHANNEL':
                await backupService.updateSettings({ channelId: text });
                await ctx.reply(`✅ Channel backup diset: ${text}`);
                await sendBackupMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            case 'SET_BACKUP_TIME':
                if (!/^\d{2}:\d{2}$/.test(text)) {
                    await ctx.reply('❌ Format salah. Gunakan HH:MM');
                    return;
                }
                const [hour, minute] = text.split(':');
                const db = await jsonDb.read();
                const currentSchedule = (db as any).backupSettings?.schedule || { day: '*', hour: '00', minute: '00' };
                await backupService.updateSettings({ 
                    schedule: { ...currentSchedule, hour, minute } 
                });
                await ctx.reply(`✅ Jam backup diset: ${text}`);
                await sendBackupMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            case 'SET_BACKUP_DAY':
                if (text !== '*' && (isNaN(parseInt(text)) || parseInt(text) < 1 || parseInt(text) > 31)) {
                    await ctx.reply('❌ Masukkan * atau angka 1-31');
                    return;
                }
                const dbDay = await jsonDb.read();
                const currSchedule = (dbDay as any).backupSettings?.schedule || { day: '*', hour: '00', minute: '00' };
                await backupService.updateSettings({ 
                    schedule: { ...currSchedule, day: text } 
                });
                await ctx.reply(`✅ Hari backup diset: ${text === '*' ? 'Setiap hari' : 'Tanggal ' + text}`);
                await sendBackupMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            // ========== BOT BROADCAST ==========
            case 'ADD_BC_TARGET':
                const dbBc = await jsonDb.read();
                (dbBc as any).botBroadcast = (dbBc as any).botBroadcast || { mode: 'CHANNEL', targets: [], message: null };
                if (!(dbBc as any).botBroadcast.targets.includes(text)) {
                    (dbBc as any).botBroadcast.targets.push(text);
                }
                await jsonDb.write(dbBc);
                await ctx.reply(`✅ Target ditambahkan: ${text}`);
                await sendBotBroadcastMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            case 'SET_BC_MESSAGE':
                const dbMsg = await jsonDb.read();
                (dbMsg as any).botBroadcast = (dbMsg as any).botBroadcast || { mode: 'CHANNEL', targets: [], message: null };
                (dbMsg as any).botBroadcast.message = text;
                await jsonDb.write(dbMsg);
                await ctx.reply('✅ Pesan broadcast disimpan!');
                await sendBotBroadcastMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            // ========== SOURCE ==========
            case 'SOURCE_CUSTOM_NAME':
                await ctx.reply('⏳ Membuat archive...');
                try {
                    const filePath = await sourceService.exportSource({ mode: 'script_only', customName: text });
                    await ctx.replyWithDocument({ source: filePath, filename: `${text}.zip` });
                    await ctx.reply('✅ Export berhasil!');
                } catch (e: any) {
                    await ctx.reply(`❌ Gagal: ${e.message}`);
                }
                await sendSourceMenu(ctx);
                jasebBot.userStates.delete(userId);
                break;

            // ========== SUBSCRIPTION DURATION SETTING (Per Jam/Hari/Minggu/Bulan/Tahun) ==========
            case 'SET_SUB_HOURS':
                {
                    const subId = state.temp.userbotId;
                    const hours = parseInt(text.trim());
                    if (isNaN(hours) || hours < 1) {
                        await ctx.reply('❌ Masukkan angka jam yang valid (min 1)');
                        return;
                    }
                    const durationMs = hours * 60 * 60 * 1000;
                    const now = Date.now();
                    await jsonDb.updateUserbot(subId, (u) => {
                        u.subscription.startedAt = now;
                        u.subscription.expireAt = now + durationMs;
                        u.subscription.durationMs = durationMs;
                        u.subscription.durationDays = Math.ceil(durationMs / (24 * 60 * 60 * 1000));
                        u.subscription.active = true;
                        u.subscription.autoOffApplied = false;
                        return u;
                    });
                    await ctx.reply(`✅ Subscription diset: <b>${hours} jam</b>\n\nBerakhir: ${new Date(now + durationMs).toLocaleString('id-ID')}`, { parse_mode: 'HTML' });
                    await sendSubscriptionMenu(ctx, subId);
                    jasebBot.userStates.delete(userId);
                }
                break;

            case 'SET_SUB_DAYS':
                {
                    const subId = state.temp.userbotId;
                    const days = parseInt(text.trim());
                    if (isNaN(days) || days < 1) {
                        await ctx.reply('❌ Masukkan angka hari yang valid (min 1)');
                        return;
                    }
                    const durationMs = days * 24 * 60 * 60 * 1000;
                    const now = Date.now();
                    await jsonDb.updateUserbot(subId, (u) => {
                        u.subscription.startedAt = now;
                        u.subscription.expireAt = now + durationMs;
                        u.subscription.durationMs = durationMs;
                        u.subscription.durationDays = days;
                        u.subscription.active = true;
                        u.subscription.autoOffApplied = false;
                        return u;
                    });
                    await ctx.reply(`✅ Subscription diset: <b>${days} hari</b>\n\nBerakhir: ${new Date(now + durationMs).toLocaleString('id-ID')}`, { parse_mode: 'HTML' });
                    await sendSubscriptionMenu(ctx, subId);
                    jasebBot.userStates.delete(userId);
                }
                break;

            case 'SET_SUB_WEEKS':
                {
                    const subId = state.temp.userbotId;
                    const weeks = parseInt(text.trim());
                    if (isNaN(weeks) || weeks < 1) {
                        await ctx.reply('❌ Masukkan angka minggu yang valid (min 1)');
                        return;
                    }
                    const days = weeks * 7;
                    const durationMs = days * 24 * 60 * 60 * 1000;
                    const now = Date.now();
                    await jsonDb.updateUserbot(subId, (u) => {
                        u.subscription.startedAt = now;
                        u.subscription.expireAt = now + durationMs;
                        u.subscription.durationMs = durationMs;
                        u.subscription.durationDays = days;
                        u.subscription.active = true;
                        u.subscription.autoOffApplied = false;
                        return u;
                    });
                    await ctx.reply(`✅ Subscription diset: <b>${weeks} minggu (${days} hari)</b>\n\nBerakhir: ${new Date(now + durationMs).toLocaleString('id-ID')}`, { parse_mode: 'HTML' });
                    await sendSubscriptionMenu(ctx, subId);
                    jasebBot.userStates.delete(userId);
                }
                break;

            case 'SET_SUB_MONTHS':
                {
                    const subId = state.temp.userbotId;
                    const months = parseInt(text.trim());
                    if (isNaN(months) || months < 1) {
                        await ctx.reply('❌ Masukkan angka bulan yang valid (min 1)');
                        return;
                    }
                    const days = months * 30;
                    const durationMs = days * 24 * 60 * 60 * 1000;
                    const now = Date.now();
                    await jsonDb.updateUserbot(subId, (u) => {
                        u.subscription.startedAt = now;
                        u.subscription.expireAt = now + durationMs;
                        u.subscription.durationMs = durationMs;
                        u.subscription.durationDays = days;
                        u.subscription.active = true;
                        u.subscription.autoOffApplied = false;
                        return u;
                    });
                    await ctx.reply(`✅ Subscription diset: <b>${months} bulan (~${days} hari)</b>\n\nBerakhir: ${new Date(now + durationMs).toLocaleString('id-ID')}`, { parse_mode: 'HTML' });
                    await sendSubscriptionMenu(ctx, subId);
                    jasebBot.userStates.delete(userId);
                }
                break;

            case 'SET_SUB_YEARS':
                {
                    const subId = state.temp.userbotId;
                    const years = parseInt(text.trim());
                    if (isNaN(years) || years < 1) {
                        await ctx.reply('❌ Masukkan angka tahun yang valid (min 1)');
                        return;
                    }
                    const days = years * 365;
                    const durationMs = days * 24 * 60 * 60 * 1000;
                    const now = Date.now();
                    await jsonDb.updateUserbot(subId, (u) => {
                        u.subscription.startedAt = now;
                        u.subscription.expireAt = now + durationMs;
                        u.subscription.durationMs = durationMs;
                        u.subscription.durationDays = days;
                        u.subscription.active = true;
                        u.subscription.autoOffApplied = false;
                        return u;
                    });
                    await ctx.reply(`✅ Subscription diset: <b>${years} tahun (${days} hari)</b>\n\nBerakhir: ${new Date(now + durationMs).toLocaleString('id-ID')}`, { parse_mode: 'HTML' });
                    await sendSubscriptionMenu(ctx, subId);
                    jasebBot.userStates.delete(userId);
                }
                break;

            // ========== SUBSCRIPTION ==========
            case 'EXTEND_SUBSCRIPTION':
                {
                    const subId = state.temp.userbotId;
                    const durationMs = parseDuration(text);
                    if (!durationMs) {
                        await ctx.reply('❌ Format durasi tidak valid. Gunakan contoh: 1h, 12h, 1d, 7d, 1w, 1m');
                        return;
                    }
                    await jsonDb.updateUserbot(subId, (u) => {
                        const now = Date.now();
                        const base = u.subscription.expireAt > now ? u.subscription.expireAt : now;
                        u.subscription.expireAt = base + durationMs;
                        u.subscription.durationMs = (u.subscription.durationMs || 0) + durationMs;
                        u.subscription.durationDays = Math.ceil((u.subscription.durationMs || 0) / (24 * 60 * 60 * 1000));
                        u.subscription.active = true;
                        u.subscription.autoOffApplied = false;
                        return u;
                    });
                    await ctx.reply('✅ Subscription diperpanjang!');
                    await sendUserbotControlMenu(ctx, subId);
                    jasebBot.userStates.delete(userId);
                }
                break;

            // ========== NEW FEATURES ==========
            case 'GLOBAL_SET_TIMEZONE':
                {
                    const inputTz = text.trim();
                    const validated = validateTimezone(inputTz);
                    if (!validated.valid || !validated.value) {
                        await ctx.reply('❌ Timezone tidak valid. Contoh: Asia/Jakarta atau WIB');
                        return;
                    }

                    try {
                        await jsonDb.updateGlobalSettings(s => {
                            s.timezone = validated.value!;
                            return s;
                        });
                        await ctx.reply(`✅ Timezone diset ke: ${validated.value}\n\n💡 Ini akan diterapkan untuk timer semua userbot.`);
                        await sendGlobalSettingsMenu(ctx);
                    } catch (e: any) {
                        await ctx.reply(`❌ Error: ${e.message}`);
                    }

                    jasebBot.userStates.delete(userId);
                }
                break;

            case 'JOIN_LIST':
                {
                    const userbotId = state.temp.userbotId;
                    const payload = text.trim();
                    if (!payload) {
                        await ctx.reply('❌ Kirim daftar link/username/ID (pisah baris)');
                        return;
                    }

                    // Parse optional options on top lines
                    const lines = payload.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
                    const options: any = {};
                    const entries: string[] = [];
                    for (const line of lines) {
                        const up = line.toUpperCase();
                        if (up.startsWith('DELAY:')) {
                            options.joinDelayMs = parseInt(line.split(':')[1]) || 3000;
                            continue;
                        }
                        if (up.startsWith('BATCH:')) {
                            options.batchSize = parseInt(line.split(':')[1]) || 5;
                            continue;
                        }
                        if (up.startsWith('PAUSE:')) {
                            options.batchPauseMs = parseInt(line.split(':')[1]) || 60000;
                            continue;
                        }
                        entries.push(line);
                    }

                    try {
                        if (entries.length === 0) {
                            await ctx.reply('❌ Tidak ada grup/channel yang dideteksi');
                            jasebBot.userStates.delete(userId);
                            return;
                        }

                        const progressMsg = await ctx.reply(`⏳ <b>Auto Join Started</b>
\nMemproses: ${entries.length} grup\nDelay: ${options.joinDelayMs}ms\nBatch: ${options.batchSize}\nPause: ${(options.batchPauseMs/1000).toFixed(0)}s\n\n<i>Prosesnya akan berjalan di background...</i>`, { parse_mode: 'HTML' });
                        
                        const result = await targetManager.joinFromList(userbotId, entries.join('\n'), options);
                        
                        await ctx.telegram.editMessageText(
                          progressMsg.chat.id,
                          progressMsg.message_id,
                          undefined,
                          `✅ <b>Auto Join Completed</b>\n\nTotal: ${result.processed}\n✅ Bergabung: ${result.joined}\n⏭️ Skip: ${result.skipped}\n❌ Gagal: ${result.failed}\n\n<i>Grup baru ditambahkan ke target list</i>`,
                          { parse_mode: 'HTML' }
                        );
                        
                        await sendTargetsMenu(ctx, userbotId);
                    } catch (e: any) {
                        await ctx.reply(`❌ Gagal: ${e.message}`);
                    }

                    jasebBot.userStates.delete(userId);
                }
                break;

            case 'BPM_MESSAGE':
                const bpmId = state.temp.userbotId;
                await jsonDb.updateUserbot(bpmId, (u) => {
                    if (!u.settings.broadcastPrivateMessages) {
                        u.settings.broadcastPrivateMessages = { enabled: false, message: undefined, targetCount: 0 };
                    }
                    u.settings.broadcastPrivateMessages.message = text;
                    return u;
                });
                await ctx.reply('✅ Pesan broadcast pribadi disimpan!');
                await sendBroadcastPrivateMessagesMenu(ctx, bpmId);
                jasebBot.userStates.delete(userId);
                break;

            case 'AUTO_LEAVE_DAYS':
                const alId = state.temp.userbotId;
                const alDays = parseInt(text);
                if (isNaN(alDays) || alDays < 1) {
                    await ctx.reply('❌ Masukkan angka hari yang valid (min 1)');
                    return;
                }
                await jsonDb.updateUserbot(alId, (u) => {
                    if (!u.settings.autoLeave) {
                        u.settings.autoLeave = { enabled: false, leaveAfterDays: 1, leftCount: 0 };
                    }
                    u.settings.autoLeave.leaveAfterDays = alDays;
                    return u;
                });
                await ctx.reply(`✅ Auto leave diset: ${alDays} hari`);
                await sendAutoLeaveMenu(ctx, alId);
                jasebBot.userStates.delete(userId);
                break;

            case 'CLEAR_CHAT_DAYS':
                const ccId = state.temp.userbotId;
                const ccDays = parseInt(text);
                if (isNaN(ccDays) || ccDays < 1) {
                    await ctx.reply('❌ Masukkan angka hari yang valid (min 1)');
                    return;
                }
                await jsonDb.updateUserbot(ccId, (u) => {
                    if (!u.settings.clearChat) {
                        u.settings.clearChat = { enabled: false, clearGroups: false, clearPrivate: false, deletedCount: 0 };
                    }
                    u.settings.clearChat.deleteLimitDays = ccDays;
                    return u;
                });
                await ctx.reply(`✅ Clear chat limit diset: ${ccDays} hari`);
                await sendClearChatMenu(ctx, ccId);
                jasebBot.userStates.delete(userId);
                break;
        }
    } catch (e: any) {
        console.error('Input handler error:', e);
        ctx.reply(`❌ Error: ${e.message}`);
        jasebBot.userStates.delete(userId);
    }
}
