import fs from 'fs-extra';
import path from 'path';
import { ENV } from '../config/env';
import { CONSTANTS } from '../config/constants';
import { locks } from './locks';
import { DatabaseSchema, type Database, type Userbot, type GlobalSettings } from '@shared/schema';
import pino from 'pino';

const logger = pino({ level: ENV.LOG_LEVEL });
const dbPath = path.join(ENV.DATA_DIR, CONSTANTS.DB_FILE);

fs.ensureDirSync(ENV.DATA_DIR);

const defaultGlobalSettings: GlobalSettings = {
  defaultInstantDelay: 60,
  defaultSequentialDelay: 10,
  defaultWatermark: undefined,
  defaultPremiumEmoji: false,
  globalBlacklist: [],
  antiSpamCooldown: 5,
  maxTargetsPerUserbot: 500,
  autoJoinDelay: 5000,
  floodWaitMultiplier: 1.5,
  timezone: "Asia/Jakarta", // WIB default
};

const defaultDb: Database = {
  userbots: [],
  jobs: {},
  globalSettings: defaultGlobalSettings,
};

export class JsonStorage {
  async read(): Promise<Database> {
    return await locks.db.runExclusive(async () => {
      try {
        if (!await fs.pathExists(dbPath)) {
          await fs.writeJSON(dbPath, defaultDb, { spaces: 2 });
          return defaultDb;
        }
        const data = await fs.readJSON(dbPath);
        // Merge with defaults for missing fields
        return { 
          ...defaultDb, 
          ...data,
          globalSettings: { ...defaultGlobalSettings, ...data.globalSettings }
        };
      } catch (error) {
        logger.error(error, 'Failed to read DB');
        return defaultDb;
      }
    });
  }

  async write(data: Database): Promise<void> {
    await locks.db.runExclusive(async () => {
      await fs.writeJSON(dbPath, data, { spaces: 2 });
    });
  }

  async updateUserbot(id: string, updateFn: (u: Userbot) => Userbot): Promise<Userbot | null> {
    const db = await this.read();
    const index = db.userbots.findIndex(u => u.id === id);
    if (index === -1) return null;

    const updated = updateFn(db.userbots[index]);
    db.userbots[index] = updated;
    await this.write(db);
    return updated;
  }

  async updateGlobalSettings(updateFn: (s: GlobalSettings) => GlobalSettings): Promise<GlobalSettings> {
    const db = await this.read();
    const settings = db.globalSettings || defaultGlobalSettings;
    const updated = updateFn(settings);
    db.globalSettings = updated;
    await this.write(db);
    return updated;
  }

  async getGlobalSettings(): Promise<GlobalSettings> {
    const db = await this.read();
    return db.globalSettings || defaultGlobalSettings;
  }
}

export const jsonDb = new JsonStorage();
