import { GramJsClient } from './gramjs.client';
import { jsonDb } from '../storage/db';
import { getUserbotLock } from '../storage/locks';
import { UserbotSchema, type Userbot } from '@shared/schema';
import { v4 as uuidv4 } from 'uuid';
import pino from 'pino';
import { setupUserbotEvents } from './events.wiring';
import { liveEvents } from '../utils/live-events';

const logger = pino({ level: 'info' });

export class UserbotManager {
  private clients = new Map<string, GramJsClient>();

  async loadAll() {
    const db = await jsonDb.read();
    for (const userbot of db.userbots) {
      if (userbot.status !== 'OFF_SUBS' && userbot.status !== 'STOPPED') {
        try {
            await this.startClient(userbot.id);
        } catch (e: any) {
            logger.error(`Failed to start userbot ${userbot.label}: ${e?.message}`);
        }
      }
    }
  }

  async startClient(id: string) {
    const lock = getUserbotLock(id);
    await lock.runExclusive(async () => {
      const db = await jsonDb.read();
      const userbot = db.userbots.find(u => u.id === id);
      if (!userbot || !userbot.auth.stringSession) return;

      if (this.clients.has(id)) return; // Already running

      const client = new GramJsClient(userbot.auth.stringSession);
      try {
        await client.connect();
        this.clients.set(id, client);
        
        // Setup Events
        setupUserbotEvents(client, id);
        
        // Auto-update label with real username
        try {
          const me = await client.getMe();
          // @ts-ignore
          const realUsername = me.username || me.firstName || userbot.label;
          if (realUsername && realUsername !== userbot.label) {
            await jsonDb.updateUserbot(id, u => {
              u.label = realUsername;
              return u;
            });
            logger.info(`Userbot ${realUsername} connected`);
          } else {
            logger.info(`Userbot ${userbot.label} connected`);
          }
        } catch (e) {
          logger.info(`Userbot ${userbot.label} connected`);
        }
      } catch (e: any) {
        logger.error(`Failed to connect ${userbot.label}: ${e?.message}`);
        throw e;
      }
    });
  }

  async stopClient(id: string) {
      const client = this.clients.get(id);
      if (client) {
          await client.disconnect();
          this.clients.delete(id);
          // ensure no leftover live monitor progress remains for this client
          try {
            liveEvents.clearBroadcastProgress(id);
          } catch (e) {
            logger.debug(`Failed to clear live progress for ${id}: ${e?.message}`);
          }
      }
  }
  
  getClient(id: string) {
      return this.clients.get(id);
  }

  async create(data: Partial<Userbot>): Promise<Userbot> {
      const id = uuidv4();
      const trackingId = uuidv4(); // ID unik untuk tracking
      const now = Date.now();
      
      const newUserbot: Userbot = {
          id,
          label: data.label || 'Unnamed',
          buyerId: data.buyerId || 'admin',
          auth: {
              type: data.auth?.type || 'STRING_SESSION',
              stringSession: data.auth?.stringSession,
              phoneNumber: data.auth?.phoneNumber
          },
          subscription: {
              active: true,
              expireAt: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days default
              autoOffApplied: false,
              resumeMode: 'RESUME',
              startedAt: now,
              durationMs: 30 * 24 * 60 * 60 * 1000,
              durationDays: 30,
              buyerName: data.buyerId || 'admin',
              uniqueTrackingId: trackingId
          },
          status: 'READY',
          settings: {
              messageType: 'REGULAR',
              spreadMode: 'INSTANT',
              delays: {
                  instantLoopDelaySec: 60,
                  sequentialPerGroupDelaySec: 10
              },
              targets: [],
              timer: { enabled: false, startAt: '08:00', stopAt: '22:00' },
              regularText: 'Hello from JASEB Bot!',
              // New feature defaults
              broadcastPrivateMessages: {
                  enabled: false,
                  message: undefined,
                  targetCount: 0
              },
              autoLeave: {
                  enabled: false,
                  leaveAfterDays: 1,
                  leftCount: 0
              },
              autoReadChat: {
                  enabled: false,
                  readGroups: true,
                  readPrivate: true
              },
              clearChat: {
                  enabled: false,
                  clearGroups: false,
                  clearPrivate: false,
                  deletedCount: 0
              },
              messageDelivery: {
                  mentionAllMembers: false,
                  showTypingIndicator: false,
                  typingDelayMs: 1000,
                  randomizeTyping: false
              }
          },
          pmPermit: {
              enabled: false,
              template: 'I am busy right now.',
              allowed: []
          },
          stats: {
              sent: 0,
              failed: 0,
              skipped: 0,
              uptimeStartAt: Date.now(),
              lastPingMs: 0,
              lastRunAt: 0
          }
      };

      const db = await jsonDb.read();
      db.userbots.push(newUserbot);
      await jsonDb.write(db);
      return newUserbot;
  }
}

export const userbotManager = new UserbotManager();
