import { GramJsClient } from './gramjs.client';
import { NewMessage, NewMessageEvent } from 'telegram/events';
import { jsonDb } from '../storage/db';
import pino from 'pino';

const logger = pino({ level: 'info' });

export function setupUserbotEvents(client: GramJsClient, userbotId: string) {
    client.client.addEventHandler(async (event: NewMessageEvent) => {
        const message = event.message;
        if (!message || message.out) return;

        try {
            const db = await jsonDb.read();
            const userbot = db.userbots.find(u => u.id === userbotId);
            if (!userbot) return;

            // Get sender info
            const sender = await message.getSender();
            // @ts-ignore
            const senderId = sender?.id?.toString();
            if (!senderId) return;

            // @ts-ignore
            const isPrivate = message.isPrivate;

            // === PM PERMIT ===
            if (isPrivate && userbot.pmPermit?.enabled) {
                if (!userbot.pmPermit.allowed.includes(senderId)) {
                    const template = userbot.pmPermit.template || 'I am busy. Please wait for my response.';
                    try {
                        await message.reply({ message: template });
                    } catch (e: any) {
                        logger.error(`PM Permit reply failed: ${e?.message}`);
                    }
                    return;
                }
            }

            // === AUTO REPLY KEYWORD ===
            if (userbot.autoReplyKeyword?.enabled && message.message) {
                const msgText = message.message.toLowerCase();
                const keywords = userbot.autoReplyKeyword.keywords || [];
                
                const matched = keywords.some(kw => msgText.includes(kw.toLowerCase()));
                
                if (matched) {
                    try {
                        if (userbot.autoReplyKeyword.useForward && userbot.settings.forwardConfig?.chatId) {
                            const fromEntity = await client.client.getEntity(userbot.settings.forwardConfig.chatId);
                            await client.client.forwardMessages(message.peerId, {
                                messages: userbot.settings.forwardConfig.messageIds || [],
                                fromPeer: fromEntity
                            });
                        } else if (userbot.autoReplyKeyword.replyText) {
                            await message.reply({ message: userbot.autoReplyKeyword.replyText });
                        } else if (userbot.settings.regularText) {
                            await message.reply({ message: userbot.settings.regularText });
                        }
                    } catch (e: any) {
                        logger.error(`Auto reply keyword failed: ${e?.message}`);
                    }
                }
            }

        } catch (e: any) {
            logger.error(`Event handler error: ${e?.message}`);
        }

    }, new NewMessage({}));
}
