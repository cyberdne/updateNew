import cron from 'node-cron';
import { jsonDb } from '../storage/db';
import { jobRunner } from '../jaseb/job.runner';
import { userbotManager } from '../userbots/userbot.manager';
import { getCurrentTimeInTimezone } from '../utils/timezone.util';
import pino from 'pino';

const logger = pino({ level: 'info' });

export class TimerScheduler {
  start() {
    // Run every minute for timer checks
    cron.schedule('* * * * *', async () => {
      await this.checkTimers();
      await this.checkSubscriptions();
    });
    logger.info('Timer Scheduler started');
  }

  async checkTimers() {
    const db = await jsonDb.read();
    const timezone = db.globalSettings?.timezone || "Asia/Jakarta";
    const currentTimeStr = getCurrentTimeInTimezone(timezone);

    for (const u of db.userbots) {
      if (!u.settings.timer.enabled) continue;
      if (u.status === 'OFF_SUBS' || u.status === 'ERROR') continue;
      
      // Start Time
      if (u.settings.timer.startAt === currentTimeStr) {
        if (u.status !== 'RUNNING') {
          logger.info(`Timer: Starting ${u.label} at ${currentTimeStr} (${timezone})`);
          
          // Validate before starting
          if (u.settings.targets.length === 0) continue;
          if (!u.settings.regularText && !u.settings.forwardFromChatId) continue;
          if (!u.subscription.active || u.subscription.expireAt < Date.now()) continue;

          await jsonDb.updateUserbot(u.id, ub => { ub.status = 'RUNNING'; return ub; });
          await jobRunner.startJob(u.id);
        }
      }

      // Stop Time
      if (u.settings.timer.stopAt === currentTimeStr) {
        if (u.status === 'RUNNING') {
          logger.info(`Timer: Stopping ${u.label} at ${currentTimeStr} (${timezone})`);
          await jsonDb.updateUserbot(u.id, ub => { ub.status = 'STOPPED'; return ub; });
          await jobRunner.stopJob(u.id);
        }
      }
    }
  }

  async checkSubscriptions() {
    const db = await jsonDb.read();
    const now = Date.now();

    for (const u of db.userbots) {
      // Check if subscription expired
      if (u.subscription.expireAt < now && !u.subscription.autoOffApplied) {
        logger.info(`Subscription expired for ${u.label}, marking OFF_SUBS`);
        
        // Stop job if running
        if (u.status === 'RUNNING') {
          await jobRunner.stopJob(u.id);
        }

        // Disconnect client
        await userbotManager.stopClient(u.id);

        // Update status
        await jsonDb.updateUserbot(u.id, ub => {
          ub.status = 'OFF_SUBS';
          ub.subscription.active = false;
          ub.subscription.autoOffApplied = true;
          return ub;
        });
      }
    }
  }
}

export const timerScheduler = new TimerScheduler();
