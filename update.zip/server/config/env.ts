import dotenv from 'dotenv';
dotenv.config();

export const ENV = {
  BOT_TOKEN: process.env.BOT_TOKEN || '8157595163:AAHwBEChPl9uHcWqzvCdUw1lQsR0VSFKX8Y',
  OWNER_IDS: (process.env.OWNER_IDS || '7997048346').split(',').map(id => id.trim()).filter(Boolean),
  API_ID: Number(process.env.API_ID || 21177393),
  API_HASH: process.env.API_HASH || 'baf6231e8c0473e6c5cf68e06f72c0f0',
  LOG_LEVEL: process.env.LOG_LEVEL || 'info',
  DATA_DIR: process.env.DATA_DIR || 'data',
};
