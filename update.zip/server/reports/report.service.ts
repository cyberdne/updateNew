import ExcelJS from 'exceljs';
import path from 'path';
import fs from 'fs-extra';
import { jsonDb } from '../storage/db';

export class ReportService {
  async generateReport() {
    const db = await jsonDb.read();
    const workbook = new ExcelJS.Workbook();
    
    // Userbots Sheet
    const userbotSheet = workbook.addWorksheet('Userbots');
    userbotSheet.columns = [
        { header: 'ID', key: 'id', width: 36 },
        { header: 'Label', key: 'label', width: 20 },
        { header: 'Buyer ID', key: 'buyerId', width: 15 },
        { header: 'Status', key: 'status', width: 12 },
        { header: 'Subscription', key: 'subscription', width: 12 },
        { header: 'Expires At', key: 'expiresAt', width: 20 },
        { header: 'Targets', key: 'targets', width: 10 },
        { header: 'Sent', key: 'sent', width: 10 },
        { header: 'Failed', key: 'failed', width: 10 },
        { header: 'Skipped', key: 'skipped', width: 10 },
        { header: 'Message Type', key: 'messageType', width: 12 },
        { header: 'Spread Mode', key: 'spreadMode', width: 12 },
        { header: 'Timer', key: 'timer', width: 15 },
        { header: 'PM Permit', key: 'pmPermit', width: 12 },
        { header: 'Last Run', key: 'lastRun', width: 20 },
        { header: 'Last Error', key: 'lastError', width: 40 }
    ];

    // Style header row
    userbotSheet.getRow(1).font = { bold: true };
    userbotSheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    for (const u of db.userbots) {
        const isExpired = u.subscription.expireAt < Date.now();
        userbotSheet.addRow({
            id: u.id,
            label: u.label,
            buyerId: u.buyerId,
            status: u.status,
            subscription: u.subscription.active && !isExpired ? 'Active' : 'Expired',
            expiresAt: new Date(u.subscription.expireAt).toLocaleDateString('id-ID'),
            targets: u.settings.targets.length,
            sent: u.stats.sent,
            failed: u.stats.failed,
            skipped: u.stats.skipped,
            messageType: u.settings.messageType,
            spreadMode: u.settings.spreadMode,
            timer: u.settings.timer.enabled ? `${u.settings.timer.startAt}-${u.settings.timer.stopAt}` : 'Off',
            pmPermit: u.pmPermit.enabled ? 'On' : 'Off',
            lastRun: u.stats.lastRunAt ? new Date(u.stats.lastRunAt).toLocaleString('id-ID') : '-',
            lastError: u.stats.lastError || '-'
        });
    }

    // Targets Sheet
    const targetsSheet = workbook.addWorksheet('Targets');
    targetsSheet.columns = [
        { header: 'Userbot', key: 'userbot', width: 20 },
        { header: 'Buyer ID', key: 'buyerId', width: 15 },
        { header: 'Chat ID', key: 'chatId', width: 20 },
        { header: 'Title', key: 'title', width: 30 },
        { header: 'Username', key: 'username', width: 20 },
        { header: 'Added At', key: 'addedAt', width: 20 }
    ];

    targetsSheet.getRow(1).font = { bold: true };
    targetsSheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };

    for (const u of db.userbots) {
        for (const t of u.settings.targets) {
            targetsSheet.addRow({
                userbot: u.label,
                buyerId: u.buyerId,
                chatId: t.chatId,
                title: t.title,
                username: t.username || '-',
                addedAt: new Date(t.addedAt).toLocaleString('id-ID')
            });
        }
    }

    // Summary Sheet
    const summarySheet = workbook.addWorksheet('Summary');
    summarySheet.columns = [
        { header: 'Metric', key: 'metric', width: 25 },
        { header: 'Value', key: 'value', width: 15 }
    ];

    summarySheet.getRow(1).font = { bold: true };

    const totalSent = db.userbots.reduce((acc, u) => acc + u.stats.sent, 0);
    const totalFailed = db.userbots.reduce((acc, u) => acc + u.stats.failed, 0);
    const totalSkipped = db.userbots.reduce((acc, u) => acc + u.stats.skipped, 0);
    const totalTargets = db.userbots.reduce((acc, u) => acc + u.settings.targets.length, 0);
    const activeCount = db.userbots.filter(u => u.status === 'RUNNING').length;
    const expiredCount = db.userbots.filter(u => u.subscription.expireAt < Date.now()).length;

    const summaryData = [
        { metric: 'Total Userbots', value: db.userbots.length },
        { metric: 'Running', value: activeCount },
        { metric: 'Expired Subscriptions', value: expiredCount },
        { metric: 'Total Targets', value: totalTargets },
        { metric: 'Total Messages Sent', value: totalSent },
        { metric: 'Total Failed', value: totalFailed },
        { metric: 'Total Skipped', value: totalSkipped },
        { metric: 'Generated At', value: new Date().toLocaleString('id-ID') }
    ];

    summaryData.forEach(row => summarySheet.addRow(row));

    const reportDir = path.join('reports');
    await fs.ensureDir(reportDir);
    const filename = `jaseb-report-${Date.now()}.xlsx`;
    const filePath = path.join(reportDir, filename);
    
    await workbook.xlsx.writeFile(filePath);
    return filePath;
  }
}

export const reportService = new ReportService();
