import { DateTime } from 'luxon';

/**
 * Mendapatkan waktu saat ini berdasarkan timezone yang diset
 * @param timezone Timezone string (e.g., 'Asia/Jakarta', 'UTC')
 * @returns Waktu saat ini di timezone tersebut dalam format HH:mm
 */
export function getCurrentTimeInTimezone(timezone: string = "Asia/Jakarta"): string {
  const now = DateTime.now().setZone(timezone);
  return now.toFormat('HH:mm');
}

/**
 * Mendapatkan waktu saat ini berdasarkan timezone yang diset (dengan detil)
 */
export function getCurrentTimeDetailInTimezone(timezone: string = "Asia/Jakarta") {
  return DateTime.now().setZone(timezone);
}

/**
 * Parse waktu string (HH:mm) dengan timezone tertentu
 */
export function parseTimeInTimezone(timeStr: string, timezone: string = "Asia/Jakarta") {
  const [hours, minutes] = timeStr.split(':').map(Number);
  const now = DateTime.now().setZone(timezone);
  return now.set({ hour: hours, minute: minutes });
}

/**
 * Cek apakah waktu sekarang sama dengan waktu yang diberikan
 */
export function isCurrentTime(targetTime: string, timezone: string = "Asia/Jakarta"): boolean {
  const current = getCurrentTimeInTimezone(timezone);
  return current === targetTime;
}

/**
 * Validasi format HH:mm
 */
export function isValidTimeFormat(timeStr: string): boolean {
  const regex = /^([0-1][0-9]|2[0-3]):[0-5][0-9]$/;
  return regex.test(timeStr);
}

/**
 * Resolve various timezone inputs (aliases like WIB/WITA/WIT, lowercase iana,
 * or UTC/GMT offsets) to a valid IANA timezone string when possible.
 * Returns normalized IANA timezone or null when not resolvable.
 */
export function resolveTimezone(input: string): string | null {
  if (!input) return null;
  const trimmed = input.trim();

  // Common Indonesian aliases
  const aliasMap: Record<string, string> = {
    'WIB': 'Asia/Jakarta',
    'WITA': 'Asia/Makassar',
    'WIT': 'Asia/Jayapura',
  };

  const upper = trimmed.toUpperCase();
  if (aliasMap[upper]) return aliasMap[upper];

  // Directly accept exact IANA strings
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: trimmed });
    return trimmed;
  } catch {}

  // Try to normalize common lowercase inputs like "asia/jakarta"
  if (trimmed.includes('/')) {
    const parts = trimmed.split('/').map(p => {
      if (!p) return p;
      return p.charAt(0).toUpperCase() + p.slice(1).toLowerCase();
    });
    const candidate = parts.join('/');
    try {
      new Intl.DateTimeFormat('en-US', { timeZone: candidate });
      return candidate;
    } catch {}
  }

  // Handle UTC/GMT offsets like UTC+7 or GMT+7 -> convert to Etc/GMT sign convention
  const offMatch = trimmed.match(/^(?:UTC|GMT)\s*([+-]?\d{1,2})$/i);
  if (offMatch) {
    const num = parseInt(offMatch[1], 10);
    if (!isNaN(num)) {
      // Note: IANA "Etc/GMT" signs are inverted: UTC+7 => Etc/GMT-7
      const etcSign = num === 0 ? 'Etc/GMT' : `Etc/GMT${num > 0 ? '-' : '+'}${Math.abs(num)}`;
      try {
        new Intl.DateTimeFormat('en-US', { timeZone: etcSign });
        return etcSign;
      } catch {}
    }
  }

  return null;
}
