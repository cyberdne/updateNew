import { userbotManager } from '../userbots/userbot.manager';
import { jsonDb } from '../storage/db';
import pino from 'pino';
import { Api } from 'telegram';

const logger = pino({ level: 'info' });

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

export class AutoLeaveService {
  /**
   * Auto leave dari grup yang sudah lama
   * Implementasi dasar: leave untuk targets yang berumur lebih dari leaveAfterDays (menggunakan target.addedAt)
   */
  async autoLeaveOldGroups(userbotId: string, leaveAfterDays: number = 1): Promise<number> {
    const client = userbotManager.getClient(userbotId);
    if (!client) throw new Error('Client not connected');

    const db = await jsonDb.read();
    const userbot = db.userbots.find(u => u.id === userbotId);
    if (!userbot) throw new Error('Userbot not found');

    let leftCount = 0;

    try {
      logger.info(`Checking groups for auto leave (${leaveAfterDays} days)`);

      const cutoff = Date.now() - leaveAfterDays * 24 * 60 * 60 * 1000;
      const candidates = (userbot.settings.targets || []).filter(t => {
        // consider group-like IDs (negative or starting with -100) and those added before cutoff
        const addedAt = t.addedAt || 0;
        const looksLikeGroup = String(t.chatId).startsWith('-') || String(t.chatId).startsWith('-100');
        return looksLikeGroup && addedAt > 0 && addedAt < cutoff;
      });

      for (const t of candidates) {
        try {
          let entity: any;
          try {
            entity = await client.client.getEntity(t.chatId);
          } catch (err) {
            if (t.username) entity = await client.client.getEntity(t.username);
            else throw err;
          }

          // Try leaving via channels.LeaveChannel (works for megagroups/channels)
          try {
            await client.client.invoke(new Api.channels.LeaveChannel({ channel: entity }));
          } catch (err) {
            // if unable to leave, log and continue
            logger.warn(`Failed to leave ${t.chatId}: ${(err as any)?.message}`);
            continue;
          }

          leftCount += 1;

          // Remove target from settings
          await jsonDb.updateUserbot(userbotId, u => {
            u.settings.targets = (u.settings.targets || []).filter(x => x.chatId !== t.chatId);
            return u;
          });

          // small delay
          await sleep(500 + Math.floor(Math.random() * 500));
        } catch (e: any) {
          logger.warn(`Auto leave failed for ${t.chatId}: ${e?.message}`);
        }
      }

      // Update stats
      await jsonDb.updateUserbot(userbotId, u => {
        if (!u.settings.autoLeave) {
          u.settings.autoLeave = { enabled: false, leaveAfterDays, leftCount: 0 } as any;
        }
        u.settings.autoLeave!.lastExecutedAt = Date.now();
        u.settings.autoLeave!.leftCount = (u.settings.autoLeave!.leftCount || 0) + leftCount;
        return u;
      });

      logger.info(`Auto leave completed: ${leftCount} groups left`);
      return leftCount;
    } catch (e: any) {
      logger.error(`Auto leave error: ${e?.message}`);
      throw e;
    }
  }
}

export const autoLeaveService = new AutoLeaveService();

