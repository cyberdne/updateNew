import { exec } from 'child_process';
import { promisify } from 'util';
import path from 'path';
import fs from 'fs-extra';

const execAsync = promisify(exec);

export type SourceExportMode = 'script_only' | 'no_modules' | 'no_data' | 'full';

interface ExportOptions {
  mode: SourceExportMode;
  customName?: string;
}

export class SourceService {
  private readonly projectRoot = process.cwd();
  private readonly outputDir = path.join(this.projectRoot, 'temp');

  async exportSource(options: ExportOptions): Promise<string> {
    const { mode, customName } = options;
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
    const filename = customName ? `${customName}.zip` : `jaseb_${mode}_${timestamp}.zip`;
    const outputPath = path.join(this.outputDir, filename);

    await fs.ensureDir(this.outputDir);

    // Build exclude list based on mode
    const excludes: string[] = [];
    
    switch (mode) {
      case 'script_only':
        excludes.push('node_modules', 'data', '.git', 'temp', 'dist', '.cache', '*.log', 'package-lock.json');
        break;
      case 'no_modules':
        excludes.push('node_modules', '.git', 'temp', 'dist', '.cache', '*.log', 'package-lock.json');
        break;
      case 'no_data':
        excludes.push('data', '.git', 'temp', 'dist', '.cache', '*.log');
        break;
      case 'full':
        excludes.push('.git', 'temp', '.cache', '*.log');
        break;
    }

    const excludeArgs = excludes.map(e => `-x "${e}" -x "${e}/*"`).join(' ');
    const command = `cd "${this.projectRoot}" && zip -r "${outputPath}" . ${excludeArgs}`;

    try {
      await execAsync(command, { maxBuffer: 100 * 1024 * 1024 });
      return outputPath;
    } catch (error: any) {
      throw new Error(`Failed to create archive: ${error.message}`);
    }
  }

  async cleanup(): Promise<void> {
    try {
      await fs.remove(this.outputDir);
    } catch (error) {
      // Ignore cleanup errors
    }
  }
}

export const sourceService = new SourceService();
