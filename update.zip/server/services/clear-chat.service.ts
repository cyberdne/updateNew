import { userbotManager } from '../userbots/userbot.manager';
import { jsonDb } from '../storage/db';
import pino from 'pino';
import { Api } from 'telegram';

const logger = pino({ level: 'info' });

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

export class ClearChatService {
  /**
   * Clear (hapus) semua pesan dari chats
   */
  async clearChats(
    userbotId: string,
    clearGroups: boolean = false,
    clearPrivate: boolean = false,
    deleteLimitDays?: number
  ): Promise<number> {
    const client = userbotManager.getClient(userbotId);
    if (!client) throw new Error('Client not connected');

    const db = await jsonDb.read();
    const userbot = db.userbots.find(u => u.id === userbotId);
    if (!userbot) throw new Error('Userbot not found');

    let deletedCount = 0;

    try {
      logger.info(`Clearing chats: groups=${clearGroups}, private=${clearPrivate}, limit=${deleteLimitDays} days`);
      
      // Get dialogs (chats) dari userbot
      const dialogs = await client.client.getDialogs();
      const cutoffTime = deleteLimitDays ? Date.now() - deleteLimitDays * 24 * 60 * 60 * 1000 : 0;

      for (const dialog of dialogs) {
        try {
          const isGroup = dialog.isGroup || dialog.entity instanceof Api.Channel || dialog.entity instanceof Api.ChatFull;
          const isPrivate = dialog.isUser;

          // Filter berdasarkan tipe chat
          if (isGroup && !clearGroups) continue;
          if (isPrivate && !clearPrivate) continue;

          const chatId = dialog.id;
          
          // Get all messages
          const messages = await client.client.getMessages(chatId, { limit: 100 });
          
          for (const msg of messages) {
            try {
              // Check if message is old enough
              if (deleteLimitDays && msg.date) {
                const msgTime = msg.date * 1000;
                if (msgTime > cutoffTime) continue;
              }

              // Delete message
              await client.client.deleteMessages(chatId, [msg.id], { revoke: true });
              deletedCount++;
              
              // Add delay to avoid flood wait
              await sleep(100);
            } catch (e: any) {
              // Continue jika ada error pada message tertentu
              logger.warn(`Failed to delete message: ${e?.message}`);
            }
          }

          await sleep(500);
        } catch (e: any) {
          logger.warn(`Error processing chat: ${e?.message}`);
        }
      }
      
      // Update stats
      await jsonDb.updateUserbot(userbotId, u => {
        if (!u.settings.clearChat) {
          u.settings.clearChat = {
            enabled: false,
            clearGroups: false,
            clearPrivate: false,
            deletedCount: 0,
          };
        }
        u.settings.clearChat!.lastExecutedAt = Date.now();
        u.settings.clearChat!.deletedCount = (u.settings.clearChat!.deletedCount || 0) + deletedCount;
        return u;
      });

      logger.info(`Clear chat completed: ${deletedCount} messages deleted`);
      return deletedCount;
    } catch (e: any) {
      logger.error(`Clear chat error: ${e?.message}`);
      throw e;
    }
  }
}

export const clearChatService = new ClearChatService();
