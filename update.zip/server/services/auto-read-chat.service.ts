import { userbotManager } from '../userbots/userbot.manager';
import { jsonDb } from '../storage/db';
import pino from 'pino';
import { Api } from 'telegram';

const logger = pino({ level: 'info' });

const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));

export class AutoReadChatService {
  /**
   * Auto read semua pesan di chats
   */
  async autoReadChats(
    userbotId: string,
    readGroups: boolean = true,
    readPrivate: boolean = true
  ): Promise<{ groupsRead: number; privateRead: number }> {
    const client = userbotManager.getClient(userbotId);
    if (!client) throw new Error('Client not connected');

    const db = await jsonDb.read();
    const userbot = db.userbots.find(u => u.id === userbotId);
    if (!userbot) throw new Error('Userbot not found');

    let groupsRead = 0;
    let privateRead = 0;

    try {
      logger.info(`Auto reading chats: groups=${readGroups}, private=${readPrivate}`);
      
      // Get all dialogs (chats)
      const dialogs = await client.client.getDialogs();

      for (const dialog of dialogs) {
        try {
          // Skip jika dialog tidak memiliki unread messages
          if (!dialog.unreadCount || dialog.unreadCount === 0) continue;

          const isGroup = dialog.isGroup || dialog.entity instanceof Api.Channel || dialog.entity instanceof Api.ChatFull;
          const isPrivate = dialog.isUser;

          // Filter berdasarkan tipe chat
          if (isGroup && !readGroups) continue;
          if (isPrivate && !readPrivate) continue;

          const chatId = dialog.id;

          try {
            // Mark as read dengan getHistory
            const messages = await client.client.getMessages(chatId, { limit: 100 });
            
            if (messages.length > 0) {
              // Get the latest message ID
              const latestMsgId = messages[0].id;
              
              // Mark range as read
              await client.client.invoke(new Api.messages.ReadHistory({
                peer: chatId,
                maxId: latestMsgId
              }));

              if (isGroup) groupsRead++;
              if (isPrivate) privateRead++;

              logger.info(`Marked ${chatId} as read`);
            }
          } catch (e: any) {
            logger.warn(`Failed to mark chat as read: ${e?.message}`);
          }

          await sleep(300);
        } catch (e: any) {
          logger.warn(`Error processing dialog: ${e?.message}`);
        }
      }
      
      // Update stats
      await jsonDb.updateUserbot(userbotId, u => {
        if (!u.settings.autoReadChat) {
          u.settings.autoReadChat = {
            enabled: false,
            readGroups: true,
            readPrivate: true,
          };
        }
        u.settings.autoReadChat!.lastExecutedAt = Date.now();
        return u;
      });

      logger.info(`Auto read completed: ${groupsRead} groups, ${privateRead} private messages read`);
      return { groupsRead, privateRead };
    } catch (e: any) {
      logger.error(`Auto read error: ${e?.message}`);
      throw e;
    }
  }
}

export const autoReadChatService = new AutoReadChatService();
