import { ReactNode } from "react";
import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  trendUp?: boolean;
  color?: "primary" | "success" | "warning" | "info" | "purple";
  className?: string;
  delay?: number;
}

export function StatsCard({ 
  title, 
  value, 
  icon: Icon, 
  color = "primary",
  className,
  delay = 0 
}: StatsCardProps) {
  
  const colorMap = {
    primary: "text-primary from-primary/20 to-primary/5",
    success: "text-emerald-500 from-emerald-500/20 to-emerald-500/5",
    warning: "text-amber-500 from-amber-500/20 to-amber-500/5",
    info: "text-blue-500 from-blue-500/20 to-blue-500/5",
    purple: "text-purple-500 from-purple-500/20 to-purple-500/5",
  };

  const bgGradient = colorMap[color];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: delay }}
      className={cn(
        "relative overflow-hidden rounded-2xl border border-white/5 bg-card/40 p-6 backdrop-blur-sm transition-all duration-300 hover:border-primary/20 hover:shadow-lg hover:shadow-primary/5 hover:-translate-y-1",
        className
      )}
    >
      <div className={cn("absolute -right-6 -top-6 h-32 w-32 rounded-full bg-gradient-to-br opacity-20 blur-2xl", bgGradient)} />
      
      <div className="relative z-10 flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <h3 className="mt-2 font-display text-3xl font-bold tracking-tight text-foreground">
            {value}
          </h3>
        </div>
        <div className={cn("rounded-xl p-3 shadow-inner bg-white/5 border border-white/5", colorMap[color].split(" ")[0])}>
          <Icon className="h-6 w-6" />
        </div>
      </div>
      
      {/* Decorative shimmer line */}
      <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-transparent via-primary/20 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
    </motion.div>
  );
}
