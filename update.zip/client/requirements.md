## Packages
framer-motion | Smooth animations for cards and layout
lucide-react | Beautiful icons for the dashboard
date-fns | Formatting uptime duration

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
