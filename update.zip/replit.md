# JASEB Telegram Bot

## Overview

JASEB (Jasa Sebar/Broadcast Service) is a Telegram automation bot built with Node.js. It provides multi-userbot management for broadcast services, allowing owners to manage multiple Telegram userbots simultaneously for message broadcasting to groups/channels.

The application consists of:
- **Backend**: Express.js server with Telegram bot (Telegraf) and userbot clients (GramJS/MTProto)
- **Frontend**: React dashboard for monitoring bot status and statistics
- **Storage**: File-based JSON database with mutex locking for concurrent access

## User Preferences

Preferred communication style: Simple, everyday language.
Menu language: Indonesian with professional formatting and emojis.

## System Architecture

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Telegram Bot Controller**: Telegraf library for Bot API interactions
- **Userbot Clients**: GramJS (telegram package) for MTProto userbot sessions
- **Build System**: esbuild for server bundling, Vite for client

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state
- **Routing**: Wouter for client-side routing
- **Animations**: Framer Motion

### Data Storage
- **Primary Storage**: JSON file-based database (`data/db.json`)
- **Concurrency Control**: async-mutex for safe concurrent file writes
- **Schema Validation**: Zod schemas for data validation
- **No SQL databases used** - explicitly avoids MongoDB, SQLite per requirements

### Key Design Patterns
- **Modular Bot Structure**: Separate routers for callbacks and text input handling
- **Menu-Based UI**: Inline keyboard navigation with edit-or-resend pattern
- **State Machine**: User conversation states tracked per Telegram user ID
- **Job Runner**: Background task execution for broadcast jobs with batching
- **Timer Scheduler**: Cron-based scheduling for automated start/stop times
- **Link Scanner**: Automatic group link detection and joining

## Bot Features

### Core Features
- Multi-userbot session management (String Session & Phone Login)
- Buyer ID tracking per userbot
- Broadcast modes: Instant (parallel with batching) and Sequential
- Target management: Manual add, group scanning, channel scanning, keyword search
- Forward message support from any chat/channel (auto-detect, multi-message support)
- Subscription system with expiration handling
- PM Permit auto-reply system
- Timer-based auto start/stop
- Excel report generation

### Premium Features
- **Premium Emoji Support**: Enable/disable support for Telegram Premium emojis in messages
- **Auto Pilot Mode**: Automatic link scanning + auto-joining groups while broadcasting
- **Auto Reply Keyword**: Automatic reply to messages containing specific keywords (text or forward mode)
- **Source Code Export**: Export script files to ZIP (script_only, no_modules, no_data, full modes)
- **Bot Broadcast**: Broadcast messages from bot to channels/groups/PMs
- **Auto Backup**: Scheduled backups with cron, channel sending, restore functionality
- **Cache & Junk Cleaner**: Clear .cache, temp, logs, and junk files

### Global Settings
- Default instant/sequential delays
- Default watermark text
- Global blacklist (chat IDs to skip)
- Anti-spam cooldown settings
- Max targets per userbot limit
- Auto join delay configuration

### Anti-Spam Protection
- FloodWait handling with automatic retry
- Cooldown every 5 group joins (5 minute wait)
- Per-target fail tracking
- Global and per-userbot blacklists

### Link Scanner
- Multiple regex patterns for Telegram links:
  - t.me/username
  - telegram.me/username
  - telegram.dog/username
  - t.me/joinchat/hash
  - t.me/+hash
- Automatic entity resolution with fallback
- Excluded usernames filter (prevents joining non-group links)
- Scans target chat messages for new group links

## File Structure

### Key Files
- `server/jaseb/job.runner.ts` - Main broadcast job execution with optimized batching
- `server/jaseb/link.scanner.ts` - Auto-pilot link detection and joining (5 regex patterns)
- `server/jaseb/target/target.manager.ts` - Target CRUD operations
- `server/bot/routers/callback.router.ts` - Telegram button callback handler
- `server/bot/routers/input.router.ts` - Text input state machine with forward auto-detect
- `server/bot/menus/*.ts` - Menu UI generation (Indonesian text with emojis)
- `server/storage/db.ts` - JSON database with global settings
- `server/services/source.service.ts` - Source code export service
- `server/services/backup.service.ts` - Auto backup service with cron scheduling
- `server/services/cache.service.ts` - Cache and junk cleaner

## External Dependencies

### Telegram Services
- **Bot API**: Via Telegraf - requires `BOT_TOKEN` from @BotFather
- **MTProto API**: Via GramJS - requires `API_ID` and `API_HASH` from my.telegram.org

### NPM Packages (Key)
- `telegraf`: Telegram Bot API framework
- `telegram`: GramJS for MTProto userbot functionality
- `exceljs`: Excel report generation
- `pino`: Logging
- `node-cron`: Timer and backup scheduling
- `async-mutex`: Concurrent write protection
- `fs-extra`: Enhanced filesystem operations
- `uuid`: Unique ID generation

### Environment Variables Required
- `BOT_TOKEN`: Telegram bot token
- `OWNER_IDS`: Comma-separated Telegram user IDs for access control
- `API_ID`: Telegram API ID for userbots
- `API_HASH`: Telegram API hash for userbots
- `SESSION_SECRET`: Session encryption key

## Recent Updates (January 2026)

### Fixed
- Forward message now auto-detects forwarded messages and saves chatId + messageIds automatically
- Auto-join groups improved with 5 comprehensive link detection patterns and excluded usernames filter
- Global Settings fully implemented with all configuration options
- Job runner optimized with batching (10 parallel for instant, 1 for sequential)

### Added
- Source Code Export feature with 4 modes (script_only, no_modules, no_data, full) + custom naming
- Bot Broadcast - broadcast from bot to channel/group/PM with target management
- Cache & Junk Cleaner - clears .cache, temp, logs, junk files with size reporting
- Auto Backup system - scheduled backups with cron, channel sending, restore functionality
- Monitor Info display - shows server port, IPs, network interfaces, system stats
- All menus revamped with Indonesian text, professional formatting, and detailed explanations
- Premium Emoji Support (enable/disable per userbot)
- Auto Pilot Mode - automatic link scanning + auto-joining during broadcasts
- Auto Reply Keyword - automatic reply to messages containing keywords
- Global blacklist system
- Enhanced anti-spam with configurable cooldowns
- Per-target fail tracking for better target management
